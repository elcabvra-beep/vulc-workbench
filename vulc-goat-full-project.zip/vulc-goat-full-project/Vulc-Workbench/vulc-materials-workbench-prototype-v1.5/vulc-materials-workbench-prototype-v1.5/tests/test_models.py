import math
import unittest
from vulc_physics import *

class TestPhysicsModels(unittest.TestCase):
    def test_decay_half_life(self):
        r = radioactive_decay(1000, 10, 10)
        self.assertAlmostEqual(r['remaining_atoms_expected'], 500)
        self.assertAlmostEqual(r['activity_bq'], math.log(2)*50)
    def test_gravity_inverse_square(self):
        a = gravitational_force(2, 3, 4)['force_n']
        b = gravitational_force(2, 3, 8)['force_n']
        self.assertAlmostEqual(a/b, 4)
    def test_weight(self): self.assertAlmostEqual(near_surface_weight(2)['weight_n'], 19.6133)
    def test_second_law(self): self.assertEqual(acceleration_from_force(10, 2)['acceleration_m_s2'], 5)
    def test_pressure(self): self.assertEqual(pressure_force(1000, .2)['force_n'], 200)
    def test_friction(self): self.assertAlmostEqual(coulomb_friction(100, .3)['friction_limit_or_magnitude_n'], 30)
    def test_drag_opposes_motion(self):
        self.assertLess(quadratic_drag(1.2, 1, 2, 3)['drag_force_n'], 0)
        self.assertGreater(quadratic_drag(1.2, 1, 2, -3)['drag_force_n'], 0)
    def test_cooling_toward_ambient(self):
        r = newton_cooling(500, 300, 100, 10, 1, 1, 1000)
        self.assertGreater(r['temperature_k'], 300); self.assertLess(r['temperature_k'], 500)
    def test_elastic_impact_conserves_energy(self):
        r = one_dimensional_impact(1, 2, 1, 0, 1)
        self.assertAlmostEqual(r['kinetic_energy_before_j'], r['kinetic_energy_after_j'])
        self.assertAlmostEqual(r['velocity_a_after_m_s'], 0)
        self.assertAlmostEqual(r['velocity_b_after_m_s'], 2)
    def test_inelastic_impact_energy_nonincreasing(self):
        r = one_dimensional_impact(1, 2, 1, 0, 0)
        self.assertLessEqual(r['kinetic_energy_after_j'], r['kinetic_energy_before_j'])
    def test_invalid_domains(self):
        with self.assertRaises(ModelError): radioactive_decay(1, 1, 0)
        with self.assertRaises(ModelError): gravitational_force(1, 1, 0)
        with self.assertRaises(ModelError): acceleration_from_force(1, 0)
        with self.assertRaises(ModelError): one_dimensional_impact(1, 0, 1, 1, .5)

if __name__ == '__main__': unittest.main()
