import unittest
from vulc_engine.process_api import (
    BoundaryMapping, BoundaryMappingKind, CouplingDirection, DomainRef, FieldType,
    InteractionLink, MaterialRef, ModelContract, PortContract, ProcessDefinition,
    Schedule, SolverProfile,
)
from vulc_engine.execution import ModelRegistry, ExecutionPlanError, compile_execution_plan
from vulc_engine.quantity import TEMPERATURE

class ExecutionPlanTests(unittest.TestCase):
    def make_process(self, reverse=False):
        temp = FieldType("temperature", "K", TEMPERATURE, spatial_support="global")
        a = ModelContract("a", "1", "thermal", "da/dt", (), (), (), (PortContract("out", "output", temp), PortContract("in", "input", temp)), "analytically_verified")
        b = ModelContract("b", "1", "thermal", "db/dt", (), (), (), (PortContract("out", "output", temp), PortContract("in", "input", temp)), "analytically_verified")
        mapping = BoundaryMapping(BoundaryMappingKind.GLOBAL, "da", "db")
        link = InteractionLink("ab", "a", "out", "b", "in", CouplingDirection.ONE_WAY, mapping)
        links = (link,)
        if reverse:
            # Same-direction contracts are intentionally not used to fake a valid reverse port.
            links = (link, InteractionLink("ba", "b", "out", "a", "in", CouplingDirection.ONE_WAY,
                BoundaryMapping(BoundaryMappingKind.GLOBAL, "db", "da")))
        return ProcessDefinition("p", "1", "p", "test", (MaterialRef("ma", "A"), MaterialRef("mb", "B")),
            (DomainRef("da", "ma", "global"), DomainRef("db", "mb", "global")), (a,b), links, Schedule())
    def test_topological_order_and_determinism(self):
        p = self.make_process(); r = ModelRegistry({("a","1"):"impl.a", ("b","1"):"impl.b"})
        plan = compile_execution_plan(p, r)
        self.assertEqual([s.model_id for s in plan.steps], ["a", "b"])
        self.assertEqual(plan.to_dict(), compile_execution_plan(p, r).to_dict())
    def test_missing_implementation_rejected(self):
        with self.assertRaisesRegex(ExecutionPlanError, "no registered implementation"):
            compile_execution_plan(self.make_process(), ModelRegistry())
    def test_cycle_rejected(self):
        with self.assertRaisesRegex(ExecutionPlanError, "dependency cycle"):
            compile_execution_plan(self.make_process(True), ModelRegistry({("a","1"):"a", ("b","1"):"b"}))
    def test_disabled_link_does_not_add_dependency(self):
        p = self.make_process(); from dataclasses import replace
        p = replace(p, links=(replace(p.links[0], enabled=False),))
        plan = compile_execution_plan(p, ModelRegistry({("a","1"):"a", ("b","1"):"b"}))
        self.assertEqual(plan.active_links, ())

if __name__ == "__main__": unittest.main()
