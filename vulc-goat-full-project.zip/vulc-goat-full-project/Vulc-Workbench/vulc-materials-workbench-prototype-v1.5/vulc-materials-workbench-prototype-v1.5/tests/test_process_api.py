import json
import pathlib
import unittest

from vulc_engine.process_api import (
    BoundaryMapping, BoundaryMappingKind, ContractError, CouplingDirection, DomainRef,
    FieldType, InteractionLink, MaterialRef, ModelContract, OutputSpec, PortContract,
    ProcessDefinition, Schedule, Severity, SolverProfile, TimePolicy, TimeSemantics,
)
from vulc_engine.quantity import TEMPERATURE, ENERGY


class ProcessApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = FieldType("temperature", "K", TEMPERATURE, "scalar", "global")
        self.energy = FieldType("energy", "J", ENERGY, "scalar", "global")
        self.a = ModelContract("a", "1.0", "thermal", "equation A", ("uniform body",), ("lumped only",), ("ode",), (PortContract("out", "output", self.temp),))
        self.b = ModelContract("b", "1.0", "thermal", "equation B", (), (), ("ode",), (PortContract("in", "input", self.temp),))
        self.materials = (MaterialRef("mat-a", "Material A"), MaterialRef("mat-b", "Material B"))
        self.domains = (DomainRef("dom-a", "mat-a", "global"), DomainRef("dom-b", "mat-b", "global"))
        self.link = InteractionLink("link-1", "a", "out", "b", "in", CouplingDirection.ONE_WAY,
            BoundaryMapping(BoundaryMappingKind.GLOBAL, "dom-a", "dom-b"))
        self.process = ProcessDefinition("p", "1.0", "Demo", "thermal", self.materials, self.domains,
            (self.a, self.b), (self.link,), Schedule(), (OutputSpec("temperature"),))

    def test_json_roundtrip(self):
        parsed = ProcessDefinition.from_json(self.process.to_json())
        self.assertEqual(parsed.to_dict(), self.process.to_dict())

    def test_schema_version_rejected(self):
        data = self.process.to_dict(); data["schema_version"] = "99"
        with self.assertRaises(ContractError): ProcessDefinition.from_dict(data)

    def test_unit_dimension_mismatch_rejected(self):
        with self.assertRaises(ContractError): FieldType("bad", "K", ENERGY)

    def test_vector_requires_frame(self):
        with self.assertRaises(ContractError): FieldType("velocity", "m/s", (0,1,-1,0,0,0,0), "vector", "cell")

    def test_randomized_requires_seed(self):
        with self.assertRaises(ContractError): Schedule(mode="randomized")

    def test_interval_requires_positive_value(self):
        with self.assertRaises(ContractError): TimePolicy(update_policy="interval")

    def test_explicit_boundary_requires_map_id(self):
        with self.assertRaises(ContractError): BoundaryMapping(BoundaryMappingKind.EXPLICIT, "a", "b")

    def test_dimension_mismatch_diagnostic(self):
        wrong_target = ModelContract("b", "1.0", "energy", "equation B", (), (), (), (PortContract("in", "input", self.energy),))
        p = ProcessDefinition("p", "1", "Demo", "x", self.materials, self.domains, (self.a, wrong_target), (self.link,), outputs=(OutputSpec("x"),))
        self.assertIn("DIMENSION_MISMATCH", {d.code for d in p.validate()})

    def test_unknown_port_diagnostic(self):
        bad = InteractionLink("l", "a", "missing", "b", "in", CouplingDirection.ONE_WAY, self.link.boundary_mapping)
        p = ProcessDefinition("p", "1", "Demo", "x", self.materials, self.domains, (self.a, self.b), (bad,), outputs=(OutputSpec("x"),))
        self.assertIn("LINK_SOURCE_PORT_UNKNOWN", {d.code for d in p.validate()})

    def test_two_way_requires_reverse_link(self):
        tw = InteractionLink("tw", "a", "out", "b", "in", CouplingDirection.TWO_WAY, self.link.boundary_mapping)
        p = ProcessDefinition("p", "1", "Demo", "x", self.materials, self.domains, (self.a, self.b), (tw,), outputs=(OutputSpec("x"),))
        self.assertIn("TWO_WAY_REVERSE_LINK_MISSING", {d.code for d in p.validate()})

    def test_solver_capabilities_checked(self):
        ds = self.process.validate(SolverProfile("tiny", frozenset(), frozenset({"global"})))
        self.assertIn("SOLVER_CAPABILITY_MISSING", {d.code for d in ds})

    def test_unvalidated_models_warn(self):
        ds = self.process.validate(SolverProfile("ode", frozenset({"ode"}), frozenset({"global"})))
        self.assertIn("MODEL_UNVALIDATED", {d.code for d in ds})
        self.assertTrue(all(d.severity in Severity for d in ds))

    def test_same_dimension_different_units_requires_explicit_conversion(self):
        millimetres = FieldType("distance", "mm", (0, 1, 0, 0, 0, 0, 0), "scalar", "global")
        metres = FieldType("distance", "m", (0, 1, 0, 0, 0, 0, 0), "scalar", "global")
        src = ModelContract("distance-src", "1", "geometry", "x", (), (), (), (PortContract("out", "output", millimetres),))
        dst = ModelContract("distance-dst", "1", "geometry", "x", (), (), (), (PortContract("in", "input", metres),))
        link = InteractionLink("units", "distance-src", "out", "distance-dst", "in", CouplingDirection.ONE_WAY,
            BoundaryMapping(BoundaryMappingKind.GLOBAL, "dom-a", "dom-b"))
        p = ProcessDefinition("p", "1", "Units", "test", self.materials, self.domains, (src, dst), (link,), outputs=(OutputSpec("distance"),))
        self.assertIn("UNIT_CONVERSION_REQUIRED", {d.code for d in p.validate()})

    def test_example_loads(self):
        p = pathlib.Path(__file__).parents[1] / "examples" / "thermal_contact_process.json"
        loaded = ProcessDefinition.from_json(p.read_text())
        self.assertEqual(loaded.process_id, "process.thermal-contact.demo")
        self.assertTrue(any(d.code == "MODEL_UNVALIDATED" for d in loaded.validate()))


if __name__ == "__main__": unittest.main()
