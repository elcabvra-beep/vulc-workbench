import unittest
from vulc_engine.goat_script import parse_script

class GoatScriptParserTests(unittest.TestCase):
    def test_builds_typed_ast_and_locations(self):
        r = parse_script('''# demo
material("steel", grade="AISI 1045")
heat = process("heat_treat", model="thermal.heat_treatment", enabled=true)
factor("temperature", value=900, unit="K")
connect(heat.temperature_out, quench.temperature_in)
use("heat-cycle@1.0")
quench = process("quench", model="thermal.cooling")''')
        self.assertTrue(r.ok, [d.to_dict() for d in r.diagnostics])
        self.assertEqual([x.kind for x in r.ast.statements], ["material", "process", "factor", "connect", "use", "process"])
        self.assertEqual(r.ast.statements[1].arguments["enabled"], True)
        self.assertEqual(r.ast.statements[3].source_port, "temperature_out")
        self.assertEqual(r.ast.statements[0].span.line, 2)

    def test_unknown_statement_fails_closed(self):
        r = parse_script('import os')
        self.assertFalse(r.ok)
        self.assertEqual(r.diagnostics[0].code, "UNSUPPORTED_STATEMENT")

    def test_duplicate_alias_and_unknown_connection(self):
        r = parse_script('''x = process("a", model="m")
x = process("b", model="m")
connect(x.out, missing.in)''')
        codes = {d.code for d in r.diagnostics}
        self.assertIn("DUPLICATE_ALIAS", codes)
        self.assertIn("UNKNOWN_CONNECTION_ALIAS", codes)

    def test_requires_model_and_factor_units(self):
        r = parse_script('''process("hot")
factor("temp", value=900)''')
        self.assertIn("MODEL_REQUIRED", {d.code for d in r.diagnostics})
        self.assertIn("FACTOR_INCOMPLETE", {d.code for d in r.diagnostics})

    def test_duplicate_and_unsupported_arguments_fail(self):
        r = parse_script('process("a", model="m", model="n")')
        self.assertIn("SYNTAX_ERROR", {d.code for d in r.diagnostics})
        self.assertFalse(r.ok)

    def test_numeric_nonfinite_rejected(self):
        r = parse_script('factor("temp", value=1e999, unit="K")')
        self.assertIn("SYNTAX_ERROR", {d.code for d in r.diagnostics})

if __name__ == "__main__": unittest.main()
