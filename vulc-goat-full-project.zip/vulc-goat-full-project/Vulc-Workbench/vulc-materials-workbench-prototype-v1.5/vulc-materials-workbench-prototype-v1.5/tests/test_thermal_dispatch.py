import unittest
from vulc_engine.execution import ExecutableModelRegistry, execute_process
from vulc_engine.process_api import DomainRef, FieldType, MaterialRef, ModelContract, OutputSpec, PortContract, ProcessDefinition, Schedule
from vulc_engine.quantity import TEMPERATURE, ENERGY
from vulc_physics.thermal_coupling import MODEL_ID, MODEL_VERSION, register_thermal_coupling_model

class ThermalProcessIntegrationTests(unittest.TestCase):
    def test_process_dispatcher_executes_thermal_model(self):
        cap_dim = (1, 2, -2, 0, -1, 0, 0)
        cond_dim = (1, 2, -3, 0, -1, 0, 0)
        time_dim = (0, 0, 1, 0, 0, 0, 0)
        ports = []
        for name, unit, dim in (
            ("heat_capacity_a", "J/K", cap_dim), ("initial_temperature_a", "K", TEMPERATURE),
            ("heat_capacity_b", "J/K", cap_dim), ("initial_temperature_b", "K", TEMPERATURE),
            ("conductance", "W/K", cond_dim), ("duration", "s", time_dim), ("timestep", "s", time_dim),
        ):
            ports.append(PortContract(name, "input", FieldType(name, unit, dim, spatial_support="global")))
        ports.extend((
            PortContract("final_temperature_a", "output", FieldType("ta", "K", TEMPERATURE, spatial_support="global")),
            PortContract("final_temperature_b", "output", FieldType("tb", "K", TEMPERATURE, spatial_support="global")),
            PortContract("max_energy_balance_error", "output", FieldType("energy_error", "J", ENERGY, spatial_support="global")),
        ))
        model = ModelContract(MODEL_ID, MODEL_VERSION, "lumped_thermal", "two-body heat balance", (), (), (), tuple(ports), "analytically_verified")
        process = ProcessDefinition("thermal-process-test", "1", "Thermal integration test", "thermal",
            (MaterialRef("ma", "A"), MaterialRef("mb", "B")),
            (DomainRef("da", "ma", "global"), DomainRef("db", "mb", "global")),
            (model,), (), Schedule(), (OutputSpec("final_temperature_a"), OutputSpec("final_temperature_b")))
        registry = ExecutableModelRegistry()
        register_thermal_coupling_model(registry)
        result = execute_process(process, registry, {MODEL_ID: {
            "heat_capacity_a": 10.0, "initial_temperature_a": 400.0,
            "heat_capacity_b": 20.0, "initial_temperature_b": 300.0,
            "conductance": 2.0, "duration": 10.0, "timestep": 0.1,
        }})
        self.assertAlmostEqual(result.outputs[MODEL_ID]["final_temperature_a"], 336.6524712934, places=8)
        self.assertAlmostEqual(result.outputs[MODEL_ID]["final_temperature_b"], 331.6737643533, places=8)
        self.assertLess(result.outputs[MODEL_ID]["max_energy_balance_error"], 1e-9)

if __name__ == "__main__": unittest.main()
