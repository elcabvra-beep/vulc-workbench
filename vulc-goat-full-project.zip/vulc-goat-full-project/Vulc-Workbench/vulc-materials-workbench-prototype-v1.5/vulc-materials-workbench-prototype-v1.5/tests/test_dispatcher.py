import unittest
from vulc_engine.process_api import (
    BoundaryMapping, BoundaryMappingKind, CouplingDirection, DomainRef, FieldType,
    InteractionLink, MaterialRef, ModelContract, PortContract, ProcessDefinition, Schedule,
)
from vulc_engine.execution import ExecutableModelRegistry, ModelExecutionContext, ModelExecutionError, execute_process
from vulc_engine.quantity import POWER

class RuntimeDispatcherTests(unittest.TestCase):
    def make_process(self, source_unit="W", target_unit="kW"):
        src_field = FieldType("power", source_unit, POWER, spatial_support="global")
        dst_field = FieldType("power", target_unit, POWER, spatial_support="global")
        source = ModelContract("source", "1.0", "test", "P=constant", (), (), (),
                               (PortContract("power_out", "output", src_field),), "analytically_verified")
        target = ModelContract("target", "1.0", "test", "consume power", (), (), (),
                               (PortContract("power_in", "input", dst_field), PortContract("result", "output", dst_field)), "analytically_verified")
        link = InteractionLink("link", "source", "power_out", "target", "power_in", CouplingDirection.ONE_WAY,
                               BoundaryMapping(BoundaryMappingKind.GLOBAL, "d1", "d2"))
        return ProcessDefinition("dispatch-test", "1.0", "Dispatcher test", "test",
            (MaterialRef("m1", "Material 1"), MaterialRef("m2", "Material 2")),
            (DomainRef("d1", "m1", "global"), DomainRef("d2", "m2", "global")),
            (source, target), (link,), Schedule(), metadata={"test": True})

    def registry(self):
        registry = ExecutableModelRegistry()
        registry.register_callable("source", "1.0", "test.constant-power", lambda ctx: {"power_out": 2500.0})
        def consume(ctx):
            return {"result": ctx.inputs["power_in"] * 2}
        registry.register_callable("target", "1.0", "test.double-power", consume)
        return registry

    def test_runs_registered_models_and_converts_units(self):
        result = execute_process(self.make_process(), self.registry())
        self.assertEqual([r.model_id for r in result.records], ["source", "target"])
        self.assertAlmostEqual(result.records[1].inputs["power_in"], 2.5)
        self.assertAlmostEqual(result.outputs["target"]["result"], 5.0)
        self.assertEqual(len(result.configuration_sha256), 64)
        self.assertEqual(result.to_dict()["process_id"], "dispatch-test")
        self.assertIn("configuration_sha256", result.to_json())

    def test_repeated_runs_have_unique_ids_but_stable_configuration_hash(self):
        process = self.make_process()
        first = execute_process(process, self.registry())
        second = execute_process(process, self.registry())
        self.assertNotEqual(first.run_id, second.run_id)
        self.assertTrue(first.run_id.startswith("run-"))
        self.assertEqual(first.configuration_sha256, second.configuration_sha256)

    def test_rejects_missing_required_input_before_call(self):
        p = self.make_process()
        from dataclasses import replace
        p = replace(p, links=())
        registry = self.registry()
        with self.assertRaisesRegex(ModelExecutionError, "missing required inputs"):
            execute_process(p, registry)

    def test_rejects_nonfinite_model_output(self):
        registry = self.registry()
        bad = ExecutableModelRegistry()
        bad.register_callable("source", "1.0", "bad.nan", lambda ctx: {"power_out": float("nan")})
        bad.register_callable("target", "1.0", "test.double-power", lambda ctx: {"result": 0.0})
        with self.assertRaisesRegex(ModelExecutionError, "finite scalar"):
            execute_process(self.make_process(), bad)

    def test_rejects_unsupported_mapping_instead_of_guessing(self):
        from dataclasses import replace
        p = self.make_process()
        link = replace(p.links[0], boundary_mapping=BoundaryMapping(BoundaryMappingKind.INTERPOLATION, "d1", "d2"))
        p = replace(p, links=(link,))
        with self.assertRaisesRegex(ModelExecutionError, "registered mapping operator"):
            execute_process(p, self.registry())

    def test_model_exception_has_context(self):
        registry = ExecutableModelRegistry()
        registry.register_callable("source", "1.0", "throws", lambda ctx: (_ for _ in ()).throw(RuntimeError("boom")))
        registry.register_callable("target", "1.0", "target", lambda ctx: {"result": 0.0})
        with self.assertRaisesRegex(ModelExecutionError, "source implementation failed.*boom"):
            execute_process(self.make_process(), registry)

if __name__ == "__main__":
    unittest.main()
