import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from vulc_engine.goat_compiler import compile_goat_script, execute_goat_script
from vulc_engine.execution import ExecutableModelRegistry
from vulc_physics.thermal_coupling import MODEL_ID, register_thermal_coupling_model

VALID = '''material("Body A")
material("Body B")
thermal = process("thermal-demo", model="thermal.two_body_lumped_conductance", heat_capacity_a=10, initial_temperature_a=400, heat_capacity_b=20, initial_temperature_b=300, conductance=2, duration=10, timestep=0.1)'''

class GoatCompilerTests(unittest.TestCase):
    def test_compile_and_execute_end_to_end(self):
        compiled, result = execute_goat_script(VALID)
        self.assertEqual(compiled.process.process_id, "process.thermal-demo")
        self.assertEqual(len(compiled.source_sha256), 64)
        self.assertAlmostEqual(result.outputs[MODEL_ID]["final_temperature_a"], 336.652471, places=4)
        self.assertAlmostEqual(result.outputs[MODEL_ID]["final_temperature_b"], 331.673764, places=4)
        self.assertLess(result.outputs[MODEL_ID]["max_energy_balance_error"], 1e-9)
        self.assertTrue(result.run_id.startswith("run-"))

    def test_factor_values_compile(self):
        source = '''factor("heat_capacity_a", value=10, unit="J/K")
factor("initial_temperature_a", value=400, unit="K")
factor("heat_capacity_b", value=20, unit="J/K")
factor("initial_temperature_b", value=300, unit="K")
factor("conductance", value=2, unit="W/K")
factor("duration", value=10, unit="s")
factor("timestep", value=0.1, unit="s")
process("thermal-demo", model="thermal.two_body_lumped_conductance")'''
        self.assertEqual(compile_goat_script(source).initial_inputs[MODEL_ID]["conductance"], 2)

    def test_unknown_model_fails_closed(self):
        with self.assertRaisesRegex(ValueError, "unsupported model"):
            compile_goat_script('process("x", model="thermal.magic", heat_capacity_a=1)')

    def test_connections_not_executable_yet(self):
        with self.assertRaisesRegex(ValueError, "not yet executable"):
            compile_goat_script(VALID + '\nconnect(thermal.final_temperature_a, thermal.initial_temperature_a)')

    def test_unknown_arguments_rejected(self):
        with self.assertRaisesRegex(ValueError, "unsupported process argument"):
            compile_goat_script(VALID.replace('duration=10', 'duration=10, arbitrary_code="no"'))

    def test_missing_required_input_rejected(self):
        with self.assertRaisesRegex(ValueError, "missing required thermal input"):
            compile_goat_script('process("x", model="thermal.two_body_lumped_conductance", heat_capacity_a=10)')

    def test_registry_must_have_callable(self):
        compiled = compile_goat_script(VALID)
        registry = ExecutableModelRegistry()
        registry.register(MODEL_ID, "1.0.0", "metadata-only")
        from vulc_engine.execution import ModelExecutionError
        with self.assertRaises(ModelExecutionError):
            from vulc_engine.execution import execute_process
            execute_process(compiled.process, registry, compiled.initial_inputs)

if __name__ == "__main__": unittest.main()
