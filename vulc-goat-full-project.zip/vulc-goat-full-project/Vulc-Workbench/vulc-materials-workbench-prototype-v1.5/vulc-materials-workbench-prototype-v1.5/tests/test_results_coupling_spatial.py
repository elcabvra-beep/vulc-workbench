import unittest
from vulc_engine.results import ResultSeries, CausalChange, ResultBundle, ResultArtifactError
from vulc_engine.coupling import solve_fixed_point, CouplingConvergenceError
from vulc_physics.thermal_1d import Thermal1DConfig, run_thermal_1d, SpatialThermalError

class ResultTests(unittest.TestCase):
 def test_bundle_serializes_and_hashes(self):
  s=ResultSeries('T','temperature','K',(0.,1.),(300.,310.),'body','thermal')
  c=CausalChange('c1',1.,'thermal','body','temperature',300.,310.,'heat conduction',('constant k',))
  b=ResultBundle('r','p','1','abc',(s,),(c,),{'evidence_status':'unvalidated'})
  self.assertEqual(b.sha256,ResultBundle('r','p','1','abc',(s,),(c,),{'evidence_status':'unvalidated'}).sha256)
  self.assertIn('causal_changes',b.to_json())
 def test_invalid_series_rejected(self):
  with self.assertRaises(ResultArtifactError): ResultSeries('T','temperature','K',(0.,1.),(1.,2.),spatial_coordinates_m=(0.,1.))
class CouplingTests(unittest.TestCase):
 def test_converges_fixed_point(self):
  r=solve_fixed_point(lambda x:(0.5*x[0]+1,), (0.,), absolute_tolerance=1e-12, relative_tolerance=1e-12)
  self.assertTrue(r.converged); self.assertAlmostEqual(r.state[0],2.,places=10)
 def test_nonconvergence_is_explicit(self):
  with self.assertRaises(CouplingConvergenceError): solve_fixed_point(lambda x:(2*x[0]+1,), (1.,), max_iterations=8)
class SpatialThermalTests(unittest.TestCase):
 def test_uniform_field_stays_uniform_and_energy_conserved(self):
  c=Thermal1DConfig(.1,10,1000,500,10.,(300.,)*10,1.,.01)
  r=run_thermal_1d(c)
  self.assertTrue(all(abs(t-300)<1e-10 for row in r.temperatures_k for t in row))
  self.assertLess(r.max_energy_residual_j_per_m2,1e-8)
 def test_heat_diffuses_and_neumann_boundary_energy_conserved(self):
  c=Thermal1DConfig(.1,10,1000,500,10.,(400.,)+(300.,)*9,1.,.001)
  r=run_thermal_1d(c)
  self.assertGreater(r.temperatures_k[-1][1],300.)
  self.assertLess(r.max_energy_residual_j_per_m2,1e-7)
 def test_second_order_spatial_convergence_for_neumann_eigenmode(self):
  # Cell-centered cosine mode satisfies insulated (zero-gradient) ends.
  import math
  errors=[]
  for n in (20,40):
   length=1.0; rho=1.0; cp=1.0; k=1.0; alpha=k/(rho*cp); dx=length/n; dt=0.2*dx*dx/alpha; duration=0.01
   steps=round(duration/dt); duration=steps*dt
   initial=tuple(300.+math.cos(math.pi*((i+.5)*dx)/length) for i in range(n))
   c=Thermal1DConfig(length,n,rho,cp,k,initial,duration,dt)
   result=run_thermal_1d(c); exact=tuple(300.+math.exp(-alpha*math.pi**2*duration/length**2)*math.cos(math.pi*x/length) for x in result.x_cell_centers_m)
   errors.append(math.sqrt(sum((a-b)**2 for a,b in zip(result.temperatures_k[-1],exact))/n))
  self.assertGreater(errors[0]/errors[1],3.2)
 def test_stability_limit_enforced(self):
  with self.assertRaises(SpatialThermalError): Thermal1DConfig(.1,10,1000,500,10.,(300.,)*10,3.,3.)
if __name__=='__main__': unittest.main()

class ThermalResultAdapterTests(unittest.TestCase):
 def test_spatial_run_exports_auditable_bundle(self):
  from vulc_physics.result_adapters import thermal_1d_result_bundle
  c=Thermal1DConfig(.1,4,1000,500,10.,(400.,300.,300.,300.),.1,.001)
  r=run_thermal_1d(c); b=thermal_1d_result_bundle(c,r)
  self.assertEqual(len(b.series),2)
  self.assertEqual(len(b.series[0].values),len(r.times_s)*c.cells)
  self.assertEqual(len(b.causal_changes),len(r.times_s)-1)
  self.assertEqual(b.causal_changes[0].before,list(r.temperatures_k[0]))
  self.assertEqual(b.causal_changes[0].after,list(r.temperatures_k[1]))
  self.assertFalse(b.metadata['experimental_validation'])
  self.assertEqual(b.sha256,thermal_1d_result_bundle(c,r).sha256)
 def test_adapter_rejects_mismatched_configuration(self):
  from vulc_physics.result_adapters import thermal_1d_result_bundle
  c=Thermal1DConfig(.1,4,1000,500,10.,(400.,300.,300.,300.),.1,.001)
  other=Thermal1DConfig(.1,4,1000,500,11.,(400.,300.,300.,300.),.1,.001)
  with self.assertRaises(ValueError): thermal_1d_result_bundle(other,run_thermal_1d(c))
