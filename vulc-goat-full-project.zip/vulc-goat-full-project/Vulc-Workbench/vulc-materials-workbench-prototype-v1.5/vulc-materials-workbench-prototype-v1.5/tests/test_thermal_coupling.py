import json, math, unittest
from vulc_physics.thermal_coupling import (
    ThermalBody, ThermalCouplingConfig, ThermalModelError,
    analytical_temperatures, run_thermal_coupling,
)

def config(dt=0.1, g=2.0):
    return ThermalCouplingConfig("thermal.demo", "1.0.0", ThermalBody("hot", 10.0, 400.0),
        ThermalBody("cold", 20.0, 300.0), g, 10.0, dt)

class ThermalCouplingTests(unittest.TestCase):
    def test_energy_conservation_and_equilibrium(self):
        c = ThermalCouplingConfig("thermal.demo", "1.0.0", ThermalBody("hot", 10.0, 400.0), ThermalBody("cold", 20.0, 300.0), 2.0, 60.0, 0.1)
        result = run_thermal_coupling(c)
        initial = 10*400 + 20*300
        self.assertLess(max(abs(s.energy_balance_error_j) for s in result.samples), 1e-8)
        self.assertAlmostEqual(result.samples[-1].temperature_a_k, 333.3333333333, places=5)
        self.assertAlmostEqual(result.samples[-1].temperature_b_k, 333.3333333333, places=5)
        self.assertAlmostEqual(10*result.samples[-1].temperature_a_k + 20*result.samples[-1].temperature_b_k, initial, places=8)
    def test_against_analytical_solution(self):
        c = config(dt=0.5)
        result = run_thermal_coupling(c)
        for s in result.samples:
            ta, tb = analytical_temperatures(c, s.time_s)
            self.assertAlmostEqual(s.temperature_a_k, ta, delta=2e-4)
            self.assertAlmostEqual(s.temperature_b_k, tb, delta=2e-4)
    def test_fourth_order_convergence(self):
        c1 = config(dt=1.0); c2 = config(dt=0.5)
        e1 = abs(run_thermal_coupling(c1).samples[-1].temperature_a_k - analytical_temperatures(c1,10)[0])
        e2 = abs(run_thermal_coupling(c2).samples[-1].temperature_a_k - analytical_temperatures(c2,10)[0])
        self.assertGreater(e1, 0)
        self.assertGreater(e1/e2, 10) # RK4 expected asymptotic ratio is ~16
    def test_zero_conductance(self):
        c = config(g=0.0); result = run_thermal_coupling(c)
        self.assertEqual(result.samples[0].temperature_a_k, result.samples[-1].temperature_a_k)
        self.assertEqual(result.samples[0].temperature_b_k, result.samples[-1].temperature_b_k)
    def test_serialized_result_is_valid_json_and_repeatable(self):
        a = run_thermal_coupling(config()); b = run_thermal_coupling(config())
        self.assertNotEqual(a.run_id, b.run_id)
        self.assertEqual(a.samples, b.samples)
        self.assertEqual(len(json.loads(a.to_json())["samples"]), 101)
        self.assertEqual(a.configuration_sha256, b.configuration_sha256)
    def test_result_bundle_contains_history_and_causal_changes(self):
        result = run_thermal_coupling(config(dt=1.0))
        bundle = result.to_result_bundle()
        self.assertEqual(len(bundle.series), 4)
        self.assertEqual(len(bundle.series[0].values), len(result.samples))
        self.assertEqual(len(bundle.causal_changes), 2 * (len(result.samples) - 1))
        self.assertIn('analytically_verified_for_stated_lumped_model', bundle.to_json())
    def test_invalid_config_rejected(self):
        with self.assertRaises(ThermalModelError): ThermalCouplingConfig("p","1",ThermalBody("a",1,300),ThermalBody("b",1,200),-1,1,.1)
        with self.assertRaises(ThermalModelError): ThermalCouplingConfig("p","1",ThermalBody("a",1,300),ThermalBody("b",1,200),1,1,.3)
    def test_conductance_nonnegative_and_temp_finite(self):
        with self.assertRaises(ThermalModelError): ThermalBody("a",1,float("nan"))
        with self.assertRaises(ThermalModelError): ThermalBody("a",1,-1)

if __name__ == "__main__": unittest.main()
