import unittest
from vulc_physics.thermal_interfaces import planar_interface_flux, ThermalInterfaceError
class ThermalInterfaceTests(unittest.TestCase):
 def test_equal_temperature_zero_flux(self):
  r=planar_interface_flux(300,300,10,1,.01,.01,0.2)
  self.assertEqual(r.heat_flux_w_m2,0)
 def test_contact_resistance_reduces_flux(self):
  a=planar_interface_flux(400,300,10,1,.01,.01,0)
  b=planar_interface_flux(400,300,10,1,.01,.01,.2)
  self.assertGreater(a.heat_flux_w_m2,b.heat_flux_w_m2)
  self.assertAlmostEqual(b.left_temperature_drop_k+b.contact_temperature_drop_k+b.right_temperature_drop_k,100)
 def test_flux_reverses_with_temperature(self):
  self.assertLess(planar_interface_flux(300,400,10,1,.01,.01).heat_flux_w_m2,0)
 def test_negative_resistance_rejected(self):
  with self.assertRaises(ThermalInterfaceError): planar_interface_flux(300,400,10,1,.01,.01,-1)
