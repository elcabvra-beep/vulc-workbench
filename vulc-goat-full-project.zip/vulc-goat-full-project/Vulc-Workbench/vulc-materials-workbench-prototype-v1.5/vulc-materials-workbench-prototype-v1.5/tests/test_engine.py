import math, unittest
from vulc_engine import *

class TestQuantity(unittest.TestCase):
    def test_add_same_dimension(self): self.assertEqual((Quantity(2,LENGTH)+Quantity(3,LENGTH)).value,5)
    def test_reject_add_incompatible(self):
        with self.assertRaises(DimensionError): Quantity(1,LENGTH)+Quantity(1,TIME)
    def test_compound_dimension(self): self.assertEqual((Quantity(10,FORCE)/Quantity(2,AREA)).dimension,PRESSURE)
    def test_reject_nonfinite(self):
        with self.assertRaises(ValueError): Quantity(float('nan'),TIME)

AREA=(0,2,0,0,0,0,0)
class TestIntegrators(unittest.TestCase):
    def test_rk4_exponential_convergence(self):
        y=(1.0,); t=0.; dt=.1
        for _ in range(10): y=rk4_step(lambda t,y:y,t,y,dt); t+=dt
        self.assertAlmostEqual(y[0],math.e,delta=3e-6)
    def test_euler_expected(self): self.assertAlmostEqual(euler_step(lambda t,y:(y[0],),0,(1,),.1)[0],1.1)
    def test_bad_dt(self):
        with self.assertRaises(IntegrationError): rk4_step(lambda t,y:y,0,(1,),0)
    def test_bad_derivative_length(self):
        with self.assertRaises(IntegrationError): rk4_step(lambda t,y:(1,2),0,(1,),.1)

class TestGraph(unittest.TestCase):
    def setUp(self):
        self.g=ProcessGraph()
        self.g.add_node(ProcessNode('a','test.source',ports={'force':Port('force',FORCE,'out')}))
        self.g.add_node(ProcessNode('b','test.target',ports={'load':Port('load',FORCE,'in')}))
    def test_valid_link(self):
        self.g.connect(Interaction('a','force','b','load')); self.assertEqual(len(self.g.active_links()),1)
    def test_reject_dimension_mismatch(self):
        self.g.nodes['b'].ports['load']=Port('load',PRESSURE,'in')
        with self.assertRaises(GraphError): self.g.connect(Interaction('a','force','b','load'))
    def test_disabled_link_not_active(self):
        self.g.connect(Interaction('a','force','b','load',enabled=False)); self.assertEqual(self.g.active_links(),())

if __name__=='__main__': unittest.main()
