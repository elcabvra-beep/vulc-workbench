import unittest
from vulc_engine.process_api import FieldType, ContractError
from vulc_engine.fields import FieldValue, FieldValueError

class FieldContractTests(unittest.TestCase):
 def test_global_scalar_port_value(self):
  f=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='global')
  v=FieldValue(f,(300.0,))
  self.assertTrue(v.is_scalar); self.assertEqual(v.values,(300.0,))
 def test_spatial_scalar_field_shape_and_coordinates(self):
  f=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='cell')
  v=FieldValue(f,(300.,301.,302.),shape=(3,),domain_id='rod',coordinates=((.1,),(.2,),(.3,)))
  self.assertFalse(v.is_scalar); self.assertEqual(v.shape,(3,))
 def test_unit_conversion_preserves_topology(self):
  a=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='cell')
  b=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='cell')
  v=FieldValue(a,(1.,2.),shape=(2,),domain_id='rod')
  self.assertEqual(v.converted(b).values,(1.,2.))
 def test_reject_shape_mismatch(self):
  f=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='cell')
  with self.assertRaises(FieldValueError): FieldValue(f,(1.,2.,3.),shape=(2,),domain_id='rod')
 def test_global_support_cannot_smuggle_array(self):
  f=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='global')
  with self.assertRaises(FieldValueError): FieldValue(f,(1.,2.),shape=(2,))

class FieldRuntimeTests(unittest.TestCase):
 def test_spatial_field_passes_through_identity_link(self):
  from vulc_engine.process_api import (PortContract, ModelContract, BoundaryMapping, BoundaryMappingKind,
      CouplingDirection, InteractionLink, ProcessDefinition, MaterialRef, DomainRef, Schedule)
  from vulc_engine.execution import ExecutableModelRegistry, execute_process
  f=FieldType('temperature','K',(0,0,0,0,1,0,0),spatial_support='cell')
  src=ModelContract('src','1','test','copy field',(),(),(),(PortContract('out','output',f),),'analytically_verified')
  dst=ModelContract('dst','1','test','consume field',(),(),(),(PortContract('in','input',f),PortContract('out','output',f)),'analytically_verified')
  link=InteractionLink('l','src','out','dst','in',CouplingDirection.ONE_WAY,BoundaryMapping(BoundaryMappingKind.IDENTITY,'d','d'))
  p=ProcessDefinition('p','1','field test','test',(MaterialRef('m','m'),),(DomainRef('d','m','global'),),(src,dst),(link,),Schedule())
  field=FieldValue(f,(300.,310.),shape=(2,),domain_id='d')
  r=ExecutableModelRegistry(); r.register_callable('src','1','src',lambda ctx:{'out':field}); r.register_callable('dst','1','dst',lambda ctx:{'out':ctx.inputs['in']})
  result=execute_process(p,r)
  self.assertEqual(result.outputs['dst']['out'].values,(300.,310.))
