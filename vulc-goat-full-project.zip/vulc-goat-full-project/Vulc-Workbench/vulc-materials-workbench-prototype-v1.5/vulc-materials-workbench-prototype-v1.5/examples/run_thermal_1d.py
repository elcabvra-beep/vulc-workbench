"""Run a small spatial heat-diffusion example; writes JSON into the current directory."""
from pathlib import Path
import sys, json
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from vulc_physics.thermal_1d import Thermal1DConfig, run_thermal_1d
from vulc_physics.result_adapters import thermal_1d_result_bundle

n=20; length=0.1; dx=length/n; rho=2700.0; cp=900.0; k=180.0
limit=0.5*rho*cp*dx*dx/k
dt=0.5*limit; duration=100*dt
initial=tuple(400.0 if i < n//2 else 300.0 for i in range(n))
result=run_thermal_1d(Thermal1DConfig(length,n,rho,cp,k,initial,duration,dt))
path=Path('thermal-1d-results.json'); path.write_text(result.to_json()+'\n',encoding='utf-8')
print(f'Wrote {len(result.times_s)} time samples x {len(result.x_cell_centers_m)} cell centers to {path.resolve()}')
print(f'Max energy accounting residual: {result.max_energy_residual_j_per_m2:.6g} J/m^2')
print(f'Configuration SHA-256: {result.configuration_sha256}')
bundle = thermal_1d_result_bundle(Thermal1DConfig(length,n,rho,cp,k,initial,duration,dt), result)
bundle_path = Path('thermal-1d-result-bundle.json')
bundle_path.write_text(bundle.to_json()+'\n', encoding='utf-8')
print(f'Wrote auditable result bundle to {bundle_path.resolve()}')
