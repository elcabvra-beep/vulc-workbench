from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from vulc_engine.goat_compiler import execute_goat_script
source = (ROOT / "examples" / "thermal_from_goat.goat").read_text(encoding="utf-8")
compiled, result = execute_goat_script(source)
print(json.dumps({"source_sha256": compiled.source_sha256, "model_alias": compiled.model_alias,
                  "process": compiled.process.to_dict(), "result": result.to_dict()}, indent=2, sort_keys=True))
