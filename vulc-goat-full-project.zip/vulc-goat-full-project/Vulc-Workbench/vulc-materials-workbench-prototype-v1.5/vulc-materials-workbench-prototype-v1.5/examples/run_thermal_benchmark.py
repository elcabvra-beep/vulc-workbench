"""Run the two-body thermal benchmark and write deterministic JSON results."""
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from vulc_physics.thermal_coupling import ThermalBody, ThermalCouplingConfig, run_thermal_coupling

config = ThermalCouplingConfig(
    process_id="thermal.two-body.benchmark",
    process_version="1.0.0",
    body_a=ThermalBody("body.hot", heat_capacity_j_k=10.0, initial_temperature_k=400.0),
    body_b=ThermalBody("body.cold", heat_capacity_j_k=20.0, initial_temperature_k=300.0),
    conductance_w_k=2.0,
    duration_s=10.0,
    timestep_s=0.1,
)
result = run_thermal_coupling(config)
output = Path("thermal-benchmark-results.json")
output.write_text(result.to_json() + "\n", encoding="utf-8")
print(f"Wrote {len(result.samples)} samples to {output.resolve()}")
print(f"Configuration SHA-256: {result.configuration_sha256}")
print(f"Final temperatures: A={result.samples[-1].temperature_a_k:.6f} K, B={result.samples[-1].temperature_b_k:.6f} K")
print(f"Maximum absolute energy-balance error: {max(abs(s.energy_balance_error_j) for s in result.samples):.6g} J")
