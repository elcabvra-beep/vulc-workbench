from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
"""Run the lumped thermal model through the Process API execution dispatcher."""
from vulc_engine.execution import ExecutableModelRegistry, execute_process
from vulc_engine.process_api import (
    DomainRef, FieldType, MaterialRef, ModelContract, OutputSpec, PortContract,
    ProcessDefinition, Schedule,
)
from vulc_engine.quantity import TEMPERATURE, ENERGY
from vulc_physics.thermal_coupling import MODEL_ID, MODEL_VERSION, register_thermal_coupling_model

SCALAR = "scalar"
GLOBAL = "global"
def inp(name, unit, dimension):
    return PortContract(name, "input", FieldType(name, unit, dimension, SCALAR, GLOBAL))
def out(name, unit, dimension):
    return PortContract(name, "output", FieldType(name, unit, dimension, SCALAR, GLOBAL))

ports = (
    inp("heat_capacity_a", "J/K", (1, 2, -2, 0, -1, 0, 0)),
    inp("initial_temperature_a", "K", TEMPERATURE),
    inp("heat_capacity_b", "J/K", (1, 2, -2, 0, -1, 0, 0)),
    inp("initial_temperature_b", "K", TEMPERATURE),
    inp("conductance", "W/K", (1, 2, -3, 0, -1, 0, 0)),
    inp("duration", "s", (0, 0, 1, 0, 0, 0, 0)),
    inp("timestep", "s", (0, 0, 1, 0, 0, 0, 0)),
    out("final_temperature_a", "K", TEMPERATURE),
    out("final_temperature_b", "K", TEMPERATURE),
    out("max_energy_balance_error", "J", ENERGY),
)
model = ModelContract(MODEL_ID, MODEL_VERSION, "lumped_thermal", "C_a dT_a/dt=-G(T_a-T_b); C_b dT_b/dt=+G(T_a-T_b)",
    ("Two spatially uniform bodies", "Constant heat capacities and conductance", "Isolated system"),
    ("Lumped-capacitance approximation only when physically justified",), (), ports, "analytically_verified")
process = ProcessDefinition(
    "process.thermal.two-body", "1.0.0", "Two-body thermal coupling", "thermal",
    (MaterialRef("material.a", "Body A"), MaterialRef("material.b", "Body B")),
    (DomainRef("domain.a", "material.a", "global"), DomainRef("domain.b", "material.b", "global")),
    (model,), (), Schedule(duration=10.0, time_unit="s", timestep_policy="fixed"),
    (OutputSpec("final_temperature_a"), OutputSpec("final_temperature_b"), OutputSpec("max_energy_balance_error")),
    {"purpose": "Process API to numerical model integration demonstration"},
)
registry = ExecutableModelRegistry()
register_thermal_coupling_model(registry)
result = execute_process(process, registry, initial_inputs={MODEL_ID: {
    "heat_capacity_a": 10.0, "initial_temperature_a": 400.0,
    "heat_capacity_b": 20.0, "initial_temperature_b": 300.0,
    "conductance": 2.0, "duration": 10.0, "timestep": 0.1,
}})
print(result.to_json())
