# Vulc Materials Workbench 0.8 — Auditable spatial results and scientific workbench prototype

Prototype 0.4 adds a versioned, validated, serializable Process API contract and an interactive browser editor. It preserves the 0.3 scientific-kernel primitives and equation-level models. This is still a research prototype: configuration validation is not physics execution or experimental validation.

## What's new

- **Validated process models:** `vulc_engine.process_api` defines `ProcessDefinition`, `MaterialRef`, `DomainRef`, `ModelContract`, `FieldType`, `PortContract`, `Schedule`, `OutputSpec`, `InteractionLink`, `BoundaryMapping`, `TimePolicy`, `SolverProfile`, and structured `Diagnostic` objects.
- **Serialization:** deterministic JSON via `ProcessDefinition.to_json()`, plus validated `from_json()` / `from_dict()` round-trips. Schema version is explicit (`1.0.0`); unsupported versions fail closed.
- **Dimensional contracts:** field units are checked against seven SI base-dimension exponents. Port links check source-output/target-input direction, dimensions, field kind, spatial mapping, declared domains, and unit-conversion requirements.
- **Explicit coupling:** one-way, two-way, observe-only, and event links; two-way links require an explicitly configured reverse link. No automatic assumption of reciprocity.
- **Boundary mapping:** identity, nearest-entity, conservative projection, interpolation, explicit map, or global-value mapping. Explicit mappings require a mapping ID.
- **Time semantics:** physical time, solver step, event sequence, or wall clock. Physical intervals/delays are deliberately disallowed for non-physical-time semantics.
- **Solver compatibility:** declared model/link capabilities are checked against a supplied `SolverProfile`; unsupported capabilities are errors, not silent fallbacks.
- **Evidence labeling:** model evidence states distinguish unvalidated, analytically verified, numerically verified, benchmark-compared, and experimentally validated. Unvalidated connected models generate warnings.
- **Causal-output settings:** process output specs can request provenance and change-set capture.
- **Browser editor:** open `index.html` via the local engine service to inspect/edit a JSON contract, run a limited client-side preflight, and request authoritative Python semantic validation. The editor does not execute the edited process physics.
- **JSON Schema:** `schemas/process-definition.schema.json` provides structural validation; Python validation adds cross-reference and semantic checks.
- **Example:** `examples/thermal_contact_process.json` is intentionally labeled a contract example, not a runnable thermal solver. Passing a temperature signal is not itself a heat-transfer constitutive law.

## Run tests

From this directory, using Python 3.10+:

```bash
python -m unittest discover -s tests -v
```

Expected at this release: **62 tests passing**.

## Validate and serialize a process

```python
from pathlib import Path
from vulc_engine.process_api import ProcessDefinition, SolverProfile

p = ProcessDefinition.from_json(Path("examples/thermal_contact_process.json").read_text())
print(p.to_json())
for diagnostic in p.validate(SolverProfile("example", frozenset({"ode_explicit"}), frozenset({"global"}))):
    print(diagnostic.to_dict())
```

`validate()` checks contract compatibility only. A `SolverProfile` is a declared capability set, not proof that a solver is installed or correct. The Process API contract itself does not implement a solver. The repository now includes limited independent coupling and spatial thermal primitives, described below.

## Contract and science limitations

- A dimensionally compatible connection is not necessarily a physically meaningful coupling law.
- Unit conversions are diagnosed but not applied by this metadata layer.
- Boundary maps are references/policies; the engine does not currently map numerical fields across meshes.
- Solver capability declarations do not implement solver algorithms.
- `two_way` requires a reverse link, but this does not establish numerical stability or convergence of a coupled feedback loop.
- The shared result/causal ledger exists, but generic Process API execution does not yet automatically emit spatial field change sets.
- This prototype is not validated engineering software and must not be used for safety-critical or production decisions.

## 0.5 development additions: execution planning and thermal benchmark

The engine now has an explicit, deterministic execution-plan compiler (`vulc_engine.execution`). It resolves model IDs and versions through an allow-listed `ModelRegistry`, validates the process contract before planning, sorts independent model nodes deterministically, excludes disabled links, and rejects dependency cycles until a declared iterative-coupling solver exists. The planner does not execute arbitrary plugin code and is not yet a general runtime dispatcher.

A first real numerical vertical slice is available in `vulc_physics.thermal_coupling`: two lumped isothermal bodies exchange heat through a supplied constant conductance. The model integrates equal-and-opposite heat flow with fixed-step classical RK4, emits a temperature history, reports energy-balance error, and serializes deterministic run results with a SHA-256 hash of the configuration. It includes a closed-form analytical solution for verification. This is a lumped ODE benchmark, not a spatial heat-transfer, contact-resistance, finite-element, or experimentally validated solver.

Run the benchmark from the project root:

```bash
python examples/run_thermal_benchmark.py
```

This writes `thermal-benchmark-results.json` to the current working directory. Run the full test suite with:

```bash
python -m unittest discover -s tests -v
```

The execution planner and thermal benchmark are presently adjacent building blocks, not yet automatically connected through a generic process-to-physics dispatcher. That integration is a subsequent milestone; do not treat a valid execution plan as proof that a physical simulation ran.


## 0.6: executing registered process models

`vulc_engine.execution` now includes `ExecutableModelRegistry` and `execute_process()`. A caller registers an explicit callable for each exact `(model_id, version)`; process contracts cannot load arbitrary code. The runtime validates and compiles an acyclic process, passes declared scalar inputs to implementations, transfers scalar outputs across supported global-value links, performs unit scaling through SI, and returns structured per-model records with inputs, outputs, timing, configuration SHA-256, timestamps, and diagnostics.

Minimal pattern:

```python
from vulc_engine.execution import ExecutableModelRegistry, execute_process

registry = ExecutableModelRegistry()
registry.register_callable(
    "constant.source", "1.0.0", "example.constant-source",
    lambda context: {"value": 12.0},
)
# Register implementations for every model in the process, then:
# result = execute_process(process_definition, registry)
# print(result.to_json())
```

The dispatcher currently executes scalar numeric fields only, supports `global_value` mappings and zero-delay physical-time links, and rejects unsupported semantics rather than approximating them. The lumped thermal model is now registered as an executable Process API model through `register_thermal_coupling_model()`. `examples/run_process_thermal.py` demonstrates contract → dispatcher → actual RK4 thermal run → serialized scalar result outputs. The full temperature history remains available from the direct thermal API; scalar Process API ports do not silently embed arrays. Execution timestamps are observational metadata, not part of the deterministic configuration hash. A model's callable must be deterministic itself if deterministic results are required.


## 0.7 engineering milestones

### Result histories and causal ledger
`vulc_engine.results` defines `ResultSeries`, `ResultBundle`, and `CausalChange`. Time series retain units and optional domain/model provenance; spatial series use flattened time-major values with explicit coordinates. Causal changes must identify a named model, domain, field, mechanism, and before/after values. The ledger records declared attribution; it does not infer causality automatically.

### Browser editor to Python engine
Run `python -m vulc_engine.service` from this directory and open `http://127.0.0.1:8765/index.html`. The new **Validate with Python engine** action sends the current contract to the local Python semantic validator. The service binds to loopback only and is a development bridge, not an authenticated/network-facing service.

### Coupled model execution primitive
`vulc_engine.coupling.solve_fixed_point` implements relaxed Picard iteration for `x = F(x)` with explicit absolute/relative tolerances, iteration records, and non-convergence errors. This does not yet provide a full co-simulation scheduler, rollback, subcycling, or a universal solver for stiff/non-contractive coupled systems.

### Spatial thermal model
`vulc_physics.thermal_1d` implements 1-D cell-centered finite-volume heat diffusion with constant density, heat capacity and conductivity; insulated end boundaries; optional uniform volumetric heat generation; and explicit Euler. It enforces the conservative 1-D stability bound `dt <= 0.5*rho*cp*dx^2/k`, emits the full temperature history and energy-per-area history, and reports the maximum energy-accounting residual. It is not yet wired as a spatial field kind in the generic Process API dispatcher. No contact resistance, multi-material interface, phase change, nonlinear properties, multidimensional geometry, or experimental validation is claimed.

### Numerical verification
Tests now cover fixed-point convergence and failure, spatial uniform-field preservation, diffusion behavior, insulated-domain energy conservation, and stability rejection in addition to the existing RK4 analytical-reference and convergence tests. Passing software tests verifies these stated checks only; it does not establish experimental validity.

Run the spatial thermal example from the project root with `python examples/run_thermal_1d.py`. It writes a JSON artifact containing every cell temperature at every time sample. The initial condition is illustrative, not an experimentally calibrated material configuration.


## 0.8: spatial thermal results become first-class artifacts

`vulc_physics.result_adapters.thermal_1d_result_bundle()` adapts the 1-D thermal solver's existing data into the shared `ResultBundle`: a time-major spatial temperature series with explicit cell-center coordinates, a total-energy-per-area series, and one full-field transition record per solver step. It verifies the configuration hash before exporting. The ledger deliberately records model-attributed transitions rather than claiming that chronology alone proves causality; conduction is spatially coupled, so per-cell causal isolation is not implied. The bundle includes model/version, method, boundary conditions, assumptions, numerical residual, configuration provenance, and an explicit non-experimental-validation status.

This architecture follows two useful external precedents: FMI separates model execution interfaces from the importer/co-simulation scheduler, and W3C PROV distinguishes entities, activities, and generated artifacts. Vulc is not claiming FMI or PROV conformance; these are design references. Sources: [FMI specification](https://fmi-standard.org/docs/main/) and [W3C PROV Primer](https://www.w3.org/TR/prov-primer/). For future solver verification, add method-of-manufactured-solutions tests in addition to analytical eigenmode and conservation checks; see [Roache, 2002](https://doi.org/10.1115/1.1436090) and [Sandia's MMS report](https://www.sandia.gov/research/publications/details/code-verification-by-the-method-of-manufactured-solutions-2000-06-01/).


Run `python examples/run_thermal_1d.py` to produce both the solver-native `thermal-1d-results.json` and the shared `thermal-1d-result-bundle.json`. The latter includes spatial coordinates, time-series channels, model-attributed field transitions, assumptions, and provenance metadata.

## 0.9 field contract and interface work

`vulc_engine.fields.FieldValue` is the transport representation for scalar-valued
spatial fields. It records the `FieldType`, shape, domain, optional coordinates,
and coordinate frame. Global and region scalar ports retain plain numeric values
for ergonomics and backwards compatibility. Spatial supports require `FieldValue`.
The runtime currently supports scalar-valued fields only: vector/tensor storage is
not implemented. Time histories use `ResultSeries`; time must not be smuggled into
field shape. Unit conversion preserves shape and support. `identity` mapping only
works where domain topology is genuinely identical; no implicit interpolation or
projection is performed.

`vulc_physics.thermal_interfaces.planar_interface_flux` implements the planar
series-resistance closure including optional contact resistance. It is unit-tested
and deliberately not claimed to be integrated into the transient spatial solver.

Research references informing architecture: [FMI](https://fmi-standard.org/docs/main/)
for separating model execution from scheduling, [W3C PROV](https://www.w3.org/TR/prov-primer/)
for artifact/activity/derivation provenance, and [MOOSE MMS documentation](https://cardinal.cels.anl.gov/python/mms.html)
for systematic manufactured-solution verification. These references inform design;
they do not constitute validation of Vulc.

Verification at this release: 74 automated tests pass, including a process-runtime
integration test that transfers a spatial field through a validated identity link.
This is software verification for the listed cases, not experimental validation.

## Script composer and typed parser (1.2 work in progress)

The standalone `script-composer.html` offers a browser-based declarative editor and a **Parse AST via engine** action. To use the engine-backed parser, start the local development bridge from this directory:

```bash
python -m vulc_engine.service
```

Then open `http://127.0.0.1:8765/script-composer.html`. `POST /api/parse` accepts `{"source":"..."}` and returns a typed syntax tree plus source-located diagnostics. The parser supports only the declared `material(...)`, `process(...)`, `factor(...)`, `connect(...)`, and `use(...)` subset. It does not run Python, JavaScript, shell commands, or arbitrary user code. The existing **Build process system** client-side preview is still a separate prototype path and is not yet a full AST-to-ProcessDefinition compiler. Do not treat parsing success as API compatibility or permission to execute a physical model.

### Run identity versus configuration identity
Each execution receives a unique `run_id` (`run-` plus a UUID). The `configuration_sha256` remains a deterministic hash of the process definition. These serve different purposes: the run ID identifies one invocation; the configuration hash identifies the exact serialized process configuration. Identical configurations can therefore be run repeatedly without conflating their result records.


## Test-run qualification

The current thermal examples are verification-oriented research models, not a general-purpose validated engineering solver. The GOAT parser produces an AST; it is not yet compiled into an executable process graph. Process definitions can be validated and manually constructed definitions can be dispatched to registered models. Material property source/uncertainty tracking is not yet implemented as a first-class registry.

## Experimental GOAT-to-solver path (v1.5)

A narrow, fail-closed GOAT declarative path now runs one registered lumped two-body thermal model end to end:

```sh
python examples/run_goat_thermal.py
```

The supported `process()` declaration must use model `thermal.two_body_lumped_conductance` and provide `heat_capacity_a`, `initial_temperature_a`, `heat_capacity_b`, `initial_temperature_b`, `conductance`, `duration`, and `timestep` as numeric values. Equivalent values can be provided as `factor("name", value=..., unit="...")` declarations. The compiler creates and validates a `ProcessDefinition`, then execution occurs only through an explicitly registered callable model implementation. Result JSON includes a unique run ID and stable configuration hash; the compiler separately records the source SHA-256.

**Limitations:** one process and one registered thermal model only. `connect()` and `use()` are parsed but rejected by compilation; they do not execute. There is no multi-model graph compiler, expansion/package resolver, general unit conversion, material-property provenance registry, or experimental validation. This is a developer preview, not a production engineering qualification.
