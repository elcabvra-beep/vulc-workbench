# Vulc / GOAT — licensing and ownership policy draft

**Status:** Draft for owner review; not legal advice. Do not describe the repository as fully open source until the final license files and third-party notices are in place.

## 1. Ownership

Copyright in original Vulc / GOAT materials remains with their respective copyright holders. The project owner retains copyright in original work they own. Publishing source code under an open-source license grants permissions; it does not transfer ownership or put the work in the public domain.

Before release, identify the owner using the chosen public attribution, for example:

`Copyright (c) 2026 [copyright holder / project owner].`

Do not claim ownership over third-party code, dependencies, contributions, or material for which the project owner does not hold the necessary rights.

## 2. Software license recommendation

For a permissive project that people can use, modify, redistribute, incorporate into commercial products, and build on, consider the standard **Apache License 2.0** for project-owned software. It preserves copyright notices and includes an express patent license. Use the unmodified, standard license text rather than a custom license. The license does not require downstream modified versions to be open source.

If the owner instead wants people who operate modified versions as network services to make the corresponding source available to users, evaluate the standard **GNU AGPLv3** before choosing. This has different obligations and may affect adoption. Do not combine these approaches casually; choose deliberately and have a qualified lawyer review the release plan if commercial licensing is important.

Official references:
- Apache-2.0: https://www.apache.org/licenses/LICENSE-2.0
- Applying Apache-2.0: https://apache.org/legal/apply-license.html
- GNU license overview: https://www.gnu.org/licenses/licenses.html.en
- Open Source Initiative FAQ: https://opensource.org/faq

## 3. Generated output and user content

The project should not claim ownership of users' independently created output merely because they used Vulc / GOAT. Subject to applicable law and any separate agreement, users retain whatever rights they have in their inputs and outputs. The software license applies to the software itself; it does not automatically determine the copyright status of every generated result.

Users must still respect third-party data, input licenses, privacy, database terms, and any restrictions applicable to material they supply. Do not promise that every generated output is copyrightable, unique, accurate, or free of third-party rights.

## 4. Documentation, examples, and other content

Choose a separate content license for documentation, tutorials, diagrams, and other non-software works. A possible choice is **Creative Commons Attribution 4.0 International (CC BY 4.0)** if the owner wants reuse and adaptation with attribution, including commercial reuse. Keep software under a software-specific license; Creative Commons advises against using its licenses for software.

Official reference: https://creativecommons.org/faq/

## 5. Contributions

Contributors retain copyright in their original contributions unless a separate written agreement says otherwise. Before accepting substantial outside contributions, publish a clear contribution policy and decide whether contributions will be accepted under the same project license or under a contributor license agreement. Do not ask contributors to assign copyright by default if the goal is simply to let the project maintain and distribute their contributions.

Keep third-party notices and licenses. Only relicense material when the project has the rights required to do so.

## 6. Community invitation is separate from the software license

The invitation to have conversations, visit, or spend informal time with collaborators is voluntary and social, not a condition of receiving or using the software. It creates no obligation to host, provide travel or accommodation, offer employment, provide support, or spend time. Include it in the README, community page, or outreach email—not in the open-source license itself.

See `COMMUNITY_INVITATION.md` for suggested wording.

## 7. Release checklist

- [ ] Confirm the copyright-holder name or attribution to publish.
- [ ] Audit dependencies and existing code for third-party ownership and licenses.
- [ ] Select one standard software license and include its complete, unmodified text as `LICENSE`.
- [ ] Select a separate license for documentation and other content if needed.
- [ ] Add third-party notices and a contribution policy.
- [ ] State clearly that user-created output is not claimed by the project solely because the software generated it.
- [ ] Have a qualified lawyer review the final setup if dual licensing, patent strategy, commercial offerings, or contributor rights are material.
