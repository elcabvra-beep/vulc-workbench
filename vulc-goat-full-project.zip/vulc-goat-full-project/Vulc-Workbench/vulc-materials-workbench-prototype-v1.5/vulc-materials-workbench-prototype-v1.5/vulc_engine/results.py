"""Typed result channels and causal change ledger for scientific runs.

This layer stores data/provenance; it does not infer causality from temporal order.
A causal event must name the model, affected domain/field, and changed values.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Mapping
import hashlib, json, math

class ResultArtifactError(ValueError): pass

@dataclass(frozen=True, slots=True)
class ResultSeries:
    series_id: str
    field_name: str
    unit: str
    times_s: tuple[float, ...]
    values: tuple[float, ...]
    domain_id: str | None = None
    model_id: str | None = None
    spatial_coordinates_m: tuple[float, ...] | None = None
    def __post_init__(self):
        if not self.series_id or not self.field_name or not self.unit: raise ResultArtifactError('series_id, field_name and unit are required')
        if not self.times_s: raise ResultArtifactError('time array must be nonempty')
        if any(not math.isfinite(float(x)) for x in (*self.times_s, *self.values)): raise ResultArtifactError('series values must be finite')
        if any(b <= a for a,b in zip(self.times_s, self.times_s[1:])): raise ResultArtifactError('times must be strictly increasing')
        if self.spatial_coordinates_m is not None:
            if not self.spatial_coordinates_m or any(not math.isfinite(float(x)) for x in self.spatial_coordinates_m): raise ResultArtifactError('spatial coordinates must be finite and nonempty')
            if any(b <= a for a,b in zip(self.spatial_coordinates_m, self.spatial_coordinates_m[1:])): raise ResultArtifactError('spatial coordinates must be strictly increasing')
            if len(self.values) != len(self.times_s)*len(self.spatial_coordinates_m): raise ResultArtifactError('spatial values must be flattened time-major (time_count * coordinate_count)')
        elif len(self.times_s) != len(self.values):
            raise ResultArtifactError('non-spatial time/value arrays must have equal length')
    def to_dict(self): return asdict(self)

@dataclass(frozen=True, slots=True)
class CausalChange:
    change_id: str
    time_s: float
    cause_model_id: str
    domain_id: str
    field_name: str
    before: Any
    after: Any
    mechanism: str
    assumptions: tuple[str, ...] = ()
    evidence_refs: tuple[str, ...] = ()
    def __post_init__(self):
        if not self.change_id or not self.cause_model_id or not self.domain_id or not self.field_name or not self.mechanism: raise ResultArtifactError('causal change requires ID, cause, domain, field and mechanism')
        if not math.isfinite(float(self.time_s)) or self.time_s < 0: raise ResultArtifactError('change time must be finite and >= 0')

@dataclass(frozen=True, slots=True)
class ResultBundle:
    run_id: str
    process_id: str
    process_version: str
    configuration_sha256: str
    series: tuple[ResultSeries, ...]
    causal_changes: tuple[CausalChange, ...]
    metadata: Mapping[str, Any]
    def to_dict(self):
        return {'schema_version':'1.0.0','run_id':self.run_id,'process_id':self.process_id,'process_version':self.process_version,'configuration_sha256':self.configuration_sha256,'series':[s.to_dict() for s in self.series],'causal_changes':[asdict(c) for c in self.causal_changes],'metadata':dict(self.metadata)}
    def to_json(self, indent=2): return json.dumps(self.to_dict(), sort_keys=True, indent=indent, allow_nan=False)
    @property
    def sha256(self): return hashlib.sha256(self.to_json(indent=None).encode()).hexdigest()
