"""Local development bridge between the browser editor and Python contract engine.
Run from the project root: python -m vulc_engine.service
Binds only to 127.0.0.1; not intended as a network-facing production service.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import json
from vulc_engine.process_api import ProcessDefinition, ContractError
from vulc_engine.execution import ExecutionPlanError, ModelRegistry, compile_execution_plan
from vulc_engine.goat_script import parse_script

ROOT=Path(__file__).resolve().parent.parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(ROOT),**kwargs)
    def _json(self,code,payload):
        body=json.dumps(payload,sort_keys=True,indent=2,allow_nan=False).encode()
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(body))); self.send_header('Access-Control-Allow-Origin','http://127.0.0.1:8765'); self.end_headers(); self.wfile.write(body)
    def do_POST(self):
        if self.path not in ('/api/validate','/api/plan','/api/parse'):
            self._json(404,{'error':'not_found'}); return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>2_000_000: self._json(413,{'error':'request_size_invalid'}); return
            data=json.loads(self.rfile.read(length))
            if self.path == '/api/parse':
                if not isinstance(data, dict) or not isinstance(data.get('source'), str):
                    self._json(400, {'error':'invalid_request','message':'Expected JSON object with string field source.'}); return
                parsed = parse_script(data['source'])
                self._json(200, parsed.to_dict()); return
            process=ProcessDefinition.from_dict(data)
            diagnostics=[d.to_dict() for d in process.validate()]
            errors=[d for d in diagnostics if d['severity']=='error']
            result={'process_id':process.process_id,'version':process.version,'valid':not errors,'diagnostics':diagnostics,'note':'Contract validation only; no physics has been executed.'}
            if self.path=='/api/plan' and not errors:
                try: result['plan']=compile_execution_plan(process,ModelRegistry()).to_dict()
                except ExecutionPlanError as exc: result['plan_error']=str(exc)
            self._json(200,result)
        except (json.JSONDecodeError,ContractError,KeyError,TypeError,ValueError) as exc:
            self._json(400,{'valid':False,'error':type(exc).__name__,'message':str(exc)})
    def log_message(self,fmt,*args): print('%s - %s' % (self.address_string(),fmt%args))

def main():
    print('Vulc local editor/engine bridge: http://127.0.0.1:8765/index.html')
    print('Loopback only. Do not expose this development server to a network.')
    ThreadingHTTPServer(('127.0.0.1',8765),Handler).serve_forever()
if __name__=='__main__': main()
