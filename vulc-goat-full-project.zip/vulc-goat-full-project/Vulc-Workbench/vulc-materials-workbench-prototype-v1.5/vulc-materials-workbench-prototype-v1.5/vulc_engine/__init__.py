"""Lean Vulc scientific execution primitives; no third-party runtime dependencies."""
from .quantity import *
from .integrators import euler_step, rk4_step, IntegrationError
from .graph import Port, ProcessNode, Interaction, ProcessGraph, GraphError

# Versioned process API contracts (configuration validation, not physics execution).
from .process_api import (
    ContractError, Severity, CouplingDirection, TimeSemantics, BoundaryMappingKind,
    Diagnostic, FieldType, PortContract, ModelContract, BoundaryMapping, TimePolicy,
    SolverProfile, InteractionLink, MaterialRef, DomainRef, Schedule, OutputSpec,
    ProcessDefinition,
)
from .execution import (ExecutionPlanError, ExecutionStep, ExecutionPlan, ModelRegistry, compile_execution_plan,
                        ModelExecutionError, ModelExecutionContext, ModelExecutionRecord, ExecutionResult,
                        ExecutableModelRegistry, execute_process)
from .results import ResultArtifactError, ResultSeries, CausalChange, ResultBundle
from .coupling import CouplingConvergenceError, CouplingIteration, CouplingResult, solve_fixed_point

from .fields import FieldValue, FieldValueError
from vulc_physics.thermal_interfaces import *

from .goat_script import parse_script, ParseResult, ScriptAST
