"""Typed process graph metadata; graph validation is structural, not a physics solver."""
from __future__ import annotations
from dataclasses import dataclass, field
from .quantity import Dimension

class GraphError(ValueError): pass

@dataclass(frozen=True, slots=True)
class Port:
    name: str
    dimension: Dimension
    direction: str  # 'in' or 'out'

    def __post_init__(self):
        if not self.name.strip(): raise GraphError("port name cannot be empty")
        if self.direction not in {"in", "out"}: raise GraphError("port direction must be 'in' or 'out'")

@dataclass(slots=True)
class ProcessNode:
    node_id: str
    model_id: str
    enabled: bool = True
    ports: dict[str, Port] = field(default_factory=dict)

@dataclass(frozen=True, slots=True)
class Interaction:
    source_node: str
    source_port: str
    target_node: str
    target_port: str
    mode: str = "feed_forward"
    enabled: bool = True

class ProcessGraph:
    """Connections require matching dimensions and output-to-input direction."""
    MODES = {"feed_forward", "feedback", "event", "observe_only"}
    def __init__(self): self.nodes: dict[str, ProcessNode] = {}; self.links: list[Interaction] = []
    def add_node(self, node: ProcessNode) -> None:
        if not node.node_id or node.node_id in self.nodes: raise GraphError(f"duplicate/empty node id: {node.node_id!r}")
        for key,port in node.ports.items():
            if key != port.name: raise GraphError("port dictionary key must match port.name")
        self.nodes[node.node_id] = node
    def connect(self, link: Interaction) -> None:
        if link.mode not in self.MODES: raise GraphError(f"unsupported interaction mode: {link.mode}")
        try:
            source=self.nodes[link.source_node]; target=self.nodes[link.target_node]
            out=source.ports[link.source_port]; inp=target.ports[link.target_port]
        except KeyError as exc: raise GraphError(f"unknown node or port: {exc}") from exc
        if out.direction != "out" or inp.direction != "in": raise GraphError("connections must run from output port to input port")
        if out.dimension != inp.dimension: raise GraphError(f"dimension mismatch: {out.dimension} != {inp.dimension}")
        self.links.append(link)
    def active_links(self) -> tuple[Interaction, ...]:
        return tuple(link for link in self.links if link.enabled and self.nodes[link.source_node].enabled and self.nodes[link.target_node].enabled)
