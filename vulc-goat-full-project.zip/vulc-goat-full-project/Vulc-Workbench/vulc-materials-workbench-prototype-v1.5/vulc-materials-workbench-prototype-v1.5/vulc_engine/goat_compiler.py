"""Fail-closed GOAT declarative compiler for the first executable thermal workflow.

This is intentionally a narrow bridge, not a general-purpose compiler. It maps one
GOAT process declaration to a validated ProcessDefinition and relies on the explicit
model registry for execution. It never evaluates arbitrary code.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping

from .goat_script import parse_script, MaterialDecl, ProcessDecl, FactorDecl, ConnectionDecl, UseDecl
from .process_api import (DomainRef, FieldType, MaterialRef, ModelContract, OutputSpec,
                          PortContract, ProcessDefinition, Schedule, ContractError)
from .quantity import TEMPERATURE, ENERGY
from .execution import ExecutableModelRegistry, ExecutionResult, execute_process
from vulc_physics.thermal_coupling import MODEL_ID, MODEL_VERSION, register_thermal_coupling_model

HEAT_CAPACITY = (1, 2, -2, 0, -1, 0, 0)
CONDUCTANCE = (1, 2, -3, 0, -1, 0, 0)
TIME = (0, 0, 1, 0, 0, 0, 0)

@dataclass(frozen=True)
class CompiledGOAT:
    process: ProcessDefinition
    initial_inputs: Mapping[str, Mapping[str, Any]]
    source_sha256: str
    model_alias: str


def _port(name: str, direction: str, unit: str, dimension: tuple[int, ...]) -> PortContract:
    return PortContract(name, direction, FieldType(name, unit, dimension, "scalar", "global"))


def _thermal_contract() -> ModelContract:
    ports = (
        _port("heat_capacity_a", "input", "J/K", HEAT_CAPACITY),
        _port("initial_temperature_a", "input", "K", TEMPERATURE),
        _port("heat_capacity_b", "input", "J/K", HEAT_CAPACITY),
        _port("initial_temperature_b", "input", "K", TEMPERATURE),
        _port("conductance", "input", "W/K", CONDUCTANCE),
        _port("duration", "input", "s", TIME),
        _port("timestep", "input", "s", TIME),
        _port("final_temperature_a", "output", "K", TEMPERATURE),
        _port("final_temperature_b", "output", "K", TEMPERATURE),
        _port("max_energy_balance_error", "output", "J", ENERGY),
    )
    return ModelContract(MODEL_ID, MODEL_VERSION, "lumped_thermal",
        "C_a dT_a/dt=-G(T_a-T_b); C_b dT_b/dt=+G(T_a-T_b)",
        ("Two spatially uniform bodies", "Constant heat capacities and conductance", "Isolated system"),
        ("Lumped-capacitance approximation only when physically justified",), (), ports,
        "analytically_verified")

_EXPECTED_UNITS = {"heat_capacity_a":"J/K", "initial_temperature_a":"K",
    "heat_capacity_b":"J/K", "initial_temperature_b":"K", "conductance":"W/K",
    "duration":"s", "timestep":"s"}
_REQUIRED = set(_EXPECTED_UNITS)


def compile_goat_script(source: str) -> CompiledGOAT:
    """Compile the supported single-model thermal subset; unsupported constructs fail closed."""
    import hashlib
    parsed = parse_script(source)
    if not parsed.ok:
        details = "; ".join(f"{d.code} line {d.span.line}: {d.message}" for d in parsed.diagnostics if d.severity == "error")
        raise ValueError("GOAT parse failed: " + details)
    materials: list[MaterialDecl] = []
    processes: list[ProcessDecl] = []
    factors: dict[str, FactorDecl] = {}
    for node in parsed.ast.statements:
        if isinstance(node, MaterialDecl): materials.append(node)
        elif isinstance(node, ProcessDecl): processes.append(node)
        elif isinstance(node, FactorDecl):
            if node.name in factors: raise ValueError(f"duplicate factor {node.name!r}")
            factors[node.name] = node
        elif isinstance(node, (ConnectionDecl, UseDecl)):
            raise ValueError(f"{node.kind} is parsed but not yet executable; compilation fails closed at line {node.span.line}")
    if len(processes) != 1:
        raise ValueError(f"this compiler requires exactly one process declaration; received {len(processes)}")
    decl = processes[0]
    if decl.arguments.get("model") != MODEL_ID:
        raise ValueError(f"unsupported model {decl.arguments.get('model')!r}; registered GOAT target is {MODEL_ID!r}")
    allowed = {"model", "duration", "timestep", *_REQUIRED}
    unknown = set(decl.arguments) - allowed
    if unknown: raise ValueError("unsupported process argument(s): " + ", ".join(sorted(unknown)))
    inputs = {k: v for k, v in decl.arguments.items() if k in _REQUIRED}
    for name, factor in factors.items():
        if name not in _REQUIRED: raise ValueError(f"factor {name!r} is not an input of {MODEL_ID}")
        if name in inputs: raise ValueError(f"input {name!r} is specified both in process() and factor()")
        unit = factor.arguments.get("unit")
        value = factor.arguments.get("value")
        if unit != _EXPECTED_UNITS[name]:
            raise ValueError(f"factor {name!r} requires unit {_EXPECTED_UNITS[name]!r}; received {unit!r}; implicit unit conversion is not supported")
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"factor {name!r} value must be numeric")
        inputs[name] = value
    missing = sorted(_REQUIRED - set(inputs))
    if missing: raise ValueError("missing required thermal input(s): " + ", ".join(missing))
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in inputs.values()):
        raise ValueError("all thermal inputs must be numeric; strings and booleans are not executable values")
    duration = decl.arguments.get("duration", inputs["duration"])
    timestep = decl.arguments.get("timestep", inputs["timestep"])
    if duration != inputs["duration"]:
        raise ValueError("duration must be specified once, as the runtime input duration")
    if timestep != inputs["timestep"]:
        raise ValueError("timestep must be specified once, as the runtime input timestep")
    material_names = [m.name for m in materials]
    if len(material_names) != len(set(material_names)): raise ValueError("duplicate material declaration")
    if not material_names: material_names = ["body_a", "body_b"]
    if len(material_names) != 2: raise ValueError("two-body thermal model requires exactly two material declarations")
    material_refs = tuple(MaterialRef(f"material.{i+1}", name) for i, name in enumerate(material_names))
    domains = tuple(DomainRef(f"domain.{i+1}", material_refs[i].material_id, "global") for i in range(2))
    pid = decl.process_id if decl.process_id.startswith("process.") else f"process.{decl.process_id}"
    process = ProcessDefinition(pid, "1.0.0", f"GOAT process {decl.process_id}", "thermal",
        material_refs, domains, (_thermal_contract(),), (),
        Schedule(duration=float(duration), time_unit="s", timestep_policy="fixed"),
        (OutputSpec("final_temperature_a", capture="final_only"),
         OutputSpec("final_temperature_b", capture="final_only"),
         OutputSpec("max_energy_balance_error", capture="final_only")),
        {"source_language": parsed.ast.language, "source_version": parsed.ast.version,
         "compiler": "vulc_engine.goat_compiler/0.1", "model_evidence_status": "analytically_verified"})
    diagnostics = process.validate()
    errors = [d for d in diagnostics if d.severity.value == "error"]
    if errors: raise ContractError("compiled process validation failed: " + "; ".join(d.message for d in errors))
    return CompiledGOAT(process, {MODEL_ID: dict(inputs)}, hashlib.sha256(source.encode("utf-8")).hexdigest(), decl.alias)


def execute_goat_script(source: str, registry: ExecutableModelRegistry | None = None) -> tuple[CompiledGOAT, ExecutionResult]:
    """Compile then execute only through the allow-listed model registry."""
    compiled = compile_goat_script(source)
    if registry is None:
        registry = ExecutableModelRegistry()
        register_thermal_coupling_model(registry)
    result = execute_process(compiled.process, registry, compiled.initial_inputs)
    return compiled, result
