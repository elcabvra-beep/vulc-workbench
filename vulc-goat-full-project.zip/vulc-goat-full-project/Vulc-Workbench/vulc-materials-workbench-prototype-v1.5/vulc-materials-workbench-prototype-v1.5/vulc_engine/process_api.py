"""Validated, serializable process API contracts for the Vulc scientific kernel.

This module validates configuration and coupling compatibility. It does not execute
physics or claim that a selected model is scientifically validated.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from enum import Enum
import json
import math
from typing import Any, Mapping

from .quantity import Dimension, DIMENSIONLESS, MASS, LENGTH, TIME, CURRENT, TEMPERATURE, VELOCITY, ACCELERATION, FORCE, ENERGY, PRESSURE, POWER


class ContractError(ValueError):
    """Invalid process API contract or serialized representation."""


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class CouplingDirection(str, Enum):
    ONE_WAY = "one_way"
    TWO_WAY = "two_way"
    OBSERVE_ONLY = "observe_only"
    EVENT = "event"


class TimeSemantics(str, Enum):
    PHYSICAL_TIME = "physical_time"
    SOLVER_STEP = "solver_step"
    EVENT_SEQUENCE = "event_sequence"
    WALL_CLOCK = "wall_clock"


class BoundaryMappingKind(str, Enum):
    IDENTITY = "identity"
    NEAREST = "nearest_entity"
    CONSERVATIVE = "conservative_projection"
    INTERPOLATION = "interpolation"
    EXPLICIT = "explicit_map"
    GLOBAL = "global_value"


@dataclass(frozen=True, slots=True)
class Diagnostic:
    code: str
    severity: Severity
    message: str
    path: str = ""
    remediation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "severity": self.severity.value, "message": self.message,
                "path": self.path, "remediation": self.remediation}


# SI scale factors are exact where defined; units are canonical API symbols.
_UNIT_TABLE: dict[str, tuple[float, Dimension]] = {
    "1": (1.0, DIMENSIONLESS), "kg": (1.0, MASS), "g": (1e-3, MASS),
    "m": (1.0, LENGTH), "mm": (1e-3, LENGTH), "cm": (1e-2, LENGTH),
    "s": (1.0, TIME), "ms": (1e-3, TIME), "min": (60.0, TIME),
    "A": (1.0, CURRENT), "K": (1.0, TEMPERATURE),
    "m/s": (1.0, VELOCITY), "m/s^2": (1.0, ACCELERATION),
    "N": (1.0, FORCE), "kN": (1e3, FORCE), "J": (1.0, ENERGY),
    "Pa": (1.0, PRESSURE), "kPa": (1e3, PRESSURE), "MPa": (1e6, PRESSURE),
    "W": (1.0, POWER), "kW": (1e3, POWER),
    "J/K": (1.0, (1, 2, -2, 0, -1, 0, 0)),
    "W/K": (1.0, (1, 2, -3, 0, -1, 0, 0)),
}


def _finite(value: float, label: str) -> None:
    if not math.isfinite(float(value)):
        raise ContractError(f"{label} must be finite")


def _nonempty(value: str, label: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{label} cannot be empty")


def _enum_value(value: Any, enum: type[Enum], label: str):
    try:
        return value if isinstance(value, enum) else enum(value)
    except ValueError as exc:
        raise ContractError(f"unsupported {label}: {value!r}") from exc


@dataclass(frozen=True, slots=True)
class FieldType:
    """Field contract; dimension uses kg,m,s,A,K,mol,cd SI exponents."""
    name: str
    unit: str
    dimension: Dimension
    value_kind: str = "scalar"  # scalar, vector, tensor, discrete, event
    spatial_support: str = "cell"  # point, cell, face, particle, grain, region, global
    coordinate_frame: str | None = None

    def __post_init__(self):
        _nonempty(self.name, "field name")
        if self.unit not in _UNIT_TABLE:
            raise ContractError(f"unknown unit {self.unit!r}; add a reviewed unit definition")
        if tuple(self.dimension) != _UNIT_TABLE[self.unit][1]:
            raise ContractError(f"unit {self.unit!r} does not match declared dimension for field {self.name!r}")
        if self.value_kind not in {"scalar", "vector", "tensor", "discrete", "event"}:
            raise ContractError(f"unsupported value_kind: {self.value_kind}")
        if self.spatial_support not in {"point", "cell", "face", "particle", "grain", "region", "global"}:
            raise ContractError(f"unsupported spatial_support: {self.spatial_support}")
        if self.value_kind in {"vector", "tensor"} and not self.coordinate_frame:
            raise ContractError(f"{self.value_kind} field {self.name!r} requires a coordinate frame")

    @property
    def scale_to_si(self) -> float:
        return _UNIT_TABLE[self.unit][0]

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "unit": self.unit, "dimension": list(self.dimension),
                "value_kind": self.value_kind, "spatial_support": self.spatial_support,
                "coordinate_frame": self.coordinate_frame}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "FieldType":
        return cls(name=data["name"], unit=data["unit"], dimension=tuple(data["dimension"]),
                   value_kind=data.get("value_kind", "scalar"), spatial_support=data.get("spatial_support", "cell"),
                   coordinate_frame=data.get("coordinate_frame"))


@dataclass(frozen=True, slots=True)
class PortContract:
    name: str
    direction: str  # input or output
    field: FieldType
    required: bool = True

    def __post_init__(self):
        _nonempty(self.name, "port name")
        if self.direction not in {"input", "output"}:
            raise ContractError("port direction must be 'input' or 'output'")

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "direction": self.direction, "field": self.field.to_dict(), "required": self.required}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PortContract":
        return cls(data["name"], data["direction"], FieldType.from_dict(data["field"]), data.get("required", True))


@dataclass(frozen=True, slots=True)
class ModelContract:
    model_id: str
    version: str
    family: str
    equation_reference: str
    assumptions: tuple[str, ...]
    applicability: tuple[str, ...]
    solver_requirements: tuple[str, ...]
    ports: tuple[PortContract, ...]
    evidence_status: str = "unvalidated"

    def __post_init__(self):
        for name in ("model_id", "version", "family", "equation_reference"):
            _nonempty(getattr(self, name), name)
        if self.evidence_status not in {"unvalidated", "analytically_verified", "numerically_verified", "benchmark_compared", "experimentally_validated"}:
            raise ContractError(f"unsupported evidence_status: {self.evidence_status}")
        names = [p.name for p in self.ports]
        if len(names) != len(set(names)):
            raise ContractError(f"duplicate ports in model {self.model_id}")

    def to_dict(self) -> dict[str, Any]:
        return {"model_id": self.model_id, "version": self.version, "family": self.family,
                "equation_reference": self.equation_reference, "assumptions": list(self.assumptions),
                "applicability": list(self.applicability), "solver_requirements": list(self.solver_requirements),
                "ports": [p.to_dict() for p in self.ports], "evidence_status": self.evidence_status}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ModelContract":
        return cls(data["model_id"], data["version"], data["family"], data["equation_reference"],
                   tuple(data.get("assumptions", ())), tuple(data.get("applicability", ())),
                   tuple(data.get("solver_requirements", ())), tuple(PortContract.from_dict(p) for p in data.get("ports", ())),
                   data.get("evidence_status", "unvalidated"))


@dataclass(frozen=True, slots=True)
class BoundaryMapping:
    kind: BoundaryMappingKind
    source_domain: str
    target_domain: str
    source_selector: str = "all"
    target_selector: str = "all"
    mapping_id: str | None = None

    def __post_init__(self):
        object.__setattr__(self, "kind", _enum_value(self.kind, BoundaryMappingKind, "boundary mapping"))
        _nonempty(self.source_domain, "source domain")
        _nonempty(self.target_domain, "target domain")
        _nonempty(self.source_selector, "source selector")
        _nonempty(self.target_selector, "target selector")
        if self.kind == BoundaryMappingKind.EXPLICIT and not self.mapping_id:
            raise ContractError("explicit boundary mapping requires mapping_id")

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind.value, "source_domain": self.source_domain, "target_domain": self.target_domain,
                "source_selector": self.source_selector, "target_selector": self.target_selector, "mapping_id": self.mapping_id}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "BoundaryMapping":
        return cls(_enum_value(data["kind"], BoundaryMappingKind, "boundary mapping"), data["source_domain"], data["target_domain"],
                   data.get("source_selector", "all"), data.get("target_selector", "all"), data.get("mapping_id"))


@dataclass(frozen=True, slots=True)
class TimePolicy:
    semantics: TimeSemantics = TimeSemantics.PHYSICAL_TIME
    update_policy: str = "each_accepted_step"  # each_accepted_step, interval, event, manual
    interval: float | None = None
    interval_unit: str = "s"
    delay: float = 0.0
    delay_unit: str = "s"
    interpolation: str = "none"  # none, hold, linear
    stale_data_policy: str = "error"  # error, warn, hold_last

    def __post_init__(self):
        object.__setattr__(self, "semantics", _enum_value(self.semantics, TimeSemantics, "time semantics"))
        if self.update_policy not in {"each_accepted_step", "interval", "event", "manual"}:
            raise ContractError("unsupported update_policy")
        if self.update_policy == "interval" and (self.interval is None or self.interval <= 0):
            raise ContractError("interval update policy requires interval > 0")
        for v, label in ((self.interval, "interval"), (self.delay, "delay")):
            if v is not None: _finite(v, label)
        if self.delay < 0: raise ContractError("delay cannot be negative")
        if self.interval_unit not in _UNIT_TABLE or _UNIT_TABLE[self.interval_unit][1] != TIME:
            raise ContractError("interval_unit must be a recognized time unit")
        if self.delay_unit not in _UNIT_TABLE or _UNIT_TABLE[self.delay_unit][1] != TIME:
            raise ContractError("delay_unit must be a recognized time unit")
        if self.semantics != TimeSemantics.PHYSICAL_TIME and (self.interval is not None or self.delay != 0):
            raise ContractError("physical intervals/delays are only supported with physical_time semantics")
        if self.interpolation not in {"none", "hold", "linear"}: raise ContractError("unsupported interpolation")
        if self.stale_data_policy not in {"error", "warn", "hold_last"}: raise ContractError("unsupported stale_data_policy")

    def to_dict(self) -> dict[str, Any]:
        return {"semantics": self.semantics.value, "update_policy": self.update_policy, "interval": self.interval,
                "interval_unit": self.interval_unit, "delay": self.delay, "delay_unit": self.delay_unit,
                "interpolation": self.interpolation, "stale_data_policy": self.stale_data_policy}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "TimePolicy":
        return cls(_enum_value(data.get("semantics", "physical_time"), TimeSemantics, "time semantics"),
                   data.get("update_policy", "each_accepted_step"), data.get("interval"), data.get("interval_unit", "s"),
                   data.get("delay", 0.0), data.get("delay_unit", "s"), data.get("interpolation", "none"),
                   data.get("stale_data_policy", "error"))


@dataclass(frozen=True, slots=True)
class SolverProfile:
    solver_id: str
    capabilities: frozenset[str]
    supported_spatial_supports: frozenset[str] = frozenset({"global", "region"})

    def __post_init__(self):
        _nonempty(self.solver_id, "solver_id")


@dataclass(frozen=True, slots=True)
class InteractionLink:
    link_id: str
    source_model: str
    source_port: str
    target_model: str
    target_port: str
    direction: CouplingDirection
    boundary_mapping: BoundaryMapping
    time_policy: TimePolicy = field(default_factory=TimePolicy)
    enabled: bool = True
    required_capabilities: frozenset[str] = frozenset()
    notes: str = ""

    def __post_init__(self):
        for name in ("link_id", "source_model", "source_port", "target_model", "target_port"):
            _nonempty(getattr(self, name), name)
        object.__setattr__(self, "direction", _enum_value(self.direction, CouplingDirection, "coupling direction"))

    def to_dict(self) -> dict[str, Any]:
        return {"link_id": self.link_id, "source_model": self.source_model, "source_port": self.source_port,
                "target_model": self.target_model, "target_port": self.target_port, "direction": self.direction.value,
                "boundary_mapping": self.boundary_mapping.to_dict(), "time_policy": self.time_policy.to_dict(),
                "enabled": self.enabled, "required_capabilities": sorted(self.required_capabilities), "notes": self.notes}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "InteractionLink":
        return cls(data["link_id"], data["source_model"], data["source_port"], data["target_model"], data["target_port"],
                   _enum_value(data["direction"], CouplingDirection, "coupling direction"),
                   BoundaryMapping.from_dict(data["boundary_mapping"]), TimePolicy.from_dict(data.get("time_policy", {})),
                   data.get("enabled", True), frozenset(data.get("required_capabilities", ())), data.get("notes", ""))


@dataclass(frozen=True, slots=True)
class MaterialRef:
    material_id: str
    label: str
    composition_ref: str | None = None
    property_set_ref: str | None = None

    def __post_init__(self):
        _nonempty(self.material_id, "material_id"); _nonempty(self.label, "material label")

    def to_dict(self): return asdict(self)
    @classmethod
    def from_dict(cls, d): return cls(**d)


@dataclass(frozen=True, slots=True)
class DomainRef:
    domain_id: str
    material_id: str
    representation: str
    geometry_ref: str | None = None
    mesh_ref: str | None = None
    boundary_ids: tuple[str, ...] = ()

    def __post_init__(self):
        _nonempty(self.domain_id, "domain_id"); _nonempty(self.material_id, "domain material_id")
        if self.representation not in {"continuum_mesh", "particles", "crystal", "homogenized", "analytic", "global"}:
            raise ContractError(f"unsupported domain representation: {self.representation}")
        if self.representation == "continuum_mesh" and not self.mesh_ref:
            raise ContractError("continuum_mesh domain requires mesh_ref")

    def to_dict(self): return {**asdict(self), "boundary_ids": list(self.boundary_ids)}
    @classmethod
    def from_dict(cls, d): return cls(d["domain_id"], d["material_id"], d["representation"], d.get("geometry_ref"), d.get("mesh_ref"), tuple(d.get("boundary_ids", ())))


@dataclass(frozen=True, slots=True)
class Schedule:
    mode: str = "standard"
    duration: float = 1.0
    time_unit: str = "s"
    timestep_policy: str = "solver_controlled"
    random_seed: int | None = None
    parameter_distributions: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)

    def __post_init__(self):
        if self.mode not in {"standard", "randomized"}: raise ContractError("mode must be standard or randomized")
        _finite(self.duration, "duration")
        if self.duration <= 0: raise ContractError("duration must be positive")
        if self.time_unit not in _UNIT_TABLE or _UNIT_TABLE[self.time_unit][1] != TIME: raise ContractError("time_unit must be a recognized time unit")
        if self.timestep_policy not in {"fixed", "adaptive", "solver_controlled", "event_driven", "quasi_static"}: raise ContractError("unsupported timestep_policy")
        if self.mode == "randomized" and self.random_seed is None: raise ContractError("randomized schedules require an explicit random_seed")
        if self.mode == "standard" and self.parameter_distributions: raise ContractError("parameter_distributions require randomized mode")

    def to_dict(self): return {"mode": self.mode, "duration": self.duration, "time_unit": self.time_unit,
                              "timestep_policy": self.timestep_policy, "random_seed": self.random_seed,
                              "parameter_distributions": dict(self.parameter_distributions)}
    @classmethod
    def from_dict(cls, d): return cls(d.get("mode", "standard"), d.get("duration", 1.0), d.get("time_unit", "s"),
                                      d.get("timestep_policy", "solver_controlled"), d.get("random_seed"), d.get("parameter_distributions", {}))


@dataclass(frozen=True, slots=True)
class OutputSpec:
    field_name: str
    capture: str = "every_accepted_step"
    provenance: bool = True
    change_sets: bool = True

    def __post_init__(self):
        _nonempty(self.field_name, "output field name")
        if self.capture not in {"every_accepted_step", "interval", "events_only", "final_only"}: raise ContractError("unsupported output capture policy")
    def to_dict(self): return asdict(self)
    @classmethod
    def from_dict(cls, d): return cls(**d)


@dataclass(frozen=True, slots=True)
class ProcessDefinition:
    process_id: str
    version: str
    name: str
    family: str
    materials: tuple[MaterialRef, ...]
    domains: tuple[DomainRef, ...]
    models: tuple[ModelContract, ...]
    links: tuple[InteractionLink, ...]
    schedule: Schedule = field(default_factory=Schedule)
    outputs: tuple[OutputSpec, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        for n in ("process_id", "version", "name", "family"): _nonempty(getattr(self, n), n)
        for items, label in ((self.materials, "material"), (self.domains, "domain"), (self.models, "model"), (self.links, "link")):
            ids = [getattr(x, {"material":"material_id", "domain":"domain_id", "model":"model_id", "link":"link_id"}[label]) for x in items]
            if len(ids) != len(set(ids)): raise ContractError(f"duplicate {label} identifiers")
        material_ids = {m.material_id for m in self.materials}
        for domain in self.domains:
            if domain.material_id not in material_ids: raise ContractError(f"domain {domain.domain_id} references unknown material {domain.material_id}")
        model_ids = {m.model_id for m in self.models}
        for link in self.links:
            if link.source_model not in model_ids or link.target_model not in model_ids:
                raise ContractError(f"link {link.link_id} references unknown model")

    def validate(self, solver: SolverProfile | None = None) -> tuple[Diagnostic, ...]:
        diagnostics: list[Diagnostic] = []
        models = {m.model_id: m for m in self.models}
        domains = {d.domain_id: d for d in self.domains}
        for idx, link in enumerate(self.links):
            path = f"links[{idx}]"
            if not link.enabled: continue
            src, dst = models[link.source_model], models[link.target_model]
            src_ports = {p.name: p for p in src.ports}; dst_ports = {p.name: p for p in dst.ports}
            if link.source_port not in src_ports:
                diagnostics.append(Diagnostic("LINK_SOURCE_PORT_UNKNOWN", Severity.ERROR, f"Unknown source port {link.source_port!r} on {src.model_id}", path+".source_port", "Choose a declared output port.")); continue
            if link.target_port not in dst_ports:
                diagnostics.append(Diagnostic("LINK_TARGET_PORT_UNKNOWN", Severity.ERROR, f"Unknown target port {link.target_port!r} on {dst.model_id}", path+".target_port", "Choose a declared input port.")); continue
            out, inp = src_ports[link.source_port], dst_ports[link.target_port]
            if out.direction != "output": diagnostics.append(Diagnostic("SOURCE_NOT_OUTPUT", Severity.ERROR, "Source port must be an output", path+".source_port"))
            if inp.direction != "input": diagnostics.append(Diagnostic("TARGET_NOT_INPUT", Severity.ERROR, "Target port must be an input", path+".target_port"))
            if out.field.dimension != inp.field.dimension:
                diagnostics.append(Diagnostic("DIMENSION_MISMATCH", Severity.ERROR, f"Source dimension {out.field.dimension} does not match target {inp.field.dimension}", path, "Use a physically justified conversion model; do not bypass dimensional checks."))
            elif out.field.value_kind != inp.field.value_kind:
                diagnostics.append(Diagnostic("FIELD_KIND_MISMATCH", Severity.ERROR, f"Source kind {out.field.value_kind} does not match target {inp.field.value_kind}", path))
            if out.field.dimension == inp.field.dimension and out.field.unit != inp.field.unit:
                diagnostics.append(Diagnostic("UNIT_CONVERSION_REQUIRED", Severity.WARNING,
                    f"Units differ ({out.field.unit} -> {inp.field.unit}); an explicit conversion must be applied by the execution adapter",
                    path, "Use the unit scale factors to construct and test a conversion; do not relabel values."))
            if out.field.spatial_support != inp.field.spatial_support and link.boundary_mapping.kind not in {BoundaryMappingKind.NEAREST, BoundaryMappingKind.CONSERVATIVE, BoundaryMappingKind.INTERPOLATION, BoundaryMappingKind.EXPLICIT, BoundaryMappingKind.GLOBAL}:
                diagnostics.append(Diagnostic("SPATIAL_MAPPING_REQUIRED", Severity.ERROR, "Source and target spatial supports differ but no mapping policy is declared", path+".boundary_mapping"))
            if link.boundary_mapping.source_domain not in domains:
                diagnostics.append(Diagnostic("SOURCE_DOMAIN_UNKNOWN", Severity.ERROR, f"Unknown source domain {link.boundary_mapping.source_domain}", path+".boundary_mapping.source_domain"))
            if link.boundary_mapping.target_domain not in domains:
                diagnostics.append(Diagnostic("TARGET_DOMAIN_UNKNOWN", Severity.ERROR, f"Unknown target domain {link.boundary_mapping.target_domain}", path+".boundary_mapping.target_domain"))
            if link.direction == CouplingDirection.TWO_WAY:
                reverse_exists = any(other.enabled and other.source_model == link.target_model and other.target_model == link.source_model for other in self.links)
                if not reverse_exists:
                    diagnostics.append(Diagnostic("TWO_WAY_REVERSE_LINK_MISSING", Severity.ERROR, "Two-way coupling requires a separately defined reverse transfer with its own ports and mapping", path, "Add and validate the reverse link; do not assume reciprocity."))
            if solver:
                required = set(link.required_capabilities) | set(src.solver_requirements) | set(dst.solver_requirements)
                missing = sorted(required - set(solver.capabilities))
                if missing:
                    diagnostics.append(Diagnostic("SOLVER_CAPABILITY_MISSING", Severity.ERROR, f"Solver {solver.solver_id} lacks capabilities: {', '.join(missing)}", path, "Select a compatible solver or revise the model requirements."))
                for model in (src, dst):
                    for port in model.ports:
                        if port.name in {link.source_port, link.target_port} and port.field.spatial_support not in solver.supported_spatial_supports:
                            diagnostics.append(Diagnostic("SOLVER_SPATIAL_SUPPORT_MISSING", Severity.ERROR, f"Solver {solver.solver_id} does not support {port.field.spatial_support} fields", path))
            if src.evidence_status == "unvalidated" or dst.evidence_status == "unvalidated":
                diagnostics.append(Diagnostic("MODEL_UNVALIDATED", Severity.WARNING, "One or more connected models are unvalidated; mathematical or numerical correctness does not establish experimental validity", path))
        if not self.models:
            diagnostics.append(Diagnostic("NO_MODELS", Severity.ERROR, "Process has no physics models", "models"))
        if not self.outputs:
            diagnostics.append(Diagnostic("NO_OUTPUTS", Severity.WARNING, "No outputs configured; state changes may not be inspectable", "outputs", "Declare fields and enable causal change-set capture."))
        return tuple(diagnostics)

    def to_dict(self) -> dict[str, Any]:
        return {"schema_version": "1.0.0", "process_id": self.process_id, "version": self.version, "name": self.name,
                "family": self.family, "materials": [x.to_dict() for x in self.materials], "domains": [x.to_dict() for x in self.domains],
                "models": [x.to_dict() for x in self.models], "links": [x.to_dict() for x in self.links],
                "schedule": self.schedule.to_dict(), "outputs": [x.to_dict() for x in self.outputs], "metadata": dict(self.metadata)}

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True, allow_nan=False)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ProcessDefinition":
        if data.get("schema_version") != "1.0.0":
            raise ContractError(f"unsupported schema_version: {data.get('schema_version')!r}")
        return cls(data["process_id"], data["version"], data["name"], data["family"],
                   tuple(MaterialRef.from_dict(x) for x in data.get("materials", ())),
                   tuple(DomainRef.from_dict(x) for x in data.get("domains", ())),
                   tuple(ModelContract.from_dict(x) for x in data.get("models", ())),
                   tuple(InteractionLink.from_dict(x) for x in data.get("links", ())),
                   Schedule.from_dict(data.get("schedule", {})), tuple(OutputSpec.from_dict(x) for x in data.get("outputs", ())), data.get("metadata", {}))

    @classmethod
    def from_json(cls, value: str) -> "ProcessDefinition":
        try: data = json.loads(value)
        except json.JSONDecodeError as exc: raise ContractError(f"invalid process JSON: {exc.msg}") from exc
        if not isinstance(data, dict): raise ContractError("process JSON root must be an object")
        return cls.from_dict(data)
