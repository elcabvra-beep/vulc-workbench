"""Parser for the deliberately small, non-executable GOAT declarative DSL.

This module builds a typed syntax tree and diagnostics. It never evaluates user code.
The first grammar version supports material, process, factor, connect, and use.
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
import json
import re
from typing import Any, TypeAlias


@dataclass(frozen=True, slots=True)
class Span:
    line: int
    column: int
    end_column: int


@dataclass(frozen=True, slots=True)
class Diagnostic:
    code: str
    severity: str
    message: str
    span: Span
    remediation: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "severity": self.severity, "message": self.message,
                "line": self.span.line, "column": self.span.column,
                "end_column": self.span.end_column, "remediation": self.remediation}


@dataclass(frozen=True, slots=True)
class MaterialDecl:
    name: str
    arguments: dict[str, Any]
    span: Span
    kind: str = field(default="material", init=False)


@dataclass(frozen=True, slots=True)
class ProcessDecl:
    alias: str
    process_id: str
    arguments: dict[str, Any]
    span: Span
    kind: str = field(default="process", init=False)


@dataclass(frozen=True, slots=True)
class FactorDecl:
    name: str
    arguments: dict[str, Any]
    span: Span
    kind: str = field(default="factor", init=False)


@dataclass(frozen=True, slots=True)
class ConnectionDecl:
    source_alias: str
    source_port: str
    target_alias: str
    target_port: str
    span: Span
    kind: str = field(default="connect", init=False)


@dataclass(frozen=True, slots=True)
class UseDecl:
    reference: str
    span: Span
    kind: str = field(default="use", init=False)


Statement: TypeAlias = MaterialDecl | ProcessDecl | FactorDecl | ConnectionDecl | UseDecl


@dataclass(frozen=True, slots=True)
class ScriptAST:
    language: str
    version: str
    statements: tuple[Statement, ...]

    def to_dict(self) -> dict[str, Any]:
        out = []
        for node in self.statements:
            d = asdict(node)
            d["span"] = asdict(node.span)
            out.append(d)
        return {"language": self.language, "version": self.version, "statements": out}


@dataclass(frozen=True, slots=True)
class ParseResult:
    ast: ScriptAST
    diagnostics: tuple[Diagnostic, ...]

    @property
    def ok(self) -> bool:
        return not any(d.severity == "error" for d in self.diagnostics)

    def to_dict(self) -> dict[str, Any]:
        return {"ok": self.ok, "ast": self.ast.to_dict(),
                "diagnostics": [d.to_dict() for d in self.diagnostics]}


_IDENT = r"[A-Za-z_][A-Za-z0-9_]*"
_PROCESS = re.compile(rf"^(?:(?P<alias>{_IDENT})\s*=\s*)?process\(\s*(?P<id>\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*')\s*(?:,\s*(?P<args>.*))?\)$")
_MATERIAL = re.compile(r"^material\(\s*(?P<name>\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*')\s*(?:,\s*(?P<args>.*))?\)$")
_FACTOR = re.compile(r"^factor\(\s*(?P<name>\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*')\s*,\s*(?P<args>.*)\)$")
_CONNECT = re.compile(rf"^connect\(\s*(?P<source>{_IDENT}\.{_IDENT})\s*,\s*(?P<target>{_IDENT}\.{_IDENT})\s*\)$")
_USE = re.compile(r"^use\(\s*(?P<ref>\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*')\s*\)$")


def _quoted(value: str) -> str | None:
    value = value.strip()
    if len(value) >= 2 and value[0] in "\"'" and value[-1] == value[0]:
        body = value[1:-1]
        # Deliberately supports only common escapes; no evaluation/interpolation.
        return bytes(body, "utf-8").decode("unicode_escape") if "\\" in body else body
    return None


def _split_args(raw: str) -> list[str]:
    parts: list[str] = []
    start = 0
    quote: str | None = None
    escaped = False
    for i, ch in enumerate(raw):
        if quote:
            if escaped: escaped = False
            elif ch == "\\": escaped = True
            elif ch == quote: quote = None
        elif ch in "\"'": quote = ch
        elif ch == ",":
            parts.append(raw[start:i].strip()); start = i + 1
    if quote:
        raise ValueError("unterminated string literal")
    tail = raw[start:].strip()
    if tail: parts.append(tail)
    elif raw.strip(): raise ValueError("expected an argument after comma")
    return parts


def _literal(raw: str) -> Any:
    value = raw.strip()
    string = _quoted(value)
    if string is not None: return string
    if value == "true": return True
    if value == "false": return False
    if value == "null": return None
    if re.fullmatch(r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", value):
        number = float(value) if any(c in value for c in ".eE") else int(value)
        if isinstance(number, float) and (number != number or abs(number) == float("inf")):
            raise ValueError("numeric literal must be finite")
        return number
    raise ValueError(f"unsupported value {value!r}; use a quoted string, finite number, true, false, or null")


def _arguments(raw: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for part in _split_args(raw):
        if "=" not in part: raise ValueError(f"expected key=value argument, got {part!r}")
        key, value = part.split("=", 1)
        key = key.strip()
        if not re.fullmatch(_IDENT, key): raise ValueError(f"invalid argument name {key!r}")
        if key in result: raise ValueError(f"duplicate argument {key!r}")
        result[key] = _literal(value)
    return result


def parse_script(source: str) -> ParseResult:
    """Parse the safe declarative subset into a typed AST with source diagnostics."""
    statements: list[Statement] = []
    diagnostics: list[Diagnostic] = []
    aliases: dict[str, Span] = {}
    connections: list[ConnectionDecl] = []
    for line_no, raw in enumerate(source.splitlines(), 1):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"): continue
        col = len(raw) - len(raw.lstrip()) + 1
        span = Span(line_no, col, len(raw) + 1)
        try:
            m = _MATERIAL.fullmatch(stripped)
            if m:
                name = _quoted(m.group("name"))
                if name is None: raise ValueError("material name must be quoted")
                statements.append(MaterialDecl(name, _arguments(m.group("args") or ""), span)); continue
            m = _PROCESS.fullmatch(stripped)
            if m:
                process_id = _quoted(m.group("id"))
                if process_id is None: raise ValueError("process identifier must be quoted")
                args = _arguments(m.group("args") or "")
                alias = m.group("alias") or process_id
                if alias in aliases:
                    diagnostics.append(Diagnostic("DUPLICATE_ALIAS", "error", f"Alias {alias!r} is already declared.", span, "Give each process a unique alias."))
                else: aliases[alias] = span
                if not isinstance(args.get("model"), str) or not args["model"].strip():
                    diagnostics.append(Diagnostic("MODEL_REQUIRED", "error", f"Process {alias!r} requires model=\"...\".", span, "Choose a registered model identifier."))
                statements.append(ProcessDecl(alias, process_id, args, span)); continue
            m = _FACTOR.fullmatch(stripped)
            if m:
                name = _quoted(m.group("name"))
                if name is None: raise ValueError("factor name must be quoted")
                args = _arguments(m.group("args"))
                if "value" not in args or not isinstance(args.get("unit"), str):
                    diagnostics.append(Diagnostic("FACTOR_INCOMPLETE", "error", f"Factor {name!r} requires value= and unit=.", span, "Specify a finite value and explicit unit."))
                statements.append(FactorDecl(name, args, span)); continue
            m = _CONNECT.fullmatch(stripped)
            if m:
                sa, sp = m.group("source").split("."); ta, tp = m.group("target").split(".")
                node = ConnectionDecl(sa, sp, ta, tp, span); connections.append(node); statements.append(node); continue
            m = _USE.fullmatch(stripped)
            if m:
                ref = _quoted(m.group("ref"))
                if ref is None: raise ValueError("use reference must be quoted")
                statements.append(UseDecl(ref, span)); continue
            diagnostics.append(Diagnostic("UNSUPPORTED_STATEMENT", "error", "Statement is outside the supported GOAT declarative grammar.", span, "Use material(), process(), factor(), connect(), or use(). Arbitrary code is not executed."))
        except ValueError as exc:
            diagnostics.append(Diagnostic("SYNTAX_ERROR", "error", str(exc), span, "Check quoting, commas, and key=value argument syntax."))
    for c in connections:
        for alias in (c.source_alias, c.target_alias):
            if alias not in aliases:
                diagnostics.append(Diagnostic("UNKNOWN_CONNECTION_ALIAS", "error", f"Connection references undeclared process alias {alias!r}.", c.span, "Declare the process first or correct the alias."))
    ast = ScriptAST("GOAT-declarative", "1.0", tuple(statements))
    return ParseResult(ast, tuple(diagnostics))


def parse_json(source: str) -> dict[str, Any]:
    """Stable JSON form of a parse result, useful for editors and API adapters."""
    return json.loads(json.dumps(parse_script(source).to_dict(), ensure_ascii=False))
