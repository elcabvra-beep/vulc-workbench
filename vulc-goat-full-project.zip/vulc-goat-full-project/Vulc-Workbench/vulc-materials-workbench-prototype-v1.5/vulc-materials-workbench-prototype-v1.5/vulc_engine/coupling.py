"""Explicit fixed-point coupling utility; convergence is measured, never assumed."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import math

class CouplingConvergenceError(RuntimeError): pass
@dataclass(frozen=True, slots=True)
class CouplingIteration:
    iteration: int
    state: tuple[float, ...]
    residual_inf: float
@dataclass(frozen=True, slots=True)
class CouplingResult:
    state: tuple[float, ...]
    converged: bool
    iterations: tuple[CouplingIteration, ...]
    absolute_tolerance: float
    relative_tolerance: float
    relaxation: float

def solve_fixed_point(mapping: Callable[[tuple[float, ...]], Sequence[float]], initial: Sequence[float], *, absolute_tolerance: float=1e-10, relative_tolerance: float=1e-8, max_iterations: int=100, relaxation: float=1.0) -> CouplingResult:
    """Solve x=F(x) by relaxed Picard iteration. Not suitable for every stiff/noncontractive system.

    Convergence criterion: ||x_new-x_old||_inf <= atol + rtol*||x_new||_inf.
    Divergence, dimension changes, non-finite values, and exhaustion are explicit errors.
    """
    x=tuple(float(v) for v in initial)
    if not x or any(not math.isfinite(v) for v in x): raise ValueError('initial state must be nonempty and finite')
    if absolute_tolerance < 0 or relative_tolerance < 0 or (absolute_tolerance == relative_tolerance == 0): raise ValueError('tolerances must be nonnegative and not both zero')
    if max_iterations < 1: raise ValueError('max_iterations must be >= 1')
    if not 0 < relaxation <= 1: raise ValueError('relaxation must be in (0, 1]')
    history=[]
    for i in range(1,max_iterations+1):
        raw=tuple(float(v) for v in mapping(x))
        if len(raw)!=len(x): raise CouplingConvergenceError('coupling map changed state dimension')
        if any(not math.isfinite(v) for v in raw): raise CouplingConvergenceError(f'non-finite coupled state at iteration {i}')
        new=tuple(old+relaxation*(target-old) for old,target in zip(x,raw))
        residual=max(abs(a-b) for a,b in zip(new,x)); scale=max(abs(v) for v in new)
        history.append(CouplingIteration(i,new,residual))
        if residual <= absolute_tolerance+relative_tolerance*scale: return CouplingResult(new,True,tuple(history),absolute_tolerance,relative_tolerance,relaxation)
        x=new
    raise CouplingConvergenceError(f'fixed-point iteration failed to converge in {max_iterations} iterations; last residual={history[-1].residual_inf:g}')
