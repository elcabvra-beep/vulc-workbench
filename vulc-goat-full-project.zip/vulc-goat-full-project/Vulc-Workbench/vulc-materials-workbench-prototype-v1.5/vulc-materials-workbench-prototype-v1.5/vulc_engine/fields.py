"""First-class field values and field contracts for scalar and spatial ports.

Values are immutable, finite, row-major arrays. The core deliberately avoids a
NumPy dependency; adapters may translate to/from solver-native arrays.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Sequence
from .process_api import FieldType, ContractError, _UNIT_TABLE

class FieldValueError(ValueError):
    pass

@dataclass(frozen=True, slots=True)
class FieldValue:
    """A typed value carried by a process port.

    Scalar: shape=(), values=(x,). Spatial field: shape=(n,), coordinates=(x0,...).
    Time-dependent fields should use ResultSeries, not hide time inside shape.
    """
    contract: FieldType
    values: tuple[float, ...]
    shape: tuple[int, ...] = ()
    domain_id: str | None = None
    coordinates: tuple[tuple[float, ...], ...] | None = None
    coordinate_frame: str | None = None

    def __post_init__(self):
        if not self.values:
            raise FieldValueError("field values cannot be empty")
        if any(not math.isfinite(float(v)) for v in self.values):
            raise FieldValueError("field values must all be finite")
        if self.contract.value_kind != "scalar":
            raise FieldValueError("runtime currently supports scalar-valued fields only; vector/tensor/discrete/event storage is reserved")
        if not self.shape:
            if len(self.values) != 1:
                raise FieldValueError("scalar field requires exactly one value")
            if self.contract.spatial_support not in {"global", "region"}:
                raise FieldValueError("a scalar value must use global or region support")
        else:
            if any(not isinstance(n, int) or n <= 0 for n in self.shape):
                raise FieldValueError("shape dimensions must be positive integers")
            count = math.prod(self.shape)
            if count != len(self.values):
                raise FieldValueError(f"shape {self.shape} contains {count} values, received {len(self.values)}")
            if self.contract.spatial_support == "global":
                raise FieldValueError("global support cannot carry a spatial array")
        if self.coordinates is not None:
            if len(self.coordinates) != len(self.values):
                raise FieldValueError("coordinates count must match flattened field values")
            if not self.domain_id:
                raise FieldValueError("coordinate-bearing field requires domain_id")
            dims = len(self.coordinates[0]) if self.coordinates else 0
            if dims == 0 or any(len(c) != dims for c in self.coordinates):
                raise FieldValueError("coordinates must have a consistent nonzero dimension")
            if any(not math.isfinite(float(x)) for c in self.coordinates for x in c):
                raise FieldValueError("coordinates must be finite")
        if self.contract.coordinate_frame and self.coordinate_frame != self.contract.coordinate_frame:
            raise FieldValueError("field coordinate frame does not match its contract")

    @property
    def is_scalar(self) -> bool:
        return not self.shape

    def converted(self, target: FieldType) -> "FieldValue":
        if self.contract.dimension != target.dimension:
            raise FieldValueError("cannot convert fields with different physical dimensions")
        if self.contract.value_kind != target.value_kind:
            raise FieldValueError("cannot convert fields with different value kinds")
        if self.contract.spatial_support != target.spatial_support:
            raise FieldValueError("support mismatch requires an explicit mapping operator")
        scale = _UNIT_TABLE[self.contract.unit][0] / _UNIT_TABLE[target.unit][0]
        return FieldValue(target, tuple(v * scale for v in self.values), self.shape,
                          self.domain_id, self.coordinates, self.coordinate_frame)

    def to_dict(self) -> dict:
        return {"field": self.contract.to_dict(), "values": list(self.values),
                "shape": list(self.shape), "domain_id": self.domain_id,
                "coordinates": [list(c) for c in self.coordinates] if self.coordinates is not None else None,
                "coordinate_frame": self.coordinate_frame}
