"""Explicit fixed-step integrators for y'=f(t,y); caller owns units and error policy."""
from __future__ import annotations
from collections.abc import Callable, Sequence
import math

Vector = tuple[float, ...]
Derivative = Callable[[float, Vector], Sequence[float]]
class IntegrationError(ValueError): pass

def _checked(values: Sequence[float], n: int) -> Vector:
    result = tuple(float(x) for x in values)
    if len(result) != n: raise IntegrationError(f"derivative length {len(result)} != state length {n}")
    if not all(math.isfinite(x) for x in result): raise IntegrationError("non-finite derivative")
    return result

def _combine(y: Vector, h: float, terms: tuple[tuple[float, Vector], ...]) -> Vector:
    return tuple(yi + h * sum(weight * k[i] for weight,k in terms) for i,yi in enumerate(y))

def euler_step(f: Derivative, t: float, y: Sequence[float], dt: float) -> Vector:
    """Forward Euler, first order; explicit stability restrictions still apply."""
    y0=tuple(float(v) for v in y); _validate(t, y0, dt)
    k1=_checked(f(float(t), y0),len(y0))
    return _combine(y0,float(dt),((1.0,k1),))

def rk4_step(f: Derivative, t: float, y: Sequence[float], dt: float) -> Vector:
    """Classical explicit Runge-Kutta order 4. Not an adaptive or stiff solver."""
    y0=tuple(float(v) for v in y); _validate(t,y0,dt); t=float(t); h=float(dt); n=len(y0)
    k1=_checked(f(t,y0),n)
    k2=_checked(f(t+h/2,_combine(y0,h/2,((1,k1),))),n)
    k3=_checked(f(t+h/2,_combine(y0,h/2,((1,k2),))),n)
    k4=_checked(f(t+h,_combine(y0,h,((1,k3),))),n)
    return _combine(y0,h,((1/6,k1),(1/3,k2),(1/3,k3),(1/6,k4)))

def _validate(t: float, y: Vector, dt: float) -> None:
    if not math.isfinite(float(t)) or not math.isfinite(float(dt)) or dt <= 0:
        raise IntegrationError("time must be finite and dt must be finite and > 0")
    if not y or not all(math.isfinite(v) for v in y): raise IntegrationError("state must be nonempty and finite")
