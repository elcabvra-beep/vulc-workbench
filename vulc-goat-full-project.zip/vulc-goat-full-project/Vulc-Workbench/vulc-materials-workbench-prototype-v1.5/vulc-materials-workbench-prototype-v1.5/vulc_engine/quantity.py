"""Small strict dimensional-quantity layer. SI base dimensions: kg, m, s, A, K, mol, cd."""
from __future__ import annotations
from dataclasses import dataclass
import math

Dimension = tuple[int, int, int, int, int, int, int]
DIMENSIONLESS: Dimension = (0, 0, 0, 0, 0, 0, 0)
MASS: Dimension = (1, 0, 0, 0, 0, 0, 0)
LENGTH: Dimension = (0, 1, 0, 0, 0, 0, 0)
TIME: Dimension = (0, 0, 1, 0, 0, 0, 0)
CURRENT: Dimension = (0, 0, 0, 1, 0, 0, 0)
TEMPERATURE: Dimension = (0, 0, 0, 0, 1, 0, 0)
VELOCITY: Dimension = (0, 1, -1, 0, 0, 0, 0)
ACCELERATION: Dimension = (0, 1, -2, 0, 0, 0, 0)
FORCE: Dimension = (1, 1, -2, 0, 0, 0, 0)
ENERGY: Dimension = (1, 2, -2, 0, 0, 0, 0)
PRESSURE: Dimension = (1, -1, -2, 0, 0, 0, 0)
POWER: Dimension = (1, 2, -3, 0, 0, 0, 0)

class DimensionError(ValueError):
    """Raised when an operation combines incompatible dimensions."""

@dataclass(frozen=True, slots=True)
class Quantity:
    value: float
    dimension: Dimension
    symbol: str = "SI"

    def __post_init__(self):
        if len(self.dimension) != 7 or any(not isinstance(p, int) for p in self.dimension):
            raise DimensionError("dimension must be seven integer SI-base exponents")
        if not math.isfinite(float(self.value)):
            raise ValueError("quantity value must be finite")
        object.__setattr__(self, "value", float(self.value))

    def _same(self, other: Quantity) -> None:
        if not isinstance(other, Quantity) or self.dimension != other.dimension:
            raise DimensionError(f"incompatible dimensions: {self.dimension} vs {getattr(other, 'dimension', None)}")

    def __add__(self, other: Quantity) -> Quantity:
        self._same(other); return Quantity(self.value + other.value, self.dimension, self.symbol)
    def __sub__(self, other: Quantity) -> Quantity:
        self._same(other); return Quantity(self.value - other.value, self.dimension, self.symbol)
    def __mul__(self, other):
        if isinstance(other, Quantity):
            return Quantity(self.value * other.value, tuple(a+b for a,b in zip(self.dimension, other.dimension)))
        return Quantity(self.value * float(other), self.dimension, self.symbol)
    def __rmul__(self, other): return self * other
    def __truediv__(self, other):
        if isinstance(other, Quantity):
            if other.value == 0: raise ZeroDivisionError("quantity division by zero")
            return Quantity(self.value / other.value, tuple(a-b for a,b in zip(self.dimension, other.dimension)))
        scalar = float(other)
        if scalar == 0: raise ZeroDivisionError("quantity division by zero")
        return Quantity(self.value / scalar, self.dimension, self.symbol)
    def __neg__(self): return Quantity(-self.value, self.dimension, self.symbol)


def require_dimension(q: Quantity, expected: Dimension, name: str = "quantity") -> Quantity:
    if q.dimension != expected:
        raise DimensionError(f"{name} requires dimension {expected}; got {q.dimension}")
    return q
