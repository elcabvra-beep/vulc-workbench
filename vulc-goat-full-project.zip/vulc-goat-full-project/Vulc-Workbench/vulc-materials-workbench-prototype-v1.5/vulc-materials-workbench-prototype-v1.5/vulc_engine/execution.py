"""Deterministic execution planning for validated process contracts.

This module builds an execution plan only. Physics execution is delegated to
explicit registered implementations; contracts alone are never treated as code.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

from .process_api import ProcessDefinition, Severity, SolverProfile, Diagnostic

class ExecutionPlanError(ValueError):
    """A process cannot be compiled into a supported execution plan."""

@dataclass(frozen=True, slots=True)
class ExecutionStep:
    model_id: str
    model_version: str
    implementation_id: str

@dataclass(frozen=True, slots=True)
class ExecutionPlan:
    process_id: str
    process_version: str
    steps: tuple[ExecutionStep, ...]
    active_links: tuple[str, ...]
    diagnostics: tuple[Diagnostic, ...] = ()

    def to_dict(self) -> dict:
        return {"process_id": self.process_id, "process_version": self.process_version,
                "steps": [{"model_id": s.model_id, "model_version": s.model_version,
                           "implementation_id": s.implementation_id} for s in self.steps],
                "active_links": list(self.active_links),
                "diagnostics": [d.to_dict() for d in self.diagnostics]}

class ModelRegistry:
    """Allow-listed mapping from contract identity to implementation identity."""
    def __init__(self, implementations: Mapping[tuple[str, str], str] | None = None):
        self._implementations = dict(implementations or {})

    def register(self, model_id: str, version: str, implementation_id: str) -> None:
        if not model_id.strip() or not version.strip() or not implementation_id.strip():
            raise ValueError("model, version, and implementation IDs must be non-empty")
        key = (model_id, version)
        if key in self._implementations:
            raise ValueError(f"implementation already registered for {model_id}@{version}")
        self._implementations[key] = implementation_id

    def resolve(self, model_id: str, version: str) -> str | None:
        return self._implementations.get((model_id, version))


def compile_execution_plan(process: ProcessDefinition, registry: ModelRegistry,
                           solver: SolverProfile | None = None) -> ExecutionPlan:
    """Validate contracts, resolve implementations and topologically order models.

    Cycles are rejected until an explicit iterative-coupling algorithm is added.
    Disabled links do not contribute dependencies. Independent nodes are ordered
    lexicographically for repeatable plans.
    """
    diagnostics = list(process.validate(solver))
    errors = [d for d in diagnostics if d.severity == Severity.ERROR]
    if errors:
        raise ExecutionPlanError("process validation failed: " + "; ".join(f"{d.code}: {d.message}" for d in errors))
    models = {m.model_id: m for m in process.models}
    impls: dict[str, str] = {}
    for model in process.models:
        implementation = registry.resolve(model.model_id, model.version)
        if implementation is None:
            raise ExecutionPlanError(f"no registered implementation for {model.model_id}@{model.version}")
        impls[model.model_id] = implementation

    active_links = [l for l in process.links if l.enabled]
    indegree = {mid: 0 for mid in models}
    outgoing: dict[str, set[str]] = {mid: set() for mid in models}
    for link in active_links:
        if link.source_model != link.target_model and link.target_model not in outgoing[link.source_model]:
            outgoing[link.source_model].add(link.target_model)
            indegree[link.target_model] += 1
        elif link.source_model == link.target_model:
            raise ExecutionPlanError(f"self-cycle at model {link.source_model} is unsupported")
    ready = sorted(mid for mid, degree in indegree.items() if degree == 0)
    ordered: list[str] = []
    while ready:
        current = ready.pop(0)
        ordered.append(current)
        for target in sorted(outgoing[current]):
            indegree[target] -= 1
            if indegree[target] == 0:
                ready.append(target)
                ready.sort()
    if len(ordered) != len(models):
        cycle_nodes = sorted(mid for mid, degree in indegree.items() if degree > 0)
        raise ExecutionPlanError("dependency cycle requires an explicit iterative coupling solver: " + ", ".join(cycle_nodes))
    steps = tuple(ExecutionStep(mid, models[mid].version, impls[mid]) for mid in ordered)
    return ExecutionPlan(process.process_id, process.version, steps,
                         tuple(l.link_id for l in active_links), tuple(diagnostics))

# Runtime dispatcher: contracts are metadata; only explicitly registered callables execute.
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
import uuid
from typing import Any, Callable

from .process_api import CouplingDirection, BoundaryMappingKind, TimeSemantics
from .fields import FieldValue, FieldValueError

class ModelExecutionError(RuntimeError):
    """A registered model failed or returned data outside its declared contract."""

@dataclass(frozen=True, slots=True)
class ModelExecutionContext:
    process_id: str
    process_version: str
    model_id: str
    model_version: str
    inputs: Mapping[str, Any]
    parameters: Mapping[str, Any]

@dataclass(frozen=True, slots=True)
class ModelExecutionRecord:
    model_id: str
    model_version: str
    implementation_id: str
    inputs: Mapping[str, Any]
    outputs: Mapping[str, Any]
    duration_ms: float

@dataclass(frozen=True, slots=True)
class ExecutionResult:
    run_id: str
    process_id: str
    process_version: str
    configuration_sha256: str
    started_at_utc: str
    completed_at_utc: str
    records: tuple[ModelExecutionRecord, ...]
    outputs: Mapping[str, Mapping[str, Any]]
    diagnostics: tuple[Diagnostic, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id, "process_id": self.process_id,
            "process_version": self.process_version,
            "configuration_sha256": self.configuration_sha256,
            "started_at_utc": self.started_at_utc,
            "completed_at_utc": self.completed_at_utc,
            "records": [asdict(r) for r in self.records],
            "outputs": {k: dict(v) for k, v in self.outputs.items()},
            "diagnostics": [d.to_dict() for d in self.diagnostics],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True, allow_nan=False)

class ExecutableModelRegistry(ModelRegistry):
    """Allow-list of callable model implementations keyed by model ID and version."""
    def __init__(self):
        super().__init__()
        self._callables: dict[tuple[str, str], Callable[[ModelExecutionContext], Mapping[str, Any]]] = {}

    def register_callable(self, model_id: str, version: str, implementation_id: str,
                          function: Callable[[ModelExecutionContext], Mapping[str, Any]]) -> None:
        if not callable(function):
            raise TypeError("model implementation must be callable")
        self.register(model_id, version, implementation_id)
        self._callables[(model_id, version)] = function

    def resolve_callable(self, model_id: str, version: str):
        return self._callables.get((model_id, version))


def execute_process(process: ProcessDefinition, registry: ExecutableModelRegistry,
                    initial_inputs: Mapping[str, Mapping[str, Any]] | None = None,
                    solver: SolverProfile | None = None) -> ExecutionResult:
    """Execute a validated acyclic process with explicitly registered model functions.

    Inputs are {model_id: {input_port: value}}. Global scalar ports retain the
    ergonomic numeric API. Spatial scalar-valued fields use FieldValue, carrying
    shape, domain, optional coordinates, support and units. Identity mapping is
    allowed only when source and target field topology matches exactly; global
    mapping is scalar-only. Interpolation/projection and event semantics fail closed.
    """
    import time as _time
    initial_inputs = initial_inputs or {}
    plan = compile_execution_plan(process, registry, solver)
    models = {m.model_id: m for m in process.models}
    links_by_target: dict[tuple[str, str], list[Any]] = {}
    for link in process.links:
        if not link.enabled:
            continue
        if link.direction in {CouplingDirection.EVENT, CouplingDirection.OBSERVE_ONLY}:
            raise ModelExecutionError(f"link {link.link_id}: {link.direction.value} transfer is not supported by this runtime")
        if link.boundary_mapping.kind not in {BoundaryMappingKind.GLOBAL, BoundaryMappingKind.IDENTITY}:
            raise ModelExecutionError(f"link {link.link_id}: mapping {link.boundary_mapping.kind.value} requires a registered mapping operator; only global_value and validated identity mappings are supported")
        if link.time_policy.semantics != TimeSemantics.PHYSICAL_TIME:
            raise ModelExecutionError(f"link {link.link_id}: time semantics {link.time_policy.semantics.value} are not executable")
        if link.time_policy.delay != 0:
            raise ModelExecutionError(f"link {link.link_id}: nonzero delay requires a delay-line implementation")
        links_by_target.setdefault((link.target_model, link.target_port), []).append(link)

    # Validate caller-provided model/input/port references before any implementation runs.
    for model_id, port_values in initial_inputs.items():
        if model_id not in models:
            raise ModelExecutionError(f"initial input references unknown model {model_id!r}")
        ports = {p.name: p for p in models[model_id].ports}
        for port_name, value in port_values.items():
            if port_name not in ports or ports[port_name].direction != "input":
                raise ModelExecutionError(f"initial input references unknown input port {model_id}.{port_name}")
            field = ports[port_name].field
            if field.spatial_support in {"global", "region"}:
                if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)):
                    raise ModelExecutionError(f"initial input {model_id}.{port_name} must be a finite scalar number")
            elif not isinstance(value, FieldValue) or value.contract != field:
                raise ModelExecutionError(f"initial input {model_id}.{port_name} requires a FieldValue matching the declared field contract")

    config_json = process.to_json(indent=None)
    config_hash = hashlib.sha256(config_json.encode("utf-8")).hexdigest()
    # A configuration hash identifies the model definition, not an individual run.
    # Keep those identities separate so repeated runs never overwrite each other.
    run_id = "run-" + uuid.uuid4().hex
    started = datetime.now(timezone.utc).isoformat()
    records: list[ModelExecutionRecord] = []
    produced: dict[tuple[str, str], Any] = {}
    outputs_by_model: dict[str, dict[str, Any]] = {}
    diagnostics = list(plan.diagnostics)

    for step in plan.steps:
        contract = models[step.model_id]
        function = registry.resolve_callable(step.model_id, step.model_version)
        if function is None:
            raise ModelExecutionError(f"implementation {step.implementation_id!r} has no executable callable")
        input_values: dict[str, Any] = dict(initial_inputs.get(step.model_id, {}))
        input_ports = {p.name: p for p in contract.ports if p.direction == "input"}
        output_ports = {p.name: p for p in contract.ports if p.direction == "output"}
        for (target_model, target_port), links in links_by_target.items():
            if target_model != step.model_id:
                continue
            if len(links) > 1:
                raise ModelExecutionError(f"multiple links target {target_model}.{target_port}; an explicit reduction model is required")
            link = links[0]
            if target_port in input_values:
                raise ModelExecutionError(f"input {target_model}.{target_port} is supplied both directly and by link {links[0].link_id}")
            source_key = (link.source_model, link.source_port)
            if source_key not in produced:
                raise ModelExecutionError(f"link {link.link_id} has no produced source value {source_key}")
            source_port = next(p for p in models[link.source_model].ports if p.name == link.source_port)
            target_contract = input_ports[target_port]
            value = produced[source_key]
            if source_port.field.value_kind != "scalar" or target_contract.field.value_kind != "scalar":
                raise ModelExecutionError(f"link {link.link_id}: runtime storage currently supports scalar-valued fields only")
            if link.boundary_mapping.kind == BoundaryMappingKind.GLOBAL:
                if isinstance(value, FieldValue) or source_port.field.spatial_support not in {"global", "region"} or target_contract.field.spatial_support not in {"global", "region"}:
                    raise ModelExecutionError(f"link {link.link_id}: global_value mapping requires scalar global/region ports")
                input_values[target_port] = float(value) * source_port.field.scale_to_si / target_contract.field.scale_to_si
            else:
                if not isinstance(value, FieldValue):
                    raise ModelExecutionError(f"link {link.link_id}: identity spatial mapping requires FieldValue")
                if source_port.field.spatial_support != target_contract.field.spatial_support:
                    raise ModelExecutionError(f"link {link.link_id}: identity mapping cannot change spatial support")
                if value.domain_id != link.boundary_mapping.source_domain:
                    raise ModelExecutionError(f"link {link.link_id}: source field domain does not match mapping contract")
                converted = value.converted(target_contract.field)
                if converted.domain_id != link.boundary_mapping.target_domain and link.boundary_mapping.source_domain != link.boundary_mapping.target_domain:
                    raise ModelExecutionError(f"link {link.link_id}: identity mapping across different domains is forbidden; provide an explicit mapping operator")
                input_values[target_port] = converted

        missing = [name for name, port in input_ports.items() if port.required and name not in input_values]
        if missing:
            raise ModelExecutionError(f"model {step.model_id} missing required inputs: {', '.join(sorted(missing))}")
        for name, value in input_values.items():
            if name not in input_ports:
                raise ModelExecutionError(f"model {step.model_id} received undeclared input {name!r}")
            field = input_ports[name].field
            if field.spatial_support in {"global", "region"}:
                if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)):
                    raise ModelExecutionError(f"input {step.model_id}.{name} must be a finite scalar")
            elif not isinstance(value, FieldValue) or value.contract != field:
                raise ModelExecutionError(f"input {step.model_id}.{name} must be a FieldValue matching its contract")

        context = ModelExecutionContext(process.process_id, process.version, step.model_id,
                                        step.model_version, dict(input_values), {})
        start = _time.perf_counter()
        try:
            raw_outputs = function(context)
        except Exception as exc:
            raise ModelExecutionError(f"model {step.model_id} implementation failed: {type(exc).__name__}: {exc}") from exc
        elapsed_ms = (_time.perf_counter() - start) * 1000.0
        if not isinstance(raw_outputs, Mapping):
            raise ModelExecutionError(f"model {step.model_id} must return a mapping of output port names to values")
        unexpected = set(raw_outputs) - set(output_ports)
        missing_outputs = set(output_ports) - set(raw_outputs)
        if unexpected:
            raise ModelExecutionError(f"model {step.model_id} returned undeclared outputs: {', '.join(sorted(unexpected))}")
        if missing_outputs:
            raise ModelExecutionError(f"model {step.model_id} omitted declared outputs: {', '.join(sorted(missing_outputs))}")
        validated_outputs: dict[str, Any] = {}
        for name, value in raw_outputs.items():
            port = output_ports[name]
            if port.field.spatial_support in {"global", "region"}:
                if not isinstance(value, (int, float)) or isinstance(value, bool) or not math.isfinite(float(value)):
                    raise ModelExecutionError(f"output {step.model_id}.{name} must be a finite scalar")
                value = float(value)
            else:
                if not isinstance(value, FieldValue) or value.contract != port.field:
                    raise ModelExecutionError(f"output {step.model_id}.{name} must be a FieldValue matching its contract")
            validated_outputs[name] = value
            produced[(step.model_id, name)] = value
        outputs_by_model[step.model_id] = validated_outputs
        records.append(ModelExecutionRecord(step.model_id, step.model_version, step.implementation_id,
                                             dict(input_values), validated_outputs, elapsed_ms))

    completed = datetime.now(timezone.utc).isoformat()
    return ExecutionResult(run_id, process.process_id, process.version, config_hash, started, completed,
                           tuple(records), outputs_by_model, tuple(diagnostics))
