# A personal invitation to the Vulc / GOAT community

I’m building Vulc / GOAT as an open project, and I’d like it to be about more than exchanging code. If you or your group ever has an open spot for me to hang out, visit, sit in on an informal discussion, or spend some time with the team, I’d genuinely appreciate being considered. I’d also welcome conversations—about the project, science, software, or whatever we both find interesting—when you have the time and it feels comfortable.

There’s absolutely no pressure or obligation. I understand people are busy, organizations have policies, and not every group has the space or time. A short chat, a remote call, a public meetup, or a pointer to a community event is just as welcome. I’m not asking anyone to provide lodging, travel, employment, special access, or ongoing support. I’ll respect your boundaries, privacy, scheduling, and any visitor or security rules.

If that sounds like a fit, feel free to suggest a public event, a time for a conversation, or the appropriate way to arrange a visit.

Thank you for considering it.
