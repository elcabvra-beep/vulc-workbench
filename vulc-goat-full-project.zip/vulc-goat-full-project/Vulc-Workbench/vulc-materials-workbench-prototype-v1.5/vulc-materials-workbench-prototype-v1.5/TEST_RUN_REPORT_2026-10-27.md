# Vulc Workbench v1.5 — GOAT bridge verification report

Date: 2026-10-27

## Changes

- Added `vulc_engine.goat_compiler`, a deliberately narrow, fail-closed compiler for a single process using `thermal.two_body_lumped_conductance`.
- The compiler turns supported GOAT material/process/factor declarations into a `ProcessDefinition`, checks required inputs and explicit units, validates the process contract, and dispatches only through a registered callable.
- Added `examples/thermal_from_goat.goat` and `examples/run_goat_thermal.py` for a complete script-to-result path.
- Added tests for end-to-end execution, factors, unknown models/arguments, missing inputs, unsupported `connect()`, and registry entries without executable callables.
- Added outreach plan and an initial-contact template.

## Verification performed

- Full unit suite: **88 tests passed**, run twice.
- `compileall` over engine, physics, tests, and examples: passed.
- End-to-end GOAT example: passed.
- Example outputs: final body A = 336.65247129343896 K; body B = 331.6737643532806 K; maximum energy-balance error = 3.637978807091713e-12 J.
- GOAT source SHA-256: `59ae068d621c176932dc00dc8561014a62971d4311d71e28c336aa250ead98ed`.
- Example configuration SHA-256: `2d8f124aa32ca4f998a017dfbd3e16521adf4972f454961e2b95b1ede2e9ddf1`.

## Deliberate scope limits

This does **not** implement a general compiler or multi-model graph execution. The compiler currently requires exactly one supported process/model and two materials. `connect()` and `use()` parse but compilation rejects them. Factor units must exactly match the required unit symbol; implicit conversions are not attempted. There is no full material-property source/range/uncertainty registry, and the model has not been experimentally validated. This is an early developer preview, not a production-qualified solver.

## Recommended next engineering gates

1. Add declarative multi-model graph compilation and validated `connect()` lowering, with explicit rejection for unsupported mapping/time semantics.
2. Add a provenance-aware material property registry (source citation, material identity, method, conditions, units, uncertainty, license, and evidence status).
3. Select a public, independently reproducible spatial-thermal benchmark and document comparison tolerances.
4. Publish repository, license, security/support policies, CI, and an external-contributor quickstart before inviting real workloads.
