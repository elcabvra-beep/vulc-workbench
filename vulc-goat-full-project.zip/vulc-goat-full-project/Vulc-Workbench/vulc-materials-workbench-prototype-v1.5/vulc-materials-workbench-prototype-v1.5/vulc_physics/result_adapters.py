"""Adapters from physics-specific results into the common auditable result format.

The adapter preserves the solver's values exactly. CausalChange records are
model-attributed transitions, not claims that temporal ordering alone proves cause.
"""
from __future__ import annotations
from .thermal_1d import Thermal1DConfig, Thermal1DResult
from vulc_engine.results import ResultBundle, ResultSeries, CausalChange

MODEL_ID = "vulc.thermal.1d.explicit-fv"
MODEL_VERSION = "0.1.0"

def thermal_1d_result_bundle(config: Thermal1DConfig, result: Thermal1DResult, *,
                             run_id: str | None = None, process_id: str = "thermal-1d",
                             process_version: str = "1.0.0", domain_id: str = "domain-1d") -> ResultBundle:
    """Convert a 1-D thermal run into common time-series and causal-ledger records.

    Temperatures are flattened time-major: all cells at t0, then all cells at t1.
    The transition ledger records each step's complete field transition. It does
    not imply per-cell causal isolation; conduction couples neighboring cells.
    """
    if result.configuration_sha256 != _config_hash(config):
        raise ValueError("result configuration hash does not match supplied configuration")
    n = config.cells
    flat_t = tuple(v for row in result.temperatures_k for v in row)
    temperature = ResultSeries(
        series_id="temperature-field", field_name="temperature", unit="K",
        times_s=result.times_s, values=flat_t, domain_id=domain_id,
        model_id=f"{MODEL_ID}@{MODEL_VERSION}",
        spatial_coordinates_m=result.x_cell_centers_m,
    )
    energy = ResultSeries(
        series_id="thermal-energy-per-area", field_name="total_internal_energy_per_area",
        unit="J/m^2", times_s=result.times_s, values=result.total_energy_j_per_m2,
        domain_id=domain_id, model_id=f"{MODEL_ID}@{MODEL_VERSION}",
    )
    changes = tuple(
        CausalChange(
            change_id=f"thermal-step-{i:06d}", time_s=result.times_s[i],
            cause_model_id=f"{MODEL_ID}@{MODEL_VERSION}", domain_id=domain_id,
            field_name="temperature", before=list(result.temperatures_k[i-1]),
            after=list(result.temperatures_k[i]),
            mechanism="finite-volume conduction plus uniform volumetric source",
            assumptions=("constant density", "constant heat capacity", "constant conductivity",
                         "explicit Euler", "insulated end faces"),
            evidence_refs=(f"config-sha256:{result.configuration_sha256}",),
        ) for i in range(1, len(result.times_s))
    )
    return ResultBundle(
        run_id=run_id or f"thermal-1d-{result.configuration_sha256[:16]}",
        process_id=process_id, process_version=process_version,
        configuration_sha256=result.configuration_sha256,
        series=(temperature, energy), causal_changes=changes,
        metadata={
            "model_id": MODEL_ID, "model_version": MODEL_VERSION,
            "numerical_method": "cell-centered finite-volume, explicit Euler",
            "boundary_conditions": "insulated (zero flux) at both ends",
            "spatial_dimension": 1, "cells": n,
            "length_m": config.length_m, "timestep_s": config.timestep_s,
            "max_energy_residual_j_per_m2": result.max_energy_residual_j_per_m2,
            "evidence_status": "numerically_verified_limited_benchmarks",
            "experimental_validation": False,
            "causality_note": "ledger records model-attributed state transitions; it does not infer causality from time order",
        },
    )

def _config_hash(config: Thermal1DConfig) -> str:
    import hashlib, json
    from dataclasses import asdict
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()
