"""1-D transient heat conduction, uniform finite-volume cells, explicit Euler.

rho*cp*dT/dt = d/dx(k*dT/dx) + q''' . Cell-centered finite volumes, constant
properties, insulated end faces (zero flux), no phase change/contact resistance.
Explicit stability requires dt <= 0.5*rho*cp*dx^2/k in 1-D for uniform cells.
This is a verification-oriented research model, not a general-purpose FE solver.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib, json, math

class SpatialThermalError(ValueError): pass
@dataclass(frozen=True, slots=True)
class Thermal1DConfig:
    length_m: float; cells: int; density_kg_m3: float; heat_capacity_j_kg_k: float; conductivity_w_m_k: float
    initial_temperature_k: tuple[float,...]; duration_s: float; timestep_s: float; volumetric_source_w_m3: float=0.0
    def __post_init__(self):
        vals=(self.length_m,self.density_kg_m3,self.heat_capacity_j_kg_k,self.conductivity_w_m_k,self.duration_s,self.timestep_s,self.volumetric_source_w_m3,*self.initial_temperature_k)
        if any(not math.isfinite(float(x)) for x in vals): raise SpatialThermalError('all numeric inputs must be finite')
        if self.cells<2 or len(self.initial_temperature_k)!=self.cells: raise SpatialThermalError('cells must be >=2 and match initial temperature count')
        if min(self.length_m,self.density_kg_m3,self.heat_capacity_j_kg_k,self.conductivity_w_m_k,self.duration_s,self.timestep_s)<=0: raise SpatialThermalError('length, density, heat capacity, conductivity, duration and timestep must be positive')
        if min(self.initial_temperature_k)<0: raise SpatialThermalError('absolute temperature cannot be below 0 K')
        ratio=self.duration_s/self.timestep_s
        if abs(ratio-round(ratio))>1e-10*max(1,abs(ratio)): raise SpatialThermalError('duration must be an integer multiple of timestep')
        dx=self.length_m/self.cells; limit=0.5*self.density_kg_m3*self.heat_capacity_j_kg_k*dx*dx/self.conductivity_w_m_k
        if self.timestep_s > limit*(1+1e-12): raise SpatialThermalError(f'explicit stability limit exceeded: dt={self.timestep_s:g} s > {limit:g} s')
@dataclass(frozen=True, slots=True)
class Thermal1DResult:
    configuration_sha256: str; x_cell_centers_m: tuple[float,...]; times_s: tuple[float,...]; temperatures_k: tuple[tuple[float,...],...]; total_energy_j_per_m2: tuple[float,...]; max_energy_residual_j_per_m2: float
    def to_dict(self): return asdict(self)
    def to_json(self,indent=2): return json.dumps(self.to_dict(),sort_keys=True,indent=indent,allow_nan=False)

def run_thermal_1d(c: Thermal1DConfig) -> Thermal1DResult:
    raw=json.dumps(asdict(c),sort_keys=True,separators=(',',':'),allow_nan=False); digest=hashlib.sha256(raw.encode()).hexdigest()
    n=c.cells; dx=c.length_m/n; alpha=c.conductivity_w_m_k/(c.density_kg_m3*c.heat_capacity_j_kg_k); dt=c.timestep_s; steps=round(c.duration_s/dt)
    t=list(map(float,c.initial_temperature_k)); times=[0.0]; history=[tuple(t)]; cv=c.density_kg_m3*c.heat_capacity_j_kg_k
    energies=[cv*dx*sum(t)]; residual=0.0
    for step in range(steps):
        nxt=t.copy()
        for i in range(n):
            left=(t[i-1]-t[i]) if i>0 else 0.0
            right=(t[i+1]-t[i]) if i<n-1 else 0.0
            nxt[i]=t[i]+alpha*dt/(dx*dx)*(left+right)+dt*c.volumetric_source_w_m3/cv
        if any(not math.isfinite(v) or v<0 for v in nxt): raise SpatialThermalError(f'invalid state at step {step+1}')
        t=nxt; times.append((step+1)*dt); history.append(tuple(t)); energies.append(cv*dx*sum(t))
        expected=energies[0]+c.volumetric_source_w_m3*c.length_m*times[-1]
        residual=max(residual,abs(energies[-1]-expected))
    return Thermal1DResult(digest,tuple((i+0.5)*dx for i in range(n)),tuple(times),tuple(history),tuple(energies),residual)
