"""Two-body lumped thermal coupling benchmark, SI units, fixed-step RK4.

Governing equations for an isolated pair with conductance G >= 0:
  C_a dT_a/dt = -G (T_a - T_b)
  C_b dT_b/dt = +G (T_a - T_b)
where C=m*cp in J/K and G in W/K. No geometry, spatial gradients, radiation,
phase change, or temperature-dependent properties are represented.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
import hashlib
import json
import uuid
from vulc_engine.integrators import rk4_step

class ThermalModelError(ValueError):
    """Invalid thermal model input or numerical configuration."""

def _finite(name: str, value: float) -> float:
    try: x = float(value)
    except (TypeError, ValueError) as exc: raise ThermalModelError(f"{name} must be finite") from exc
    if not math.isfinite(x): raise ThermalModelError(f"{name} must be finite")
    return x

@dataclass(frozen=True, slots=True)
class ThermalBody:
    body_id: str
    heat_capacity_j_k: float
    initial_temperature_k: float
    def __post_init__(self):
        if not isinstance(self.body_id, str) or not self.body_id.strip(): raise ThermalModelError("body_id cannot be empty")
        c = _finite("heat_capacity_j_k", self.heat_capacity_j_k)
        t = _finite("initial_temperature_k", self.initial_temperature_k)
        if c <= 0: raise ThermalModelError("heat_capacity_j_k must be > 0")
        if t < 0: raise ThermalModelError("absolute temperature cannot be below 0 K")
        object.__setattr__(self, "heat_capacity_j_k", c); object.__setattr__(self, "initial_temperature_k", t)

@dataclass(frozen=True, slots=True)
class ThermalCouplingConfig:
    process_id: str
    process_version: str
    body_a: ThermalBody
    body_b: ThermalBody
    conductance_w_k: float
    duration_s: float
    timestep_s: float
    def __post_init__(self):
        if not self.process_id.strip() or not self.process_version.strip(): raise ThermalModelError("process ID and version are required")
        if self.body_a.body_id == self.body_b.body_id: raise ThermalModelError("body IDs must be distinct")
        g = _finite("conductance_w_k", self.conductance_w_k); d = _finite("duration_s", self.duration_s); dt = _finite("timestep_s", self.timestep_s)
        if g < 0: raise ThermalModelError("conductance_w_k must be >= 0")
        if d <= 0 or dt <= 0: raise ThermalModelError("duration_s and timestep_s must be > 0")
        if dt > d: raise ThermalModelError("timestep_s cannot exceed duration_s")
        # Avoid silently truncating a final partial step or changing the requested horizon.
        n = d / dt
        if abs(n - round(n)) > 1e-10 * max(1.0, abs(n)):
            raise ThermalModelError("duration_s must be an integer multiple of timestep_s")
        object.__setattr__(self, "conductance_w_k", g); object.__setattr__(self, "duration_s", d); object.__setattr__(self, "timestep_s", dt)

@dataclass(frozen=True, slots=True)
class ThermalSample:
    time_s: float
    temperature_a_k: float
    temperature_b_k: float
    total_energy_relative_j: float
    energy_balance_error_j: float
    heat_flow_a_to_b_w: float

@dataclass(frozen=True, slots=True)
class ThermalRunResult:
    run_id: str
    process_id: str
    process_version: str
    model_id: str
    model_version: str
    integrator: str
    configuration_sha256: str
    samples: tuple[ThermalSample, ...]
    diagnostics: tuple[str, ...]

    def to_dict(self) -> dict:
        return {"run_id": self.run_id, "process_id": self.process_id, "process_version": self.process_version,
                "model_id": self.model_id, "model_version": self.model_version, "integrator": self.integrator,
                "configuration_sha256": self.configuration_sha256, "samples": [asdict(s) for s in self.samples],
                "diagnostics": list(self.diagnostics)}
    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True, allow_nan=False)

    def to_result_bundle(self):
        """Promote the sampled history into the shared result/causal-ledger format."""
        from vulc_engine.results import ResultSeries, CausalChange, ResultBundle
        times = tuple(sample.time_s for sample in self.samples)
        series = (
            ResultSeries("temperature.body_a", "temperature", "K", times,
                         tuple(sample.temperature_a_k for sample in self.samples), "body.a", self.model_id),
            ResultSeries("temperature.body_b", "temperature", "K", times,
                         tuple(sample.temperature_b_k for sample in self.samples), "body.b", self.model_id),
            ResultSeries("heat_flow.a_to_b", "heat_flow", "W", times,
                         tuple(sample.heat_flow_a_to_b_w for sample in self.samples), None, self.model_id),
            ResultSeries("energy_balance_error", "energy_balance_error", "J", times,
                         tuple(sample.energy_balance_error_j for sample in self.samples), None, self.model_id),
        )
        changes = []
        for i, sample in enumerate(self.samples[1:], start=1):
            previous = self.samples[i-1]
            changes.extend((
                CausalChange(f"{self.run_id}:body.a:{i}", sample.time_s, self.model_id, "body.a", "temperature",
                             previous.temperature_a_k, sample.temperature_a_k, "conductive coupling", self.diagnostics),
                CausalChange(f"{self.run_id}:body.b:{i}", sample.time_s, self.model_id, "body.b", "temperature",
                             previous.temperature_b_k, sample.temperature_b_k, "conductive coupling", self.diagnostics),
            ))
        return ResultBundle(self.run_id, self.process_id, self.process_version, self.configuration_sha256,
                            series, tuple(changes), {"model_id": self.model_id, "model_version": self.model_version,
                            "integrator": self.integrator, "evidence_status": "analytically_verified_for_stated_lumped_model"})

MODEL_ID = "thermal.two_body_lumped_conductance"
MODEL_VERSION = "1.0.0"

def analytical_temperatures(config: ThermalCouplingConfig, time_s: float) -> tuple[float, float]:
    """Closed-form solution for constant capacities/conductance in an isolated pair."""
    t = _finite("time_s", time_s)
    if t < 0: raise ThermalModelError("time_s must be >= 0")
    a, b, g = config.body_a, config.body_b, config.conductance_w_k
    ca, cb = a.heat_capacity_j_k, b.heat_capacity_j_k
    total_c = ca + cb
    mean = (ca*a.initial_temperature_k + cb*b.initial_temperature_k) / total_c
    if g == 0: return a.initial_temperature_k, b.initial_temperature_k
    rate = g * (1.0/ca + 1.0/cb)
    delta = (a.initial_temperature_k - b.initial_temperature_k) * math.exp(-rate*t)
    return mean + cb/total_c*delta, mean - ca/total_c*delta

def run_thermal_coupling(config: ThermalCouplingConfig) -> ThermalRunResult:
    """Execute isolated two-body thermal coupling and capture every fixed step."""
    canonical = json.dumps({"process_id": config.process_id, "process_version": config.process_version,
        "body_a": asdict(config.body_a), "body_b": asdict(config.body_b),
        "conductance_w_k": config.conductance_w_k, "duration_s": config.duration_s,
        "timestep_s": config.timestep_s}, sort_keys=True, separators=(",", ":"), allow_nan=False)
    config_hash = hashlib.sha256(canonical.encode()).hexdigest()
    run_id = "run-" + uuid.uuid4().hex[:16]
    a, b = config.body_a, config.body_b
    ca, cb, g = a.heat_capacity_j_k, b.heat_capacity_j_k, config.conductance_w_k
    initial_energy = ca*a.initial_temperature_k + cb*b.initial_temperature_k
    def rhs(_t, state):
        ta, tb = state; q = g*(ta-tb)
        return (-q/ca, q/cb)
    n = round(config.duration_s/config.timestep_s)
    t = 0.0; state = (a.initial_temperature_k, b.initial_temperature_k)
    samples = []
    for i in range(n+1):
        ta, tb = state
        energy = ca*ta + cb*tb
        samples.append(ThermalSample(t, ta, tb, energy, energy-initial_energy, g*(ta-tb)))
        if i < n:
            state = rk4_step(rhs, t, state, config.timestep_s)
            if min(state) < -1e-9 or not all(math.isfinite(x) for x in state):
                raise ThermalModelError(f"invalid numerical state at step {i+1}")
            t = (i+1)*config.timestep_s
    return ThermalRunResult(run_id, config.process_id, config.process_version, MODEL_ID, MODEL_VERSION,
        "classical RK4 fixed-step", config_hash, tuple(samples),
        ("Lumped isothermal bodies; constant heat capacities and conductance.",
         "Isolated pair: no external heat sources, losses, radiation, phase change, or spatial gradients.",
         "Energy is reported relative to the initial stored thermal energy; this model does not include an absolute energy reference."))


def register_thermal_coupling_model(registry, model_id: str = MODEL_ID,
                                    model_version: str = MODEL_VERSION) -> None:
    """Register an adapter usable by the generic Process API dispatcher.

    The process contract must declare scalar input ports named:
    heat_capacity_a, initial_temperature_a, heat_capacity_b,
    initial_temperature_b, conductance, duration, timestep; and scalar output
    ports final_temperature_a, final_temperature_b, max_energy_balance_error.
    Inputs use J/K, K, J/K, K, W/K, s, s respectively; outputs use K, K, J.
    This adapter returns summary scalars; full sample history is available from
    `run_thermal_coupling` directly and is not embedded in scalar process ports.
    """
    from vulc_engine.execution import ModelExecutionError

    def execute(context):
        values = context.inputs
        required = ("heat_capacity_a", "initial_temperature_a", "heat_capacity_b",
                    "initial_temperature_b", "conductance", "duration", "timestep")
        missing = [key for key in required if key not in values]
        if missing:
            raise ModelExecutionError("thermal adapter missing inputs: " + ", ".join(missing))
        config = ThermalCouplingConfig(
            process_id=context.process_id,
            process_version=context.process_version,
            body_a=ThermalBody("body.a", values["heat_capacity_a"], values["initial_temperature_a"]),
            body_b=ThermalBody("body.b", values["heat_capacity_b"], values["initial_temperature_b"]),
            conductance_w_k=values["conductance"], duration_s=values["duration"], timestep_s=values["timestep"],
        )
        result = run_thermal_coupling(config)
        final = result.samples[-1]
        return {
            "final_temperature_a": final.temperature_a_k,
            "final_temperature_b": final.temperature_b_k,
            "max_energy_balance_error": max(abs(sample.energy_balance_error_j) for sample in result.samples),
        }

    registry.register_callable(model_id, model_version, "vulc.physics.thermal-coupling.rk4", execute)
