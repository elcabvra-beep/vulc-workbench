"""Vulc's experimental, equation-explicit physics kernel. SI units throughout."""
from .models import (
    ModelError, radioactive_decay, gravitational_force, near_surface_weight,
    acceleration_from_force, pressure_force, coulomb_friction, quadratic_drag,
    newton_cooling, one_dimensional_impact,
)

__all__ = [
    "ModelError", "radioactive_decay", "gravitational_force", "near_surface_weight",
    "acceleration_from_force", "pressure_force", "coulomb_friction", "quadratic_drag",
    "newton_cooling", "one_dimensional_impact",
]
from .thermal_coupling import (
    ThermalModelError, ThermalBody, ThermalCouplingConfig, ThermalSample,
    ThermalRunResult, analytical_temperatures, run_thermal_coupling,
)
from .thermal_1d import Thermal1DConfig, Thermal1DResult, SpatialThermalError, run_thermal_1d
from .result_adapters import thermal_1d_result_bundle
