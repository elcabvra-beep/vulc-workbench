"""Small deterministic physics models with explicit assumptions and SI units.

These models are mathematically specified but NOT experimentally validated as a
Vulc product. Inputs are SI quantities represented as floats; units are stated
in each function's docstring. No model silently guesses missing parameters.
"""
from __future__ import annotations
import math

G = 6.67430e-11  # m^3 kg^-1 s^-2; CODATA nominal value
G0 = 9.80665      # m s^-2; conventional standard gravity

class ModelError(ValueError):
    """Input violates a model's declared domain or is not finite."""

def _finite(name: str, value: float) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError) as exc:
        raise ModelError(f"{name} must be a finite number") from exc
    if not math.isfinite(x):
        raise ModelError(f"{name} must be finite")
    return x

def _nonnegative(name: str, value: float) -> float:
    x = _finite(name, value)
    if x < 0:
        raise ModelError(f"{name} must be >= 0")
    return x

def radioactive_decay(initial_atoms: float, elapsed_s: float, half_life_s: float) -> dict:
    """Ideal single-nuclide decay: N=N0*exp(-lambda*t). Atoms, seconds, seconds.

    Returns expected remaining atom count (continuous expectation), decayed count,
    decay constant (s^-1), and activity at t (Bq). Statistical count fluctuations,
    daughter-chain effects, shielding, and radiation transport are not modeled.
    """
    n0 = _nonnegative("initial_atoms", initial_atoms)
    t = _nonnegative("elapsed_s", elapsed_s)
    h = _finite("half_life_s", half_life_s)
    if h <= 0:
        raise ModelError("half_life_s must be > 0")
    lam = math.log(2.0) / h
    remaining = n0 * math.exp(-lam * t)
    return {"remaining_atoms_expected": remaining, "decayed_atoms_expected": n0 - remaining,
            "decay_constant_per_s": lam, "activity_bq": lam * remaining,
            "model_id": "radioactive_decay.single_nuclide.exponential.v1"}

def gravitational_force(mass_a_kg: float, mass_b_kg: float, separation_m: float) -> dict:
    """Newtonian point-mass attraction: F=G*m1*m2/r^2; SI kg, kg, m -> N."""
    m1 = _nonnegative("mass_a_kg", mass_a_kg); m2 = _nonnegative("mass_b_kg", mass_b_kg)
    r = _finite("separation_m", separation_m)
    if r <= 0:
        raise ModelError("separation_m must be > 0; point-mass singularity")
    f = G * m1 * m2 / (r * r)
    return {"force_n": f, "potential_energy_j": -G * m1 * m2 / r,
            "assumption": "Newtonian point masses; weak field; non-relativistic",
            "model_id": "gravity.newtonian_point_mass.v1"}

def near_surface_weight(mass_kg: float, acceleration_m_s2: float = G0) -> dict:
    """Weight magnitude F=m*g; kg and m/s^2 -> N. g is environment supplied."""
    m = _nonnegative("mass_kg", mass_kg); g = _finite("acceleration_m_s2", acceleration_m_s2)
    if g < 0: raise ModelError("acceleration_m_s2 must be >= 0 for this magnitude model")
    return {"weight_n": m * g, "acceleration_m_s2": g, "model_id": "gravity.local_weight.v1"}

def acceleration_from_force(force_n: float, mass_kg: float) -> dict:
    """Newton's second law for net force: a=F/m; N and kg -> signed m/s^2."""
    f = _finite("force_n", force_n); m = _finite("mass_kg", mass_kg)
    if m <= 0: raise ModelError("mass_kg must be > 0")
    return {"acceleration_m_s2": f / m, "model_id": "mechanics.newton_second_law_1d.v1"}

def pressure_force(pressure_pa: float, area_m2: float) -> dict:
    """Uniform pressure on a flat area: F=p*A; Pa and m^2 -> N."""
    p = _finite("pressure_pa", pressure_pa); a = _nonnegative("area_m2", area_m2)
    return {"force_n": p * a, "assumption": "uniform pressure, flat area, magnitude only",
            "model_id": "contact.uniform_pressure_force.v1"}

def coulomb_friction(normal_force_n: float, coefficient: float, sliding: bool = True) -> dict:
    """Coulomb friction magnitude: F=mu*N. Requires user-supplied coefficient.

    For sliding=True, coefficient is interpreted as kinetic friction coefficient;
    otherwise it is a static limiting coefficient, not a solved stick/slip state.
    """
    n = _nonnegative("normal_force_n", normal_force_n); mu = _nonnegative("coefficient", coefficient)
    return {"friction_limit_or_magnitude_n": mu * n, "sliding": bool(sliding),
            "assumption": "Coulomb law; coefficient supplied by user; no wear or adhesion",
            "model_id": "contact.coulomb_friction.v1"}

def quadratic_drag(density_kg_m3: float, drag_coefficient: float, area_m2: float, velocity_m_s: float) -> dict:
    """Signed 1-D quadratic drag: Fd=-0.5*rho*Cd*A*v*abs(v). SI units."""
    rho = _nonnegative("density_kg_m3", density_kg_m3); cd = _nonnegative("drag_coefficient", drag_coefficient)
    area = _nonnegative("area_m2", area_m2); v = _finite("velocity_m_s", velocity_m_s)
    f = -0.5 * rho * cd * area * v * abs(v)
    return {"drag_force_n": f, "power_w": f * v,
            "assumption": "continuum quadratic-drag regime; Cd supplied; 1-D relative velocity",
            "model_id": "fluid.quadratic_drag_1d.v1"}

def newton_cooling(initial_temp_k: float, ambient_temp_k: float, time_s: float,
                   heat_transfer_w_m2_k: float, area_m2: float, mass_kg: float,
                   specific_heat_j_kg_k: float) -> dict:
    """Lumped-capacitance cooling/heating: T=Ta+(T0-Ta)*exp(-h*A*t/(m*cp)).

    K, K, s, W/(m^2 K), m^2, kg, J/(kg K). Assumes constant properties,
    uniform body temperature, fixed ambient and h; appropriate only when lumped
    capacitance assumptions are acceptable (typically small Biot number).
    """
    t0 = _finite("initial_temp_k", initial_temp_k); ta = _finite("ambient_temp_k", ambient_temp_k)
    t = _nonnegative("time_s", time_s); h = _nonnegative("heat_transfer_w_m2_k", heat_transfer_w_m2_k)
    area = _nonnegative("area_m2", area_m2); m = _finite("mass_kg", mass_kg); cp = _finite("specific_heat_j_kg_k", specific_heat_j_kg_k)
    if m <= 0 or cp <= 0: raise ModelError("mass_kg and specific_heat_j_kg_k must be > 0")
    tau_inv = h * area / (m * cp)
    temp = ta + (t0 - ta) * math.exp(-tau_inv * t)
    return {"temperature_k": temp, "temperature_c": temp - 273.15,
            "thermal_time_constant_s": (1.0 / tau_inv if tau_inv > 0 else math.inf),
            "assumption": "lumped isothermal body, constant properties and ambient; check Biot number",
            "model_id": "thermal.newton_cooling_lumped.v1"}

def one_dimensional_impact(mass_a_kg: float, velocity_a_m_s: float, mass_b_kg: float,
                           velocity_b_m_s: float, restitution: float) -> dict:
    """1-D two-body collision using coefficient of restitution e in [0,1].

    Masses kg, velocities m/s. Returns post-impact velocities and kinetic energy
    loss. This is a rigid-body collision model, NOT a smearing/plastic-deformation,
    fracture, heat-generation, or material-mixing model.
    """
    m1 = _finite("mass_a_kg", mass_a_kg); m2 = _finite("mass_b_kg", mass_b_kg)
    u1 = _finite("velocity_a_m_s", velocity_a_m_s); u2 = _finite("velocity_b_m_s", velocity_b_m_s)
    e = _finite("restitution", restitution)
    if m1 <= 0 or m2 <= 0: raise ModelError("impact masses must be > 0")
    if not 0 <= e <= 1: raise ModelError("restitution must be in [0, 1]")
    if u1 <= u2: raise ModelError("Bodies must be approaching in the chosen positive axis convention (u_a > u_b)")
    v1 = ((m1 - e*m2)*u1 + (1+e)*m2*u2) / (m1+m2)
    v2 = ((m2 - e*m1)*u2 + (1+e)*m1*u1) / (m1+m2)
    ke_before = 0.5*m1*u1*u1 + 0.5*m2*u2*u2
    ke_after = 0.5*m1*v1*v1 + 0.5*m2*v2*v2
    return {"velocity_a_after_m_s": v1, "velocity_b_after_m_s": v2,
            "kinetic_energy_before_j": ke_before, "kinetic_energy_after_j": ke_after,
            "kinetic_energy_loss_j": ke_before-ke_after, "restitution": e,
            "assumption": "1-D rigid-body collision; no deformation, fracture, heat, or mixing",
            "model_id": "contact.impact_1d_restitution.v1"}
