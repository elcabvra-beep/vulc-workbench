"""Thermal flux across a planar interface between two materials.

Steady 1-D series resistance law, positive flux from left to right:
q'' = (T_L - T_R) / (dx_L/(2*k_L) + R_contact + dx_R/(2*k_R)).
Units: K / (m^2 K/W) = W/m^2. This is an interface closure, not a full solver.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

class ThermalInterfaceError(ValueError): pass

@dataclass(frozen=True, slots=True)
class InterfaceFluxResult:
    heat_flux_w_m2: float
    total_resistance_m2_k_w: float
    left_temperature_drop_k: float
    contact_temperature_drop_k: float
    right_temperature_drop_k: float
    def to_dict(self):
        return {"heat_flux_w_m2": self.heat_flux_w_m2,
                "total_resistance_m2_k_w": self.total_resistance_m2_k_w,
                "left_temperature_drop_k": self.left_temperature_drop_k,
                "contact_temperature_drop_k": self.contact_temperature_drop_k,
                "right_temperature_drop_k": self.right_temperature_drop_k}

def planar_interface_flux(left_temperature_k: float, right_temperature_k: float,
                          left_conductivity_w_m_k: float, right_conductivity_w_m_k: float,
                          left_cell_width_m: float, right_cell_width_m: float,
                          contact_resistance_m2_k_w: float = 0.0) -> InterfaceFluxResult:
    vals=(left_temperature_k,right_temperature_k,left_conductivity_w_m_k,right_conductivity_w_m_k,
          left_cell_width_m,right_cell_width_m,contact_resistance_m2_k_w)
    if any(not math.isfinite(float(v)) for v in vals): raise ThermalInterfaceError("all inputs must be finite")
    if left_temperature_k < 0 or right_temperature_k < 0: raise ThermalInterfaceError("absolute temperatures cannot be below 0 K")
    if min(left_conductivity_w_m_k,right_conductivity_w_m_k,left_cell_width_m,right_cell_width_m) <= 0:
        raise ThermalInterfaceError("conductivities and cell widths must be positive")
    if contact_resistance_m2_k_w < 0: raise ThermalInterfaceError("contact resistance cannot be negative")
    rl=left_cell_width_m/(2*left_conductivity_w_m_k); rr=right_cell_width_m/(2*right_conductivity_w_m_k)
    total=rl+contact_resistance_m2_k_w+rr
    q=(left_temperature_k-right_temperature_k)/total
    return InterfaceFluxResult(q,total,q*rl,q*contact_resistance_m2_k_w,q*rr)
