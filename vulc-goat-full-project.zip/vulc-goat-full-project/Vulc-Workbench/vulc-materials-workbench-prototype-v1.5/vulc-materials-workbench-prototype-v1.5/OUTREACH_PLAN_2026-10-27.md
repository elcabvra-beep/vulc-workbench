# Vulc Workbench — Early-adopter outreach plan

Date: 2026-10-27

## Positioning

Invite reviewers to evaluate a small, reproducible research-software prototype—not to endorse a production-qualified engineering solver. The first testable contribution is a GOAT declarative script that compiles to a validated process contract and dispatches an allow-listed two-body lumped thermal model. Its numerical behavior is checked against a closed-form reference and conservation checks. It currently supports one model and one process only; `connect()` and `use()` are deliberately rejected by the compiler. Experimental validation and general material-property provenance remain future work.

## Priority outreach targets

1. **Sandia National Laboratories — Materials Science and Engineering Center**
   - Fit: nearby research group with materials structure/property/performance, computational methods, and external collaboration pathways.
   - Public user liaison listed by Sandia: Coby Davis, cldavis@sandia.gov, (505) 284-9524; the page lists the MSE Center and directs interested parties to contact the user liaison.
   - Ask: Is there an appropriate materials modeling/software researcher who could spend 20 minutes reviewing the benchmark and identifying one realistic, low-risk use case? Do not imply endorsement or access to restricted programs.
   - Sources: https://www.sandia.gov/working-with-sandia/technology-deployment-centers/materials-science-and-engineering-center-mse/ and https://www.sandia.gov/research/area/materials-and-advanced-manufacturing/

2. **NIST — Center for Theoretical and Computational Materials Science (CTCMS)**
   - Fit: explicitly focuses on developing/solving/quantifying materials models and integrating tools into industrial research.
   - Public contact shown on the CTCMS page: Andrew C. E. Reid; use the official contact route on the page.
   - Ask: Could they recommend a relevant open benchmark, working group, or public validation resource for the next iteration? Ask for feedback, not certification.
   - Source: https://www.nist.gov/programs-projects/nistmml-center-theoretical-and-computational-materials-science

3. **Materials Project community**
   - Fit: established materials-data/software community with explicit paths for code contributors, domain experts, documentation, and data contributors.
   - Route: join the Materials Project forum at https://matsci.org/materials-project; developers should follow the contributor guide. Their documentation describes a weekly infrastructure update call request path for collaboration proposals.
   - Ask: feedback on the data/provenance roadmap and advice on interoperable data models; do not present Vulc as a replacement for Materials Project.
   - Source: https://docs.materialsproject.org/community/getting-involved and https://docs.materialsproject.org/community/getting-involved/potential-collaborators

4. **OPTIMADE developers**
   - Fit: API interoperability for materials databases; useful later if Vulc adds external material-data adapters.
   - Route: dev@optimade.org for first contact; the project also points to matsci.org and GitHub issues.
   - Ask: what compatibility expectations and existing clients should guide a future read-only materials-data adapter? Do not claim OPTIMADE compatibility until implemented and tested.
   - Source: https://www.optimade.org/community

5. **MolSSI — Molecular Sciences Software Institute**
   - Fit: community-driven software workshops for researchers across academia, industry, and national labs; prior workshop topics include interoperability, materials science, and software best practices.
   - Route: https://molssi.org/workshops/
   - Ask: whether a future community workshop, software-practices review, or relevant community channel is appropriate once the prototype has a public repository and reproducible quickstart.
   - Source: https://molssi.org/workshops/

6. **Materials Research Society (MRS)**
   - Fit: community and virtual workshop route for materials researchers.
   - Timely possibility: MRS lists a virtual workshop on “Bridging Human Expertise, Intelligent Agents and Algorithms for Autonomous Science” for November 4–5, 2026. Check registration and participation rules immediately; the event is not assumed to accept unsolicited talks or demos.
   - Route: https://www.mrs.org/publications-digital-content/webinars-workshops/virtual-workshops
   - Ask: whether there is a public forum, future workshop, or demo/submission path for open research-software prototypes.

## Ownership, licensing, and community tone

The project owner retains copyright in original project-owned work. The intention is to grant broad open-source permissions to use, modify, redistribute, and build upon the software, while allowing users to produce their own content with it. Do not claim that the project owns user-created output merely because Vulc generated it. Choose a standard software license and a separate content license for documentation; see `LICENSING_POLICY_DRAFT.md`. The social invitation is voluntary and belongs in community material, not in the software license.

The project owner also welcomes informal conversation and, if a team has an appropriate open spot, an opportunity to hang out or visit. Make the request respectfully and without expectation. A remote conversation, public meetup, or pointer to a community event is just as welcome. Do not imply that reviewers owe personal time, hosting, travel, accommodation, employment, or special access.

## 10-business-day plan

- **Days 1–2:** Publish the ZIP, checksum, test report, example GOAT script, and explicit limitations in a public repository. Add a license, issue templates, a one-command quickstart, and a security/support policy before inviting external use.
- **Days 2–3:** Send tailored requests to Sandia and NIST asking for one technical reviewer and one benchmark recommendation. Use only official public channels and respect institutional external-contact rules.
- **Days 3–5:** Post a short, transparent project introduction in the Materials Project forum and ask OPTIMADE about future adapter expectations. Do not spam issue trackers; open an issue only for a specific, relevant interoperability question.
- **Days 5–7:** Ask MolSSI and MRS about the appropriate channel for a future demonstration or community review.
- **Days 8–10:** Hold one remote walkthrough if anyone responds; log feedback as issues; choose one externally defined benchmark; publish a change log and repeatable results.

## First message template

Subject: Request for technical feedback on a small, reproducible materials-modeling software prototype

Hello,

I’m developing Vulc Workbench, an early-stage open research-software prototype intended to make model execution more explicit and auditable. The current demonstrator compiles a small GOAT declarative script into a validated process contract and runs an allow-listed two-body thermal model. The narrow benchmark is checked against a closed-form reference and energy-balance diagnostics.

I want to be clear about its scope: this is not a generally validated or production-qualified engineering solver. The current compiler supports one thermal model; multi-process connections, general material-property provenance, and experimental validation remain incomplete.

Would someone in your group be willing to suggest one suitable public benchmark or spend 20 minutes reviewing the workflow and its limitations? A short written critique is equally helpful. I can provide the reproducible example, test report, and source archive. I retain copyright in original work I own while aiming to release the software under a standard open-source license; I do not claim ownership of your independently created output merely because you use it.

On a personal note, if your group ever has an open spot for a casual visit, public meetup, or informal hangout, I’d be glad to be considered. I’d also welcome a conversation when it fits your schedule. There is no pressure at all—a short remote chat or a pointer to an appropriate community event is equally appreciated. I understand that time, visitor rules, and boundaries come first.

If this is not the right contact, I would appreciate a pointer to the appropriate public software or materials-modeling community.

Thank you,
Vulc Workbench project

## Outreach ethics and credibility

- No claims of endorsement, validation, or institutional affiliation without explicit permission.
- Do not send confidential, export-controlled, proprietary, or sensitive data to the prototype.
- Ask for critique and a benchmark first; do not ask researchers to certify it.
- Do not describe numerical verification as experimental validation.
- Keep a public record of assumptions, limitations, reviewer consent, and resulting changes.
