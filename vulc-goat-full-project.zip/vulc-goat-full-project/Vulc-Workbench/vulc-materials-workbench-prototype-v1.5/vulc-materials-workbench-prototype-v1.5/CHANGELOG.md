# Changelog

## 0.6.0 — Runtime dispatcher

- Added `ExecutableModelRegistry` for allow-listed callable model implementations.
- Added `execute_process()` to validate, compile, and execute acyclic contracts in deterministic topological order.
- Added execution context, per-model records, structured result serialization, timestamps, configuration hashes, and model-level diagnostics.
- Added scalar unit conversion across links using reviewed SI scale factors.
- Runtime explicitly rejects unsupported spatial mappings, event/observe-only links, non-physical-time links, nonzero delays, multiple producers for one input, unsupported field kinds, missing inputs/outputs, non-finite values, and undeclared outputs.
- Added dispatcher tests for execution, unit conversion, failure paths, missing inputs, and unsupported mappings.
- Registered the lumped thermal benchmark as an executable Process API model and added an end-to-end example plus integration test.

The generic dispatcher is an early vertical slice. It is not yet connected to the lumped thermal benchmark as a process model, does not execute spatial fields, and does not support iterative/two-way coupled solving.

## 0.7.0 — engineering milestones 1–5
- Added first-class result series, result bundles, content hashes, and explicit causal-change records.
- Added relaxed Picard fixed-point coupling solver with tolerance-based convergence, iteration history, and explicit failure modes. This is a numerical primitive, not an assertion that arbitrary coupled physics will converge.
- Added 1-D cell-centered finite-volume transient heat conduction with insulated boundaries, volumetric source, explicit stability-limit enforcement, energy accounting, and serialized spatial histories.
- Added a loopback-only Python HTTP bridge for actual semantic contract validation from the browser editor (`python -m vulc_engine.service`); browser preflight remains separately labeled.
- Added numerical verification tests for coupling convergence, thermal uniform-state preservation, energy balance, diffusion direction, and stability rejection.
- Limitations: spatial thermal model currently assumes uniform 1-D cells, constant properties, insulated ends, explicit Euler; no contact/interface boundary conditions, phase change, nonlinear properties, multidimensional geometry, or experimental validation. Coupling solver is fixed-point only; no adaptive Newton/Anderson methods or time-co-simulation scheduler.
- The two-body thermal benchmark can now export its complete history through `ThermalRunResult.to_result_bundle()`, including temperature, heat-flow and energy-residual series plus per-step declared causal-change entries.
- Added `examples/run_thermal_1d.py` for a spatially resolved temperature history.
- Verification status: 62 automated tests pass; compileall succeeds; both lumped and spatial examples execute. The browser bridge was smoke-tested over loopback.


## 0.8.0 — Auditable spatial results

- Added `thermal_1d_result_bundle()` adapter to export the spatial heat solver into common `ResultBundle`/`ResultSeries`/`CausalChange` records.
- Fixed `ResultSeries` validation so spatial time-major arrays are validated against `time_count × coordinate_count`, while scalar series still require one value per time.
- Added adapter tests for flattened dimensions, state-transition attribution, reproducible artifact hashes, and configuration mismatch rejection.
- Spatial example now emits both solver-native history and the common result bundle.
- Documented FMI, W3C PROV, and method-of-manufactured-solutions as architecture/verification references; no conformance or experimental validation is claimed.

## 0.9.0 — Field contracts and interface closure
- Added `FieldValue`, a first-class finite scalar-valued field container with explicit shape, domain, optional coordinates/frame, unit-aware conversion, and strict scalar-vs-spatial validation.
- Preserved ergonomic numeric values for global/region scalar ports; spatial cell/point/face/particle/grain fields must use `FieldValue` in the execution runtime.
- Extended process execution to accept/return typed spatial fields and permit identity transfer only when support and domain topology are compatible. Global-value transfer remains scalar-only; interpolation, projection, events, and observations still fail closed until explicit operators exist.
- Added a planar two-material thermal interface closure with contact resistance and decomposed temperature drops. This is a tested closure equation, not yet wired into the 1-D transient solver.
- Added field-contract and interface-flux tests.

## 1.2 — Typed GOAT declarative parser (work in progress)

- Added `vulc_engine.goat_script`: a non-executing parser that produces a typed AST for `material`, `process`, `factor`, `connect`, and `use` declarations.
- Added line/column diagnostics for unsupported statements, malformed literals/arguments, duplicate process aliases, missing model references, incomplete factors, and undeclared connection aliases.
- Added `POST /api/parse` to the loopback-only development service and a Script Composer action to request the AST from that parser.
- Parser rejects arbitrary executable code and does not use `eval` or execute scripts.
- Six parser tests added. Existing engine suite: 80 tests passing.
- Still not implemented: persistent method/snippet library, registry-backed model/port resolution for script declarations, automatic conversion of AST to a fully valid `ProcessDefinition`, and execution of composed scripts.

## 1.3 — Execution identity and provenance correctness
- Separated per-invocation `run_id` from the deterministic process-configuration SHA-256. Repeated executions of the same process now receive distinct run IDs while retaining the same configuration hash, preventing run artifacts from being mistaken for the same execution.
- Added a regression test for unique run identity and stable configuration identity.
- This release does not add spatial remapping; interpolation and conservative projection still fail closed until registered operators and explicit source/target domains are implemented.


## 1.4.0 — test-run correction

- Direct thermal-coupling runs now receive unique execution IDs; the configuration SHA-256 remains stable for identical inputs.
- Updated repeatability test to distinguish run identity from deterministic numerical samples.
- This release does not add the missing GOAT-script-to-dispatch compiler bridge or material-property provenance/uncertainty registry.

## 1.5.0 — GOAT-to-solver bridge (experimental)
- Added a fail-closed compiler for a deliberately narrow single-process GOAT thermal subset.
- Added end-to-end compilation, contract validation, allow-listed model dispatch, and JSON result example.
- Added tests for numerical output, factor input, unknown model/arguments, unsupported connections, missing inputs, and missing callable implementations.
- This is not a general GOAT compiler: multi-process graphs, `connect()` execution, `use()` expansion resolution, and arbitrary model families remain unsupported.
