# Vulc Platform

Vulc is the umbrella platform. This bundle currently contains:

- **GoatMaterials** — materials engineering API, web workbench, materials state catalog, metallurgy gravity utilities, Data Fabric reference, solver-manager planning, full API documentation, API website, and press kit.
- **Solver Data Driver — Project Maven** — math/logic and solver-data orchestration foundations.
- **Full Goatmetal Jacket** — optional creative theme and fictional universe.

## Latest GoatMaterials API release

- Website: `GoatMaterials/web/api-site/index.html`
- Documentation: `GoatMaterials/docs/`
- OpenAPI schema: `GoatMaterials/docs/openapi.json`
- Press kit: `GoatMaterials/presskit/`
- Backend: `GoatMaterials/backend/`

The API has request IDs, security headers, configurable API-key enforcement for `/api/...` routes, health probes, OpenAPI documentation, and a non-root container starter. Before public production use, follow `GoatMaterials/docs/PRODUCTION_DEPLOYMENT.md`, especially the notes about legacy root-level routes, gateway-based rate limiting, and authentication. The current API does not include a validated multiphysics solver or distributed durable Data Fabric broker.
