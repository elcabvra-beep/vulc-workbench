# Rename notes

Agreed display-name mapping:
- GOAT platform umbrella → **Vulc**
- GOAT Materials / materials and data API → **GoatMaterials**
- Solver orchestration / data API project → **Solver Data Driver (Project Maven)**
- Super-future space-cowboy-in-the-city theme → **Full Goatmetal Jacket**

This is a packaging/display rename. Existing Python namespaces and API paths are intentionally preserved to avoid breaking imports and clients. A later breaking-change release can introduce package and endpoint aliases with deprecation notices.
