# Vulc GoatMaterials API — Press Kit

## Product name
**Vulc GoatMaterials API**

## One-line description
An extensible materials-engineering API that brings material catalogs, crystallography utilities, gravity-environment inputs, phase taxonomy, and solver-data orchestration under one documented interface.

## Short description (50 words)
Vulc GoatMaterials API provides a modular interface for materials data and engineering workflows. It includes element and material-state catalogs, crystallography helpers, gravity and acceleration environment utilities, solver capability planning, and an in-process data-fabric reference. OpenAPI documentation and a static API portal help developers integrate components while preserving clear scientific limitations.

## Boilerplate (about 100 words)
Vulc is an extensible engineering platform with GoatMaterials as its materials-science and metallurgy suite. The GoatMaterials API exposes a documented JSON interface for element data, crystallography utilities, material-state taxonomy, gravity and acceleration environments, solver capability planning, and Data Fabric coordination primitives. The API is designed to support client applications, dataset adapters, and future validated solver integrations through explicit schemas and component boundaries. Its OpenAPI contract, interactive API documentation, and browser-based portal make the current interface discoverable. The current release is a development-to-deployment foundation: solver planning and reference coordination are available, but a validated multiphysics solver and distributed hard-real-time broker are not bundled.

## Key capabilities

- Materials and periodic-table catalog endpoints.
- Crystallography geometry helpers: unit-cell volume, cubic d-spacing, and Bragg angle.
- Material-state taxonomy including plasma, supercritical regimes, and liquid metallic hydrogen as a liquid phase with metallic electronic behavior.
- Metallurgical gravity/acceleration environment descriptions and simplified dimensional-analysis helpers.
- Solver manifests, capability checks, and coupling-plan generation.
- Data Fabric register, factor, coupling, trigger, action, and event interfaces.
- OpenAPI schema, Swagger UI, ReDoc, and static API website.

## Current limitations (include in accurate coverage)

- No validated physics or multiphysics solver is bundled.
- Solver registry entries are declarations, not proof of installed or runnable binaries.
- Material-state conditions endpoint does not predict phase stability.
- Data Fabric is in-process and not a durable distributed broker or hard-real-time runtime.
- Production use requires deployment-specific controls, external rate limiting, authorization policy, monitoring, and scientific validation.

## Suggested announcement

**Vulc introduces the GoatMaterials API portal and v1 interface foundation**

Vulc has published a documented API foundation for its GoatMaterials engineering suite. The release groups materials catalogs, crystallography helpers, gravity-environment inputs, material-state taxonomy, solver capability planning, and Data Fabric primitives behind a discoverable HTTP/JSON interface. The accompanying portal provides component descriptions, an endpoint directory, and a browser-based GET explorer. The release is intended to help developers integrate data and prepare validated solver adapters; it does not claim to include a production multiphysics solver.

## Brand guidance

- Product lockup: `VULC / GoatMaterials API`
- Tone: technical, candid, modular, open to extensions.
- Avoid claims such as “predicts all materials,” “fully validated multiphysics,” “hard real-time,” or “production-certified.”
- Do not imply that third-party solver candidates are bundled or automatically installed.

## Media files

The source bundle includes the static API website. No trademark-cleared logo or official photography is included in this release; create/approve those separately before external press use.
