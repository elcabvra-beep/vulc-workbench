# Architecture

## Layers

1. **HTTP/API layer** — FastAPI request parsing, validation, OpenAPI generation, CORS policy, request IDs, security headers, optional API-key middleware.
2. **Domain catalogs and utilities** — periodic table, material-state taxonomy, crystallography helpers, gravity/acceleration helper functions, visualization metadata.
3. **Solver Manager** — solver manifest registry, capability resolver, and coupling planner. It creates plans; it does not launch arbitrary solver processes.
4. **Data Fabric** — typed registers, source sampling, factor/coupling manifests, trigger/action events, and a manifold inspection interface. Current storage is process-local.
5. **Client website** — static API portal with component overview, endpoint catalog, and browser-side GET explorer.
6. **Optional solver adapters** — future extension points. Each adapter needs pinned dependencies, input/output schemas, provenance, validation benchmarks, resource limits, and an explicit execution policy.

## Request path

`Client → TLS ingress → API authentication/authorization → request validation → domain service → structured JSON response + request ID`

For production deployments, terminate TLS at a trusted ingress, enforce quotas and request limits there, export structured logs/metrics, and use an external durable store or broker if multiple workers/nodes must share fabric state.

## Scientific integrity

- Catalog taxonomy is not phase prediction.
- Solver manifests are not proof that a solver is installed or validated.
- Illustrative profiles are not physical results.
- Every future solver adapter should report units, solver/version, source inputs, mesh/time settings, convergence, uncertainty, and validation references.
