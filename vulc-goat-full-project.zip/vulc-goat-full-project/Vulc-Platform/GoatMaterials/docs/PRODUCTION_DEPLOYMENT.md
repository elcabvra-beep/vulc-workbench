# Production Deployment Guide

This guide establishes a hardened deployment baseline. It does not certify the current reference fabric or solver planning layer as a production scientific computing service. Complete the checklist for your environment before exposing the API publicly.

## 1. Required environment

- `GOAT_ENV=production`
- `GOAT_API_KEYS`: comma-separated high-entropy API secrets, supplied from a secret manager.
- `GOAT_CORS_ORIGINS`: comma-separated exact origins, no wildcard when credentials or sensitive access are involved.
- `GOAT_FABRIC_SEED`: optional reproducibility seed for in-process deterministic sources.

Example (development only):

```bash
export GOAT_ENV=production
export GOAT_API_KEYS="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export GOAT_CORS_ORIGINS="https://materials.example.org"
```

Do not paste secrets into shell history on shared systems; prefer a secrets manager or orchestrator secret. The optional API-key middleware currently protects `/api/...` paths. The older root-level utility routes remain for compatibility, so a public deployment must also protect those routes with an API gateway, reverse-proxy policy, or a follow-up route migration.

## 2. Local run

```bash
cd GoatMaterials/backend
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
uvicorn goat_materials.api:app --host 127.0.0.1 --port 8000
```

Do not bind a development server directly to the public internet. For a single-host test with a reverse proxy, bind only to loopback and let the proxy terminate TLS.

## 3. Container build

A minimal Dockerfile is included in `backend/Dockerfile`. Build and run:

```bash
docker build -t vulc-goatmaterials-api:1.0.0 GoatMaterials/backend
docker run --rm -p 127.0.0.1:8000:8000 \
  -e GOAT_ENV=production \
  -e GOAT_API_KEYS="$GOAT_API_KEYS" \
  -e GOAT_CORS_ORIGINS="https://materials.example.org" \
  vulc-goatmaterials-api:1.0.0
```

Use a trusted image registry, pin base images by digest in your release pipeline, scan the image, and run as a non-root user. The included Dockerfile is a starter baseline; adapt it to your organization's image-hardening standards.

## 4. Security controls required before internet exposure

- Put a TLS-enabled API gateway/reverse proxy in front of the service.
- Protect all endpoints, including legacy root-level routes; the current optional API-key middleware only gates `/api/...`.
- Add centralized rate limiting and concurrency quotas. Do not rely on in-memory per-process rate limiting for a multi-worker deployment.
- Enforce maximum request-body size, upload limits, timeouts, and connection limits at the gateway.
- Store API keys in a secrets manager; rotate/revoke them; never log them.
- Restrict CORS to exact trusted website origins.
- Add role-based authorization if different users may read, write, or administer resources.
- Use dependency lockfiles, vulnerability scans, software bill of materials, signed release artifacts, and automated patching.
- Export structured logs, metrics, traces, and request IDs; redact secrets and sensitive inputs.
- Add backup/restore and disaster-recovery tests for any future persistent database or event store.

## 5. Operational readiness

- Configure `/health/live` for liveness and `/health/ready` for readiness.
- Monitor 4xx/5xx rates, latency percentiles, request volume, memory, CPU, worker restarts, and dependency health.
- Define a release rollback strategy and compatibility/deprecation policy.
- Run tests and schema-diff checks in CI for every release.
- Test under expected load and failure conditions; the reference implementation has no durable distributed fabric.

## 6. Scientific readiness gate

Before using output for engineering decisions, require a validated solver implementation, versioned input/output schema, unit system, convergence criteria, uncertainty accounting, benchmark suite, provenance, and independent comparison against experimental or accepted reference data. The current API explicitly reports that no validated physics solver is bundled.
