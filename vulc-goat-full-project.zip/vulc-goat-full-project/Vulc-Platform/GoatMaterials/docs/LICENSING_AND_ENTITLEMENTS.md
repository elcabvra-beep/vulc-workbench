# Vulc Licensing and Entitlements — Implementation Draft

## Product IDs

- `gravity_api` — Gravity API
- `gravity_lab_suite` — Gravity Lab Suite
- `exotic_materials_api` — Exotic Materials API
- `exotic_materials_suite` — Exotic Materials Suite

Vulc Core remains free. Sometimes Lonely Space Punk is the Gravity theme. Full Goatmetal Jacket: Cowboy Action Pack is the Exotic Materials theme; the intended Cowboy Action Pack price is $200. Themes are presentation/packaging, not the scientific capability itself.

## License behavior

The initial local verifier accepts `X-Vulc-License`. `VULC_LICENSES_JSON` contains a JSON array of records. Each record contains:

- `key_sha256`: SHA-256 digest of the customer's license key, never the raw key
- `products`: product IDs licensed
- `perpetual_major_version`: highest major version the user can keep running perpetually
- `major_updates_through`: highest major version included in the update entitlement
- `data_access_until`: ISO date through which online/curated data access is active; null grants no data access

A license for the purchased product version remains valid after data access expires. Current API product major version is 1. `GET /api/v1/license/status` reports the entitlement view for the supplied key. `GET /api/v1/products` lists product IDs. Paid endpoints return HTTP 402 when product entitlement is absent or required data access is expired.

## Current paid routes

- Gravity API: `/api/v1/metallurgy/gravity` and its environment, hydrostatic-pressure, and Bond-number endpoints require `gravity_api`.
- Gravity Lab Suite: `/api/v1/gravity-lab/status` requires `gravity_lab_suite`.
- Exotic material data: non-conventional material-state details, conditions, `/api/v1/exotic-materials`, and explicit non-conventional family queries require `exotic_materials_api` plus active data access.
- Exotic Materials Suite: `/api/v1/exotic-materials-suite/status` requires `exotic_materials_suite`.
- The free material-state listing returns conventional-family records without an active exotic-material entitlement.

## Issue a local development license

From `GoatMaterials/backend`:

```bash
python tools_issue_license.py \\
  --key 'replace-with-a-long-random-secret' \\
  --products gravity_api,gravity_lab_suite \\
  --perpetual-major-version 1 \\
  --major-updates-through 1 \\
  --data-until 2027-10-27
```

Put the resulting JSON in `VULC_LICENSES_JSON` using a secret manager. Send the raw key to the customer through a secure channel; never commit it or log it.

## Explicit limitations — not yet a commercial billing system

This is a local entitlement gate for development and controlled pilots, not a complete commercial license service. It has no customer database, checkout, signed issuance, revocation portal, payment/refund/tax workflow, rate metering, or renewal automation. Environment-backed records require a service restart to change. Deploy behind HTTPS, keep the product license distinct from the general API key, and move records to a managed store before broad public release. A security review is required before relying on it for valuable content.

The suite status endpoints describe current scaffold capability; they do not imply that validated physics solvers or phase-equilibrium prediction are implemented.
