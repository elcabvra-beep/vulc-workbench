# Vulc GoatMaterials API — Reference v1.0.0

## Overview

The API provides materials catalogs and utilities plus coordination interfaces for clients and solver adapters. JSON is the primary representation. Interactive OpenAPI docs are served at `/docs`; ReDoc is at `/redoc`; the machine-readable contract is `/openapi.json`.

### Base URL

Local development: `http://127.0.0.1:8000`  
Production: use your HTTPS origin, e.g. `https://api.your-domain.example`.

### Authentication

When `GOAT_API_KEYS` is configured, `/api/...` routes require either `X-API-Key: <key>` or `Authorization: Bearer <key>`. The environment variable accepts comma-separated keys. Use high-entropy values from a secret manager and rotate them. Root-level legacy utility routes are not covered by this optional API-key middleware in the current compatibility release; put the service behind an authenticated gateway or restrict those routes before public exposure. If `GOAT_ENV=production` and no keys are configured, `/api/...` returns `503` rather than silently exposing those routes.

### Common headers

- `Accept: application/json`
- `Content-Type: application/json` for JSON request bodies
- `X-Request-ID` is generated if absent and returned in the response. Supply a unique ID to correlate client logs.

### Error behavior

- `400`/`422`: malformed or semantically invalid request (most Pydantic/domain validation is `422`).
- `401`: missing or invalid API key on protected routes.
- `404`: requested resource not found.
- `503`: production API key configuration missing for `/api/...` routes.
- `5xx`: unexpected service failure; correlate with `X-Request-ID` and server logs.

FastAPI validation errors retain the standard `detail` response format. Middleware-generated errors use `{ "error": { "code": "...", "message": "..." }, "request_id": "..." }`.

## Operations and discovery

| Method | Path | Purpose |
|---|---|---|
| GET | `/health` | Basic service health and planning-only solver status |
| GET | `/health/live` | Liveness probe |
| GET | `/health/ready` | Readiness metadata and physics-solver availability |
| GET | `/capabilities` | High-level capability summary and known limitations |
| GET | `/openapi.json` | OpenAPI schema |
| GET | `/docs` | Swagger UI |
| GET | `/redoc` | ReDoc UI |

Example:

```bash
curl -s http://127.0.0.1:8000/health/ready
```

## Materials and scientific utilities

| Method | Path | Purpose |
|---|---|---|
| GET | `/periodic-table` | Periodic table catalog |
| GET | `/elements/{symbol}` | Element lookup by symbol |
| GET | `/profiles/domains` | Supported profile domains and coupled phenomena vocabulary |
| GET | `/crystallography/systems` | Crystal-system names and caveats |
| POST | `/crystalmath/cell-volume` | Unit-cell volume from lengths and angles |
| POST | `/crystalmath/d-spacing-cubic` | Cubic lattice d-spacing |
| POST | `/crystalmath/bragg-angle` | Bragg angle helper |
| GET | `/visualization/kinds` | Portable visualization kinds |
| GET | `/agents` | Demo agent registry |
| POST | `/agents/route` | Route a task against the demo registry |

### Unit-cell volume request

```json
{"a": 4.05, "b": 4.05, "c": 4.05, "alpha": 90, "beta": 90, "gamma": 90}
```

`POST /crystalmath/cell-volume` returns a numeric `volume` and a generic `length^3` unit label. The caller must ensure all lengths use the same unit. This is a geometric calculation, not structure refinement.

### Cubic d-spacing request

```json
{"a": 4.05, "h": 1, "k": 1, "l": 1}
```

`POST /crystalmath/d-spacing-cubic` returns `d_spacing` in the same length unit as `a`. `(h,k,l)=(0,0,0)` is invalid.

### Bragg angle request

```json
{"wavelength": 1.5406, "d": 2.338, "order": 1}
```

`POST /crystalmath/bragg-angle` returns `theta_degrees`. Inputs must use matching length units; the request uses Bragg's law and rejects impossible geometry. It does not model instrument broadening or full diffraction patterns.

## Solver Manager

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/solvers` | List solver manifests |
| GET | `/api/v1/solvers/{solver_id}` | Read a solver manifest |
| POST | `/api/v1/solvers/check` | Check capability compatibility |
| POST | `/api/v1/solvers/plan` | Produce a coupling plan |
| GET | `/api/v1/solver-manager/status` | Status and execution caveat |
| GET | `/api/v1/solver-addons` | List optional solver candidates |
| GET | `/api/v1/solver-addons/{addon_id}` | Add-on metadata |
| POST | `/api/v1/solver-addons/{addon_id}/install-plan` | Return an installation plan; does not install software |

Example plan request:

```json
{
  "required_domains": ["thermal", "mechanical", "phase"],
  "mode": "coupled",
  "primary_solver": "goat.core",
  "allow_specialists": true,
  "allow_untrusted": false,
  "require_validation": true,
  "requested_methods": {},
  "required_couplings": [],
  "time_start_s": 0,
  "time_stop_s": 1,
  "target_relative_tolerance": 0.00001,
  "input_model": {"material_id": "example-alloy"}
}
```

The response is a compatibility/plan document. Registry declarations do not prove that a solver binary exists, is installed, or is scientifically validated. The current distribution does not bundle a validated multiphysics solver.

## Material states and phases

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/material-states` | List catalog; optional `family` and `query` filters |
| GET | `/api/v1/material-states/{state_id}` | Fetch one catalog entry |
| POST | `/api/v1/material-states/conditions` | Attach temperature/pressure metadata to a selected state label |

Example:

```json
{"state_id":"metallic_hydrogen_liquid", "temperature_k": 3000, "pressure_pa": 100000000000}
```

This endpoint is not a phase-equilibrium engine and does not decide which state is stable at those conditions. For scientific use, use validated phase diagrams, equations of state, and provenance.

## Metallurgy gravity and acceleration

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/metallurgy/gravity` | Supported modes, fields, helper calculations, limitations |
| POST | `/api/v1/metallurgy/gravity/environment` | Describe a gravity/acceleration environment |
| POST | `/api/v1/metallurgy/gravity/hydrostatic-pressure` | Simplified hydrostatic pressure difference |
| POST | `/api/v1/metallurgy/gravity/bond-number` | Bond-number dimensional-analysis helper |

Environment example:

```json
{
  "mode": "hypergravity",
  "acceleration_m_s2": 98.0665,
  "direction": [0, 0, -1],
  "frame": "rotating",
  "rotation_rate_rad_s": 10,
  "radius_m": 0.980665,
  "note": "Illustrative centrifuge field"
}
```

Modes are `microgravity`, `reduced_gravity`, `terrestrial`, `hypergravity`, and `custom`; frames are `inertial` and `rotating`. These endpoints describe inputs and compute simplified helpers. They do not model full rotating-frame flow, Coriolis effects, spatially varying gravity, free surfaces, or solidification physics.

Hydrostatic request:

```json
{"density_kg_m3": 7800, "acceleration_m_s2": 9.80665, "height_m": 0.5}
```

Bond number request:

```json
{"density_difference_kg_m3": 1000, "acceleration_m_s2": 9.80665, "length_m": 0.01, "surface_tension_n_m": 0.7}
```

## Data Fabric

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/fabric` | Fabric capabilities/status |
| POST | `/api/v1/fabric/registers` | Create typed register |
| GET | `/api/v1/fabric/registers` | List registers |
| PUT | `/api/v1/fabric/registers/{name}` | Write register value |
| GET | `/api/v1/fabric/registers/{name}` | Read register value; `fresh=true` requests freshness check |
| POST | `/api/v1/fabric/registers/{name}/source` | Configure/sample supported source profile |
| POST | `/api/v1/fabric/factors` | Register factor manifest |
| POST | `/api/v1/fabric/couplings` | Add a coupling edge |
| GET | `/api/v1/fabric/manifold` | Inspect dependency/execution order |
| POST | `/api/v1/fabric/actions` | Emit an action event |
| POST | `/api/v1/fabric/triggers` | Register a trigger rule |
| GET | `/api/v1/fabric/events` | Read event records; supports `after_sequence` and `limit` |
| GET | `/api/v1/fabric/snapshot` | Snapshot current in-process state |
| POST | `/api/v1/fabric/event-values` | Set event value |

Register example:

```json
{"name":"melt.temperature", "value_type":"number", "unit":"K", "direction":"input", "required":true, "description":"Measured melt temperature", "max_age_ms":5000}
```

Write example:

```json
{"value": 1723.15, "source":"sensor-01", "unit":"K", "quality":"measured"}
```

The fabric is an in-process reference broker. It is not a durable distributed message bus, hard-real-time scheduler, isolated solver executor, or production multi-node event log. Coupling transforms and iterative cycles have limitations documented in the release notes; do not assume every transform is executed as a numerical operation.

## Compatibility notes

The original unprefixed utilities are retained for compatibility. Newer domain APIs use `/api/v1`. Future breaking changes should use a new major prefix or a documented deprecation process. Avoid relying on private implementation details in response schemas.

## Product licensing and paid expansions

The initial entitlement implementation accepts `X-Vulc-License` separately from the general `X-API-Key`. Product records are loaded from `VULC_LICENSES_JSON`; see [Licensing and Entitlements](LICENSING_AND_ENTITLEMENTS.md). This is a controlled-pilot foundation, not a complete checkout or license-management service.

- `GET /api/v1/products` — product IDs and current major versions.
- `GET /api/v1/license/status` — product entitlements for the supplied `X-Vulc-License`.
- `GET /api/v1/gravity-lab/status` — requires `gravity_lab_suite`.
- `POST /api/v1/gravity-lab/scenarios/evaluate` — combined dimensional-analysis workflow; requires `gravity_lab_suite` and `gravity_api`.
- `GET /api/v1/exotic-materials` — exotic-state taxonomy; requires `exotic_materials_api` and active data access.
- `GET /api/v1/exotic-materials-suite/status` — requires `exotic_materials_suite`.
- `POST /api/v1/exotic-materials-suite/workflows/annotate-conditions` — attach conditions to a selected phase entry; requires suite and active exotic-data entitlement.
- `/api/v1/metallurgy/gravity...` — requires `gravity_api`.
- Non-conventional material-state detail/condition requests require `exotic_materials_api` and active data access; free catalog listing returns conventional-family entries.

A `402` response indicates that a product entitlement or required data renewal is missing. A `503` indicates server-side license configuration trouble.
