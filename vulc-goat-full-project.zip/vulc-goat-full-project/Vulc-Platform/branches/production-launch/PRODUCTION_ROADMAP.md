# Vulc Production Roadmap

## Gate 0 — Preserve the baseline
- [x] Preserve the existing Vulc platform bundle as the starting baseline.
- [x] Record the product mapping, free-core policy, target pricing, and licensing model in `DECISIONS.md`.
- [ ] Create and retain a version-controlled source repository and tagged baseline release.

## Gate 1 — Production security and operations
- [ ] Protect all data-bearing routes, including legacy root-level routes, with a coherent authentication policy; preserve paths while changing policy.
- [ ] Add per-customer API keys, secure storage/hashing, rotation/revocation, and usage metering; do not rely on one shared environment-variable key list for a commercial service.
- [ ] Add rate limiting and abuse controls at gateway or service layer.
- [ ] Pin dependencies with a lock file; add dependency and container vulnerability checks.
- [ ] Add structured logs, metrics, tracing/request IDs, actionable health/readiness checks, and alerting.
- [ ] Define backup/restore and incident-response procedures where stateful services are introduced.
- [ ] Test deployment behind TLS and a reverse proxy; validate CORS and security headers.
- [ ] Audit license compatibility and all data provenance/redistribution rights.

## Gate 2 — Commercial product foundations
- [ ] Define an entitlement model for free core, Gravity API, Gravity Lab Suite, Exotic Materials API, and Exotic Materials Suite.
- [ ] Implement signed/verified licenses or a hosted entitlement service, with an offline grace policy if required.
- [ ] Implement annual renewal for data access and major-update entitlement without disabling the perpetual version already purchased.
- [ ] Add checkout, invoices/receipts, tax handling, refunds, customer portal, and renewal reminders before taking automated payments.
- [ ] Publish clear terms covering license scope, upgrades, hosted data, local data retention, support, and third-party datasets.

## Gate 3 — Gravity product
- [ ] Define Gravity API contract, units, frames, assumptions, valid ranges, and versioning.
- [ ] Separate simplified gravity utilities from validated physics capabilities in API and UI.
- [ ] Add reproducible tests, reference cases, numerical tolerances, and documentation for each supported calculation.
- [ ] Deliver Gravity Lab workflows end-to-end before describing them as production features.

## Gate 4 — Exotic Materials product
- [ ] Define taxonomy versus measured data versus calculated properties versus model predictions.
- [ ] Add source/provenance, uncertainty, conditions, units, and licensing metadata to every curated dataset.
- [ ] Define and enforce paid entitlements for exotic-state content and API operations.
- [ ] Add scientific review and regression fixtures for each claimed computation.
- [ ] Do not imply phase stability or predictive accuracy from a state catalog alone.

## Gate 5 — Production release criteria
- [ ] Automated tests pass in a clean environment.
- [ ] Security and dependency scans reviewed; no known critical/high unresolved issue without documented acceptance.
- [ ] API compatibility and migration policy documented.
- [ ] Load, failure, recovery, and backup/restore exercises completed as relevant.
- [ ] Monitoring, support ownership, release rollback, and incident process ready.
- [ ] Product claims are supported by shipped functionality and evidence.
- [ ] Owner approves the release.

## Current known baseline limitations

The existing GoatMaterials API is a useful foundation with catalog endpoints, crystallography helpers, gravity environment utilities, material-state metadata, Data Fabric reference behavior, and solver-planning components. It is not yet a production-certified scientific computing service. The Data Fabric is an in-process reference broker; coupling transforms are not a numerical execution engine; solver manifests and plans do not establish that a solver is installed or validated. API-key middleware has historically focused on `/api/...` routes while legacy root-level endpoints also exist, so complete route coverage must be audited before public deployment.
