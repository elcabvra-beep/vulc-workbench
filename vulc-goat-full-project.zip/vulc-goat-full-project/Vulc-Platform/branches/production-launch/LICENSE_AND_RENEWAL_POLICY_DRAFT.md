# Vulc License and Renewal Policy — Draft for Legal Review

This is a product-policy draft, not legal advice or a final customer contract.

1. **Vulc Core:** available at no charge under its published license.
2. **Paid expansion purchase:** grants the customer the rights expressly stated for the purchased version of the relevant expansion.
3. **Perpetual version use:** expiration or non-renewal of maintenance does not, by itself, cancel the customer's right to use the purchased locally installed version, subject to license compliance and third-party component terms.
4. **Annual optional plan:** may cover access to specified hosted/curated datasets, major releases, maintenance updates, and support. The checkout page must clearly list included services and dates.
5. **Renewal lapse:** hosted services or licensed feeds may cease or become limited at the end of the paid term if disclosed in advance. Locally retained data may be kept only to the extent its data license permits.
6. **Data rights:** third-party datasets can have separate restrictions and may not be bundled, redistributed, or retained without permission.
7. **Updates:** state whether minor fixes are included with the original purchase or only during active maintenance. Do not imply a promise that future updates will always be produced.
8. **License tiers:** individual, commercial/team, and research/enterprise rights should be clearly distinguished where offered.
9. **Refunds, taxes, privacy, export controls, warranty disclaimers, liability limits, and governing law:** require jurisdiction-appropriate legal review before sale.
10. **No remote data destruction:** renewal expiration must not trigger deletion of customer-owned project files or locally stored user data.
