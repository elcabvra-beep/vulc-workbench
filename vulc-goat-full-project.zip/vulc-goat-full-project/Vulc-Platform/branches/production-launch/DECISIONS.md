# Vulc Production Branch — Product Decisions

**Branch snapshot date:** 2026-10-27  
**Status:** Production planning and hardening started; not yet production-certified.

## Platform policy

- Vulc Core remains free.
- Extensions and specialized capabilities may be paid products.
- Themes are presentation/creative identities; they do not define or replace the underlying API or engineering suite.
- Preserve existing Python import namespaces and API paths during initial productization for compatibility.

## Product mapping

### Sometimes Lonely Space Punk
- Role: theme/creative identity.
- Product: Gravity API.
- Suite: Gravity Lab Suite.
- The suite is for gravity-oriented engineering workflows and related tools.

### Full Goatmetal Jacket: Cowboy Action Pack
- Role: paid theme/expansion; current target price: **$200**.
- Product: Exotic Materials API.
- Suite: Exotic Materials Suite.
- Exotic phases/states and specialized exotic-material capabilities are not part of the free core.

## Licensing and renewals

- Perpetual license for the version purchased, under the applicable license terms.
- Annual renewal is optional, not mandatory to keep using the purchased version.
- Active annual maintenance/data plan may provide eligible hosted or curated data access, major updates, and maintenance benefits as specified in the offer.
- When renewal expires, the customer retains access to their licensed installed version and locally retained data, subject to third-party data licenses and product terms.
- Hosted data services may stop or become limited when the applicable service term ends; disclose this before purchase.
- Do not erase customer data or remotely disable a locally installed perpetual version solely because renewal expires.

## Future premium edition

- Vulc Professional / Research Edition target: **$1,000+**.
- Do not launch until the owner is satisfied with quality, maturity, documentation, security, support, and demonstrated capabilities.
- Price is a target concept, not a current offer or validated market price.

## Scientific integrity

- Catalog entries and taxonomy are not proof of material stability or predictive accuracy.
- Solver discovery/planning must not be represented as actual solver execution.
- Phase predictions, engineering outputs, and solver results must be labeled according to evidence, assumptions, and validation status.
