# Production Branch Log

Branch: `production/2026-10-27`

## Baseline

- Preserved the existing Vulc, GoatMaterials, and Solver Data Driver — Project Maven source tree.
- Preserved the `goat_materials` and `goat_solver_api` Python namespaces.
- Captured the approved free-core / paid-expansion product architecture in `DECISIONS.md`.

## Milestone 1 — API access-control hardening

- Expanded API-key checks from `/api/...` to all application data routes, including legacy routes such as `/periodic-table` and `/elements/{symbol}`.
- Kept health probes and interactive API documentation public by explicit allow-list.
- In `GOAT_ENV=production`, protected application routes now fail closed with HTTP 503 if no API keys are configured.
- Added `X-API-Key` and `X-Request-ID` to the CORS allowed headers.
- Added regression tests for legacy-route bypass and production fail-closed behavior.
- Added `.gitignore` and removed generated Python caches from version control.

### Verification

- GoatMaterials backend: `PYTHONPATH=. python -m pytest -q` — **47 passed**.
- Solver Data Driver — Project Maven: `python -m pytest -q` — **10 passed**.

### Remaining before public production deployment

- Use a managed secret store and high-entropy keys; the current comma-separated environment-variable key list is a baseline, not a complete key lifecycle system.
- Add rate limiting and request quotas at a gateway or in a dedicated service.
- Review public docs/OpenAPI exposure and route-by-route data sensitivity.
- Pin dependencies, add vulnerability scanning, CI, deployment smoke tests, backups/restore where applicable, and monitoring/alerting.
- Implement durable customer identity, entitlements, license issuance, renewals, and data-access enforcement before selling paid API access.
- Validate scientific methods and external solver adapters before claiming engineering-grade predictions.

This branch is a production-hardening work branch, not a claim that the system has completed security certification or is ready for unrestricted public deployment.
