# Contributing to Vulc Workbench

Thank you for considering a contribution.

## Before starting

- Search existing issues and discussions.
- For substantial changes, open an issue first to agree on scope.
- Never submit secrets, private data, confidential institutional information, export-controlled material, or data you do not have permission to share.

## Scientific and engineering changes

Please include, as applicable:

- A minimal reproduction or benchmark.
- Units, assumptions, boundary conditions, and valid parameter ranges.
- Expected behavior and actual behavior.
- Tests, convergence evidence, conservation checks, or comparison to an analytical/trusted reference.
- Source and license details for external datasets.
- Clear distinction between measured values, calculations, predictions, and illustrative examples.

Do not describe a model as experimentally validated unless the validation evidence is documented and independently reviewable.

## Pull requests

Keep changes focused. Explain the motivation, limitations, test commands, and any compatibility implications. Unsupported features should fail clearly rather than produce plausible-looking fabricated results.

## Contributor rights

Before accepting external contributions, the project owner must publish the chosen contribution terms and license. Opening a pull request does not by itself settle every copyright or licensing question; contributors should review the repository's finalized policy.
