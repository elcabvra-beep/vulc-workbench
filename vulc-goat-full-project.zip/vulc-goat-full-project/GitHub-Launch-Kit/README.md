# Vulc Workbench

**An early-stage, reproducible scientific-computing workbench for explicit model execution and auditable results.**

Vulc is being developed to make computational workflows easier to inspect, reproduce, and extend. The current demonstrator connects a small GOAT declarative script to a registered thermal model and reports numerical results with run identification and configuration provenance.

> **Research prototype — not a certified or production-qualified engineering solver.** Results must be independently reviewed for the intended use. No experimental validation is implied.

## Current scope

- GOAT-script parsing, validation, and execution for the supported thermal demonstration.
- Registered-model dispatch with unsupported constructs rejected rather than silently approximated.
- Run identifiers and configuration hashes to help distinguish executions from their inputs.
- Automated tests and a documented thermal benchmark.

## Known limitations

- The current GOAT-to-solver path is limited; general multi-process graph execution is not complete.
- Comprehensive material-property provenance, validity ranges, and uncertainty tracking are not complete.
- Spatial mapping operators and broader coupled simulations are not generally supported.
- The spatial thermal model has not been independently validated against experimental data.
- Passing tests does not establish fitness for safety-critical or production engineering decisions.

## Quick start

1. Download the source archive from the repository's **Releases** page.
2. Review the release notes and test report before running it.
3. Use a supported Python version as specified by the project metadata or release notes.
4. Run the test suite using the command documented for that release.
5. Start with the included benchmark and compare the output with its stated reference.

Commands and dependency requirements may change by release. Follow the exact instructions in the tagged release rather than assuming commands from an older version apply.

## Project principles

- **Scientific honesty:** separate measured data, calculations, predictions, and illustrative examples.
- **Reproducibility:** document inputs, units, assumptions, configuration, and known limits.
- **Fail closed:** reject unsupported model features instead of inventing behavior.
- **Open collaboration:** welcome issues, reproducible bug reports, benchmark proposals, and respectful review.
- **Human connection:** informal conversations and visits are welcome when people have the time and capacity; see [Community and contact](docs/COMMUNITY.md).

## Copyright and licensing

The project owner retains copyright in original project material they own. The repository's software license grants the permissions stated in `LICENSE`; it does not transfer copyright ownership. The license file must be finalized with the copyright holder's chosen legal name and year before publication.

The software license does not claim ownership of independently created output or content merely because Vulc was used to create it. Third-party components and datasets remain subject to their own terms. See [Licensing policy](docs/LICENSING.md).

## Contributing

Please read [CONTRIBUTING.md](CONTRIBUTING.md), open an issue for substantial changes, and include tests or reproducible evidence where practical. Do not submit confidential, export-controlled, proprietary, or personal information.

## Contact and research collaboration

Use GitHub Issues for public, technical discussion. For private or sensitive matters, use the contact route the project owner publishes separately. For prospective institutional reviewers, see [Research outreach](docs/OUTREACH.md).

## Status

This repository is an evolving research prototype. Feature support, test coverage, and validation status must be judged from the current source and release-specific reports, not marketing claims.
