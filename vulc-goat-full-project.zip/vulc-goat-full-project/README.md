# GOAT + Vulc — Full Project Bundle

This archive gathers the current project artifacts into one local handoff bundle.

## Contents

- `Vulc-Workbench/` — Vulc Workbench 1.5 community source archive, including Python engine/physics code, GOAT compiler, examples, tests, workbench UI, test report, community invitation, and outreach plan.
- `Vulc-Platform/` — current umbrella platform documentation and GoatMaterials platform reference files.
- `GitHub-Launch-Kit/` — starter README, static homepage, contribution and community policies, issue templates, and GitHub Pages workflow.

## Important status notes

- This is a bundled handoff, not a claim that all folders form one integrated executable monorepo.
- The Workbench is an early-stage research prototype, not a certified or production-qualified engineering solver.
- Some platform directories described in planning documentation may not be present in this bundle; use the included source and docs as the actual scope.
- The launch kit's `LICENSE` is a placeholder. Replace it with the full text of a chosen open-source license before publishing the repository publicly.
- Replace `YOUR-USERNAME` and copyright-holder placeholders before publishing.
- Keep the Workbench's release-specific test report with its matching source version.

## Suggested GitHub organization

1. `vulc-workbench` — primary source and scientific-computing prototype.
2. `vulc-media-theme` — visual assets, styling, design tokens, and theme documentation.
3. Optional later repository: `goatmaterials-platform` — API/platform source once its code, tests, license, and deployment instructions are fully assembled.

## Reproducibility

Check each component's README and test report before running it. Do not assume that documentation for one component proves that other components have been integrated or validated.
